﻿function Local {
Set-ExecutionPolicy RemoteSigned -Force
Enable-PsRemoting -Force
Enable-NetFirewallRule -DisplayName "Remote Scheduled Tasks Management (RPC)"
Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (DCOM-In)"
Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (WMI-In)"
Set-NetFirewallRule -DisplayName "Windows Remote Management (HTTP-In)" -Profile Domain, Private
Get-WmiObject -Class Win32_Volume | Select-Object Label, BlockSize
vssadmin list shadowstorage
}

function LocalHSW {
Import-PfxCertificate -FilePath "\\pacfile2\groups\epic\Technical Team\Upgrade2019\Certs\EpicHSW.pfx" -Password (ConvertTo-SecureString -String "EpicTLS" -AsPlainText -Force) -CertStoreLocation Cert:\LocalMachine\My
New-WebBinding -HostHeader EpicHSW.phs.org -Name "Default Web Site" -Port 443 -Protocol https
}

function Remote {
$servers = Get-Content C:\Input\servers.txt
Install-WindowsFeature -name Net-Framework-Core -ComputerName $server -source \\netappb\EpicRA\sxs
foreach($server in $servers) {
$s = New-Pssession -ComputerName $server
Invoke-Command -session $s { powercfg.exe -SETACTIVE 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c } }
}