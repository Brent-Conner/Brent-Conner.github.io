﻿$recipients = ("5055502936@vzvmg.biz","bconner@phs.org")
$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")
$sleep = "300"
$max = "50"

while(1)
{	
$date = Get-Date
write-host $date

	foreach ($server in $EPSservers)
	{
		$sender = $server + "@phs.org"
		$folder = get-childitem -Path "\\$server\d$\Epic\Jobs\Incoming\8.3\Epic Print Service" -recurse | Measure-Object
		$count = $folder.count
		$stat = Get-Service -Name 'Troy Port Monitor Service' -ComputerName $server

        write-host "$server has $count print jobs -- Troy Service is" $stat.status

		if ($count -ge $max) { Send-Mailmessage -to $recipients -from $sender -Subject "$server has $count jobs waiting to print." -SmtpServer "imr2.phs.org" }
               
        if ($stat.status -ne "Running")
	    {
		$stat | Start-Service
        Send-Mailmessage -to $recipients -from $sender -Subject "The Troy service on $server was found not running." -SmtpServer "imr2.phs.org"
        }
	}
$minutes = $sleep / 60
write-host "Counting complete, sleeping for $minutes minutes"
Start-Sleep -s $sleep
}
