﻿function TroyInclusion
{
    $x = "95"
    $y = "1950"
    $w = "3000"
    $h = "2135"

    $TroyPort = 1
    while($TroyPort -lt 501)
    {

        $Counter = 0
        while($Counter -lt 4)
        {
        $Dest = "D:\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPantographConfiguration.xml"
        [xml]$DestConfig = Get-Content -Path $Dest
       
        $DestConfig.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].ExclusionRegions.PantographRegionObjectType.XAnchor = $x
        $DestConfig.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].ExclusionRegions.PantographRegionObjectType.YAnchor = $y
        $DestConfig.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].ExclusionRegions.PantographRegionObjectType.Width = $w
        $DestConfig.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].ExclusionRegions.PantographRegionObjectType.Height = $h
    
        $DestConfig.Save("$Dest")
        Write-Host $TroyPort
        $Counter++
        }
    $TroyPort++
    }
}

TroyInclusion

# $DestConfig.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].ExclusionRegions.innerText = $null