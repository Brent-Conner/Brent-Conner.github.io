﻿$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")

[xml]$exsrc = Get-Content -path "\\zwpdcepiceps11\d$\config\TroyPantographConfiguration.xml"
$srcxanchor = $exsrc.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.XAnchor
$srcyanchor = $exsrc.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.YAnchor
$srcwidth = $exsrc.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.Width
$srcheight = $exsrc.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.Height

foreach($server in $EPSservers)
{

$portnum = 1
while($portnum -lt 501)
{
$path = "\\$server\d$\Program Files\TROY Group\Port Monitor\PrintPort$portnum\Config\TroyPortMonitorConfiguration.xml"
[xml]$exdest = Get-Content -path $path

$ximport = $exdest.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.XAnchor = $srcxanchor
$exdest.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.YAnchor = $srcyanchor
$exdest.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.Width = $srcwidth
$exdest.PantographConfiguration.PantographConfigurations.CustomConfiguration.ExclusionRegions.PantographRegionObjectType.Height = $srcheight

$exdest.save("$path")