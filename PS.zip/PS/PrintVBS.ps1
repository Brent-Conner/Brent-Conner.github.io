﻿$printers = Get-Printer | Select Name # Where {$_.name -like '*BE*'}
#$printers = Get-WmiObject -Class Win32_Printer | Select Name

foreach ($printer in $printers)
    {
    #Write-Host "Configuring $printer.name"
    #Set-Printer -p $printer.name +rawonly -enablebidi
    c:\windows\system32\printing_admin_scripts\en-us\prncnfg.vbs -t -p $printer.name -published +rawonly -enablebidi -docompletefirst -queued -shared
    start-sleep -s 1
    }
    