﻿$servers = ("ZWTSTEPICWEB11","ZWTSTEPICWEB12")
Function RecycleTST {
    foreach ($server in $servers) {
    Invoke-Command -CN $server { Restart-WebAppPool -Name "MyChartPHS-TST" } }
    Write-Host "TST Recycled" }

Function RecycleTSTO {
    foreach ($server in $servers) {
    Invoke-Command -CN $server { Restart-WebAppPool -Name "MyChartPHS-TSTO" } }
    Write-Host "TSTO Recycled" }

Write-Host "1. Recycle TST"
Write-Host "2. Recycle TSTO"
$MenuOption = Read-Host "Option"
Switch($MenuOption) { "1" { RecycleTST } "2" { RecycleTSTO } }