﻿$PC = Read-Host "Enter silver tag or IP"

If (Test-Connection -ComputerName $PC -Count 2 -Quiet)
 { Start-Process -FilePath "C:\Windows\System32\msra.exe" -Args "/Offerra \\$PC" }
Else
 { Return "Failed to Connect to $PC" }