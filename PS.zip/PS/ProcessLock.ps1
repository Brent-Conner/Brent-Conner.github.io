﻿$FileOrFolder = "D:\Epic\HSWebApps\PHS-GRN\830-13\web.config"

IF((Test-Path -Path $FileOrFolder) -eq $false) {
    Write-Warning "File or directory does not exist."       
}
Else {
    $LockingProcess = CMD /C "openfiles /query /fo table | find /I ""$FileOrFolderPath"""
    Write-Host $LockingProcess
}