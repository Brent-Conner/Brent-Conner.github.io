﻿$servers = ("zwpdcepiceps01","zwpdcepiceps02","zwpdcepiceps03","zwpdcepiceps04","zwpdcepiceps05")	
$OldIP = Read-Host "OldIP "
$NewIP = Read-Host "NewIP "
foreach ($server in $servers)
    {
    # CreatePort
    Write-Host "Creating $NewIP on $server"
	    $port=([WMICLASS]"\\$server\ROOT\cimv2:Win32_TCPIPPrinterPort").createInstance() 
        $port.Name=$NewIP
        $port.SNMPEnabled=$false 
        $port.Protocol=1 
        $port.HostAddress=$NewIP 
        $port.Put() | Out-Null
    }
foreach ($server in $servers)
    {
    # ChangePort
    $Printer = Get-Printer -ComputerName $server | where-Object { $_.PortName -eq $oldIP }
    $Name = $Printer.Name
    Write-Host "Changing $Name to IP $NewIP on $server"
    Set-Printer -Name $Name -ComputerName $server -PortName $NewIP | Out-Null
    }

#foreach ($server in $servers)
#    {
    # Delete old printer port
#    Write-Host "Deleting $OldIP on $server"
#    Remove-PrinterPort -ComputerName $server -Name $OldIP
#    }
Pause