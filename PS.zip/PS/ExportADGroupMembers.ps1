﻿import-module activedirectory
$basepath = "\\pacfile2\groups\epic\Technical Team\Security"
$exports = "\\pacfile2\groups\epic\Technical Team\Security\Exports"
$Date = Get-Date -Format d | % {$_.replace("/","_")}
$outpath = $exports + "\" + $Date
If (!(Test-Path $outpath)) { New-Item $outpath -Type Directory -Force | Out-Null }

$groups = Get-Content "$basepath\Groups.txt"
foreach($group in $groups)
{
$i = 0
$header = "Name^ID^Title^Manager^Acct Active"
$header | Out-File "$outpath\$group.txt" -append
$all = $null
$all = Get-ADGroupMember -identity $group
if($all -ne $null) {
    foreach($one in $all)
    {
        $manager = $null
        $get = Get-ADUser $one.samaccountname -Properties manager,title,enabled
        $status = $get.enabled
        $title = $get.title
        $manager = (Get-ADUser $get.Manager).name
        $out = $one.name + "^" + $one.samaccountname + "^" + $title + "^" + $manager + "^" + $status
        $out | Out-File "$outpath\$group.txt" -append
    }
}
}