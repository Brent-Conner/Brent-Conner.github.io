﻿$HSWservers = Get-Content C:\Input\PRODHSW.txt

foreach($server in $HSWservers)
{
$info = get-wmiobject -class Win32_ComputerSystem -namespace "root\CIMV2" -computername $server
$gb = [math]::round($info.totalphysicalmemory/1024/1024/1024)
$out = $server + "," + $gb
$out # | Out-file C:\Output\raminfo.txt -append
}