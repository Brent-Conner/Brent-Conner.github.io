﻿$server = Read-Host "Server"
$service = Read-Host "Service"

Get-Service -ComputerName $server -name $service | Restart-Service -Force