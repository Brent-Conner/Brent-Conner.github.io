﻿$pcname = read-host "Enter silver tag with prefix: "
gwmi win32_userprofile -computername $pcname | select @{LABEL="Last used";EXPRESSION={$_.ConvertToDateTime($_.lastusetime)}}, LocalPath | ft -a