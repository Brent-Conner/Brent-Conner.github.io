$ErrorActionPreference = "SilentlyContinue"
$names = Get-ChildItem -Force \\epic2010hwebm\bca\outgoing
$all = $names | Select Name
$singles = $all | Select-String Name
$output = $singles -replace ".*=" -replace "}.*"
#$output | Out-File -Append C:\scripts\bcanames.txt
$ping = new-object System.Net.NetworkInformation.Ping

foreach ($one in $output)
{
Write-host "Pinging" $one
$r = $ping.send($one)
$out = $one + ',' + $r.status.tostring()
$out | Out-File -Append C:\scripts\bcanamesandping.txt
}

