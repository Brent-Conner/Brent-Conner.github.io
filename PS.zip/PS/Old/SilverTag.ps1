import-module activedirectory
while(1)
{
$tag = read-host "Enter silver tag no prefix"
$pc = get-adcomputer -ldapfilter "(name=*$tag)"
$out = $pc.name
write-host $out
$out | out-file c:\tmp\pcs.txt -append
}

