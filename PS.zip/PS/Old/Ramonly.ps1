﻿#$heading = "Map Identifier,Cube,Location,UID,Last Name,First Name,Phone,Silver Tag,Operating System,Model,Serial Number,Current RAM"
#$heading | Out-File C:\tmp\raminfo.txt -append
while(1)
{
$pcname = read-host "Enter silver tag"
if ($pcname -eq "exit")	{ break	}
gwmi win32_userprofile -computername $pcname | select @{LABEL="Last used on $pcname";EXPRESSION={$_.ConvertToDateTime($_.lastusetime)}}, LocalPath | ft -a
#$userinfo = Get-ADuser -Identity $user; $userfull = $userinfo.name -replace ', ',','
$pcinfo = get-wmiobject -class Win32_ComputerSystem -namespace "root\CIMV2" -computername $pcname
$serial = get-wmiobject -class Win32_bios -computername $pcname
$gb = [math]::round($pcinfo.totalphysicalmemory/1024/1024/1024)
$model = $pcinfo.model
if ($model -eq $null){$model="offline"}
if ($gb -eq "0"){$gb = "offline"}
$out = $pcname + "," + $model + "," + $serial.serialnumber + "," + $gb + "GB"
write-host $out
#$out | out-file c:\tmp\raminfo.txt -append
}