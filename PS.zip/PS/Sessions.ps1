﻿$server = Read-Host "Server"
$connections = ((Get-Counter -Counter 'web service(_total)\Current connections' -Computername $server).CounterSamples).CookedValue
Write-Host $server "-" $connections

#Get-Counter -ListSet ASP* | Select -expand counter | ?{$_ -match 'session'}