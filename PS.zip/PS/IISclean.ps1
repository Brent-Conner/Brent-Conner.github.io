﻿# Delete all files older than 7 days
$IISpath = "C:\inetpub\logs\LogFiles\W3SVC1\"
$FTPpath = "C:\inetpub\logs\LogFiles\FTPSVC2\"
$Days = "-7"
$CurrentDate = Get-Date
$DatetoDelete = $CurrentDate.AddDays($Days)
Get-ChildItem $IISpath -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse
Get-ChildItem $FTPpath -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse