﻿Param (
	[string]$PrintServer = "zwpdcepiceps11"
)
$Results = @()

ForEach ($Driver in (Get-WmiObject Win32_PrinterDriver -ComputerName $PrintServer))
{	$Drive = $Driver.DriverPath.Substring(0,1)
	$Results += New-Object PSObject -Property @{
		Name = $Driver.Name
		Version = (Get-ItemProperty ($Driver.DriverPath.Replace("$Drive`:","\\$PrintServer\$Drive`$"))).VersionInfo.ProductVersion
	}
}
$Results | Out-File C:\Output\$PrintServer.txt