﻿$msi = '\\netappb\EpicRA\2019\May\Client Applications\BCA PC\Epic May 2019 BCA PC.msi'
$cp4 = '\\netappb\EpicRA\SU_EEDS\RA-2195_10-01-2019\CP_004_-_RA _2195{sync}\Epic_May_2019_BCA_PC_CP_4_-_RA__2195{sync}.msp'
$fmsi = 'C:\ProgramData\Epic\Satellite\Downloads\C5677A25E6E890DAF1EDC1B64FD6652F88AE4C160A8AC31FF5CB3C2D11071E8C'
$fcp4 = 'C:\ProgramData\Epic\Satellite\Downloads\FD275774B6CF3E66E3A07443BE18061F834CE6B4BA2735030E15965B1B8F0617'

$pc = Read-Host "PC"
$s = New-PSSession $pc

Invoke-Command -Session $s { New-Item -ItemType 'Directory' -Name $fmsi -Force }
Invoke-Command -Session $s { New-Item -ItemType 'Directory' -Name $fcp4 -Force }
Copy-Item -Path $msi -Destination $fmsi -Force -ToSession $s
Copy-Item -Path $cp4 -Destination $fcp4 -Force -ToSession $s

