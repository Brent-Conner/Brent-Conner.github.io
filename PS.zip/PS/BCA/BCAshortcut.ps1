﻿$Contents = Get-Content '\\pacfile2\groups\epic\Technical Team\BCA\BCAlist.csv'

foreach($Line in $Contents)
{
if($line[0] -eq "#") { Write-Host $line }
else{
$s = $Line -split ","
$pc = $s[0]

if(Test-NetConnection -ComputerName $PC -InformationLevel Quiet) {
$session = New-PSSession $pc
Write-Host "Attempting to copy to $pc"
Copy-Item -Path 'C:\Input\BCA Printing.lnk' -Destination C:\Users\Public\Desktop -Force -ToSession $session

}
}
}