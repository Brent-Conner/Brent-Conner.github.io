﻿$tocatest = "catestmailbox@phs.org"
$tob = "bconner@phs.org"
$tocaprod = "camailbox@phs.org"
$customer = Read-Host "Enter your username (no @phs.org) example- bconner "
$from = ("ecsm@phs.org")
$toecsm = $customer + "@phs.org"
$pw = 'Pre$byterian1'
$Contents = Get-Content '\\pacfile2\groups\epic\Technical Team\BCA\BCAlist.csv'
$PullService = ("EpicBCAClient93")
$sleep = "1"
$minutes = $sleep / 60

foreach($Line in $Contents)
{
if($line[0] -eq "#") { Write-Host $line }
else{
$s = $Line -split ","
$pc = $s[0]
$group = $s[1]
$loc = $s[2]
$dep = $s[3]
$desc = $s[4]
$subject = "BCA - " + $pc + " | " + $loc + " | " + $dep + " | " + $desc 

    if(Test-NetConnection -ComputerName $PC -InformationLevel Quiet)
    {
        $status = Get-Service -ComputerName $PC -Name $PullService
        Write-Host $PC $status.status $status.name
        
        if($status -eq $null) { 
            Write-Host -foreground red "$PC $($status.status) doesn't exist or can't be queried, sending email to $toecsm"
            Send-Mailmessage -to $toecsm -from $from -subject "Install BCA Application on $PC" -body "$PC is online, but service $PullService doesn't exist or cannot be queried." -SmtpServer "imr2.phs.org" }
        if($status.status -eq "Stopped") {
            Write-Host -foreground red "$PullService on $PC is $($status.status), sending email to $toecsm"
            Send-Mailmessage -to $toecsm -from $from -subject "$PullService is stopped on $PC" -body "$PC is online, but service $PullService isn't running." -SmtpServer "imr2.phs.org" }
    }
    else { 
    Write-Host -foreground red "$PC is offline, sending email to $tocaprod"
    Send-Mailmessage -to $tocaprod -from $from -subject "Auto-Generated BCA PC Incident" -body "%GROUP=$group
%ZCIINITIAL=$pc
%Z_LOCATION=$loc
%CUSTOMER=$customer
%SUMMARY=$subject
%DESCRIPTION=The BCA computer is offline, unable to authenticate network accounts, or otherwise not able to pull downtime reports from the server.

1. Ensure BCA PC is online
2. Verify network authentication
3. Re-image to Windows 10 if the BCA is still on Windows 7.
4. Check local admin account UID: $pc\Presbyterian PW: $pw" -SmtpServer "imr2.phs.org" }

Start-Sleep -s $sleep
}
}