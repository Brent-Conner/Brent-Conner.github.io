﻿$PC = Read-Host "Silver Tag"
Invoke-Command -cn $PC { $rpt = Get-ChildItem "C:\Epic\Jobs\Processed\Epic Bca Client\" | Select LastWriteTime ; $rpt[-1]}
