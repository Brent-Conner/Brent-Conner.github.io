﻿#$path = "\\c4usc1syn03g003\OnbaseProd01\SWEEP\Jiva"
$path = "\\zwtstonbtapp01\Sweep\Jiva\Test"
$Names = Get-ChildItem $path -recurse | Where-Object { $_.name -match ".pdf" }
$file = $path + "\names.txt"

foreach ($name in $names) { 
$out = $path + "," + $name
$out | Out-File $file -Append
}