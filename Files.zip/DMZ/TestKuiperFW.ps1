$servers = Get-Content D:\scripts\_Servers\DMZ.txt
$outfile = "D:\Scripts\DMZFWtest.txt"
$c = ","

"SourceIP,Server,ServerIP,135,5985" | Out-File $outfile
foreach($server in $servers) {

$info = test-netconnection -cn $server

$135 = (test-netconnection -cn $server -port 135).tcptestsucceeded
$5985 = (test-netconnection -cn $server -port 5985).tcptestsucceeded

$out = $info.SourceAddress.IPAddress + $c + $server + $c + $info.RemoteAddress.IPAddressToString + $c + $135 + $c + $5985
$out | Out-File $outfile -append
}