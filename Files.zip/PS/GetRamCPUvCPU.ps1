﻿$servers = Get-Content C:\Input\servers.txt
foreach($server in $servers)
{
Write-Host $server
$ram = Invoke-Command -ComputerName $server { (systeminfo | Select-String 'Total Physical Memory:').ToString().Split(':')[1].Trim() }
$vcpu = Invoke-Command -ComputerName $server { (Get-WmiObject Win32_ComputerSystem).NumberOfLogicalProcessors }
$ram
$vcpu
$out = $server + "^" + $vcpu + "^" + $ram
$out | out-file c:\output\info.txt -append

 

}