﻿$servers = Get-Content C:\input\testb.txt
#$kb = Read-Host "KB"

foreach($server in $servers)
{
Write-host $server
Get-hotfix -ComputerName $server | where {$_.installedon -match "3/18/2020" }
#$hotfix = Get-Hotfix -ComputerName $server | where {$_.HotFixId -like $KB} | select-object installedon
#If ($hotfix -eq $null) {Write-Host "$KB is not installed on $server"} Else {Write-Host "$KB was $hotfix to $server" }
}

