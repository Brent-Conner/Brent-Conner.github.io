$recipients = Get-Content -path c:\input\users.txt
$num = Get-Content -path c:\input\fax.txt
$from = ("noreply@phs.org")


$i = 0
foreach($recipient in $recipients)
{
Write-Host $recipient $($num[$i])
Send-Mailmessage -to $recipient -from $from -Subject "RightFax Access" -body "Welcome to Presbyterian!

We are very excited that you are joining the PHS family and look forward to future collaboration!

Your account has been setup within the RightFax system.
Below is your personal fax number and the RightFax web access link, along with a link to common 'How-to Guides', including RightFax.

Rightfax link: http://rightfaxweb/webclient

Fax number: $($num[$i])


How-to guides: http://itteams.phs.org/ait/Public/Home.aspx

" -SmtpServer "imr2.phs.org"
$i++
}

