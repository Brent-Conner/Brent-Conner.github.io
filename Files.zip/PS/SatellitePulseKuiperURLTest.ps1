New-Item C:\Scripts -type directory
$outfile = "C:\Scripts\DMZFWtest.txt"
$c = ","
#"Source,SourceIP,Kuiper,Pulse" | Out-File $outfile

$kurl = "epickuiper.mountsinai.org"
$purl = "sepiplsp018001.mountsinai.org"
$ping = test-netconnection -cn $kurl -port 443

$sourceIP = $ping.sourceaddress.IPAddress
$kuiper = $ping.tcptestsucceeded
$pulse = (test-netconnection -cn $purl -port 443).tcptestsucceeded

$out = $env:COMPUTERNAME + $c + $sourceIP + $c + $kuiper + $c + $pulse
$out | Out-File $outfile -append
Invoke-Item $outfile
SEPIMYCT019001,146.203.150.140,False,False
SEPIMYCT019002,146.203.150.141,False,False
SEPIMYCT018001,146.203.150.108,False,True
SEPIMYCT018002,146.203.150.109,False,True

$outfile = "C:\Scripts\DMZFWtest.txt"
$c = ","
"SourceIP,Kuiper,Pulse" | Out-File $outfile

$kurl = "epickuiper.mountsinai.org"
$purl = "sepiplsp018001.mountsinai.org"

$info = Get-ComputerInfo

$kuiper = (test-netconnection -cn $kurl -port 443).tcptestsucceeded
$pulse = (test-netconnection -cn $purl -port 443).tcptestsucceeded

$out = $info.CsName + $c + $server + $c + $info.RemoteAddress.IPAddressToString + $c + $kuiper + $c + $pulse
$out | Out-File $outfile -append
Invoke-Item $outfile
