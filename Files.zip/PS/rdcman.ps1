﻿$servers = Get-Content C:\Scripts\HSW.txt
$file = "C:\Scripts\rdcman.txt"
        
foreach($server in $servers) {        
        
"        <server>" | Out-File $file -append
"          <properties>" | Out-File $file -append
"            <name>$server</name>" | Out-File $file -append
"          </properties>" | Out-File $file -append
"        </server>" | Out-File $file -append
}