﻿$servers = Get-Content D:\Scripts\_Servers\ICprd.txt

foreach($server in $servers) {
echo $server
Get-Service -ComputerName $server -Name *Interconnect* | Restart-Service -Force
Get-Service -ComputerName $server -Name w3svc | Restart-Service -Force
}
#Get-Service -cn sepiintt018002 -Name *Interconnect* | Where { $_.StartType -eq "Automatic" } | Start-Service
#Get-Service -cn sepiintt018002 -Name w3svc | Start-Service
