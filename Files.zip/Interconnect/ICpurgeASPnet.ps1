﻿# Delete Temp ASP NET files from previous CP versions
$servers = "SEPIINTP018003","SEPIINTP018004","SEPIINTP018005","SEPIINTP018006","SEPIINTP018007","SEPIINTP018008"
#$servers = "SEPIINTT018002","SEPIINTT018001","SEPIINTT018003","SEPIINTT018004","SEPIINTT018005","SEPIINTT018006","SEPIINTT018007","SEPIINTT018008"


foreach($server in $servers) {
$aspnet = "\\$server\C$\Windows\Microsoft.NET\Framework64\v4.0.30319\Temporary ASP.NET Files\"
$paths = Get-ChildItem $aspnet -Directory
    foreach($path in $paths) {
        if($path -match "interconnect") {
        $path = $aspnet + $path
        Write-Host $path
        Get-ChildItem $path -Directory | Sort-Object CreationTime -Descending | Select-Object -Skip 1 | Remove-Item -Recurse -Force
        }
    }
}