﻿$MYCHARTservers = ("ZWPDCEPICWEB01","ZWPDCEPICWEB02")
$recipients = ("5055502936@vzvmg.biz","bconner@phs.org")
$sleep = "300"

while(1)
{	
$date = Get-Date
write-host $date

	foreach ($server in $MYCHARTservers)
	{
		$sender = $server + "@phs.org"
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',$server)
        $path = 'SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings'
        $key = $reg.OpenSubKey($path)
        $hex = $key.GetValue('ProxySettingsPerUser')
        Write-Host $server $hex

		if ($hex -ne '0')
		{
			write-host "Sending email for $server -- $date"
			Send-Mailmessage -to $recipients -from $sender -Subject "$server has incorrect settings." -SmtpServer "imr2.phs.org"
		}

	}
$minutes = $sleep / 60
write-host "Sleeping for $minutes minutes"
Start-Sleep -s $sleep
}