﻿
Get-Service -Name W3SVC | Stop-Service -Force

# BLD to TST
Echo "Copying strings from BLD to TST"
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\en-US\scripts\MyChartJSStrings.js" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTTST\web\en-US\scripts\" -Force
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\en-US\scripts\MyChartJSStrings.min.js" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTTST\web\en-US\scripts\" -Force
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\CombinedStrings\*" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTTST\web\CombinedStrings\" -Force -Recurse
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\CustomStrings\*" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTTST\web\CustomStrings\" -Force -Recurse


# BLD to UPGPLY
Echo "Copying strings from BLD to UPGPLY"
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\en-US\scripts\MyChartJSStrings.js" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTUPGPLY\web\en-US\scripts\" -Force
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\en-US\scripts\MyChartJSStrings.min.js" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTUPGPLY\web\en-US\scripts\" -Force
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\CombinedStrings\*" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTUPGPLY\web\CombinedStrings\" -Force -Recurse
Copy-Item -path "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\web\CustomStrings\*" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTUPGPLY\web\CustomStrings\" -Force -Recurse

Start-Service -Name W3SVC


$servers = "SEPIMYCP01A001","SEPIMYCP01A002","SEPIMYCP01A003","SEPIMYCP01A004"

$i = 0
foreach($server in $servers) {$i++; Write-Host $i "-" $server}
#$srcinput = Read-host "Choose source server"
$src = hostname
Echo "Source server is $src"
$destinput = Read-host "Choose destination server"
$dest = $servers[$destinput-1]

Write-Host -Foreground Yellow "This will stop IIS on $dest. CTRL-C to cancel, Enter to continue"
Pause
#$user = Read-Host "Enter credentials for target server (-pa acct)"
$user = $env:UserName

$s = New-PSSession $dest -Credential msnyuhealth\$user

Invoke-Command -session $s { Get-Service -name W3SVC | Stop-Service -Force }

Echo "Copying MyChartJSStrings.js from $src to $dest"
Copy-Item -Path "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\en-US\scripts\MyChartJSStrings.js" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\en-US\scripts\" -Force -ToSession $s
Echo "Copying MyChartJSStrings.min.js from $src to $dest"
Copy-Item -Path "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\en-US\scripts\MyChartJSStrings.min.js" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\en-US\scripts\" -Force -ToSession $s

Echo "Copying CustomStrings from $src to $dest"
Copy-Item -Path "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\CustomStrings\*" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\CustomStrings\" -Force -Recurse -ToSession $s
Echo "Copying CombinedStrings from $src to $dest"
Copy-Item -Path "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\CombinedStrings\*" -Destination "C:\Program Files (x86)\Epic\MyChart\v10.2-MyChart\web\CombinedStrings\" -Force -Recurse -ToSession $s

Echo "Starting IIS on $dest"
Invoke-Command -session $s { Start-Service -name W3SVC }