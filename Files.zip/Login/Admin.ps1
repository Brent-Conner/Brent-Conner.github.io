﻿$servers = Get-Content C:\Input\ProdHSW.txt

Invoke-Command -ComputerName $server {
Add-LocalGroupMember -Group "Administrators" -Member "msnyuhealth\epicprintservice"