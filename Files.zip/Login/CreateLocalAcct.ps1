$pass = "ThomasJeffers0n" | ConvertTo-SecureString -AsPlainText -Force
New-LocalUser -Name grenit01-pa -Password $pass
Add-LocalGroupMember -Group "Administrators" -Member "grenit01-pa"

$pass = "SirBrenth0lameau" | ConvertTo-SecureString -AsPlainText -Force
New-LocalUser -Name conneb02-pa -Password $pass
Add-LocalGroupMember -Group "Administrators" -Member "conneb02-pa"

$pass = "FlannelD@niel" | ConvertTo-SecureString -AsPlainText -Force
New-LocalUser -Name schwed03-pa -Password $pass
Add-LocalGroupMember -Group "Administrators" -Member "schwed03-pa"

$pass = "JefftheRef$" | ConvertTo-SecureString -AsPlainText -Force
New-LocalUser -Name arndtj01-pa -Password $pass
Add-LocalGroupMember -Group "Administrators" -Member "arndtj01-pa"

$pass = "Kuenhasalway$Been" | ConvertTo-SecureString -AsPlainText -Force
New-LocalUser -Name Klee02-pa -Password $pass
Add-LocalGroupMember -Group "Administrators" -Member "Klee02-pa"

$pass = "Ep1c77468$" | ConvertTo-SecureString -AsPlainText -Force
New-LocalUser -Name epicprintservice -Password $pass
Add-LocalGroupMember -Group "Administrators" -Member "epicprintservice"