﻿$servers = Get-Content C:\Input\HSWnew.txt


foreach($server in $servers) {
Write-Host $server
$s = New-PSSession $server
Copy-Item -Path '\\epicfileshare\epicfileshare\Brent\Server2019\sxs\' -Destination 'D:\sources\sxs' -Force -recurse -ToSession $s
Copy-Item -Path '\\epicfileshare\epicfileshare\Brent\Server2019\PreReq.xml' -Destination 'D:\sources\' -Force -recurse -ToSession $s


Invoke-Command -ComputerName $server {
    Set-ExecutionPolicy RemoteSigned -Force
    Enable-PsRemoting -Force
    Add-LocalGroupMember -Group "Administrators" -Member "msnyuhealth\epicprintservice"
    #Enable-NetFirewallRule -DisplayName "Remote Scheduled Tasks Management (RPC)"
    #Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (DCOM-In)"
    #Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (WMI-In)"
    Set-NetFirewallRule -DisplayName "Windows Remote Management (HTTP-In)" -Profile Domain, Private
    powercfg.exe -SETACTIVE 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
    Install-WindowsFeature -ConfigurationFilePath "D:\sources\PreReq.xml" -source "D:\sources\sxs\"
    }
    Write-Host "End Invoke-Command"
}

