Set-ExecutionPolicy -ExecutionPolicy RemoteSigned  
#Enabling SQL Server Ports
New-NetFirewallRule -DisplayName “SQL TCP 1433” -Direction Inbound –Protocol TCP –LocalPort 1433 -Action allow
New-NetFirewallRule -DisplayName “SQL UDP 1434” -Direction Inbound –Protocol UDP –LocalPort 1434 -Action allow