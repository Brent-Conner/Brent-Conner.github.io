﻿$servers = Get-Content C:\Input\ProdHSW.txt
#$servers = Get-Content C:\Input\TestHSW.txt

foreach($server in $servers) {
Write-Host $server
Invoke-Command -ComputerName $server {
    Set-ExecutionPolicy RemoteSigned -Force
    Enable-PsRemoting -Force
    Add-LocalGroupMember -Group "Administrators" -Member "msnyuhealth\epicprintservice"
    Enable-NetFirewallRule -DisplayName "Remote Scheduled Tasks Management (RPC)"
    Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (DCOM-In)"
    Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (WMI-In)"
    Set-NetFirewallRule -DisplayName "Windows Remote Management (HTTP-In)" -Profile Domain, Private
    powercfg.exe -SETACTIVE 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
    }
    Write-Host "End Invoke-Command"

Install-WindowsFeature -cn $server -name Web-AppInit
#Install-WindowsFeature -ComputerName $server -ConfigurationFilePath \\pacfile2\groups\epic\Brent\PS\NewServer\EpicWebServer.xml -Source \\netappb\EpicRA\Independent\sxs\
}