﻿function PRD { start powershell -argumentlist "ssh conneb02@ECDBPRD01.mountsinai.org" }
function SHD { start powershell -argumentlist "ssh conneb02@ECDBSHD01.mountsinai.org" }
function BLD { start powershell -argumentlist "ssh conneb02@ECDBBLD01.mountsinai.org" }
function BLD2 { start powershell -argumentlist "ssh conneb02@DRACO.mountsinai.org" }
function UPG { start powershell -argumentlist "ssh conneb02@ECDBUPG01.mountsinai.org" }
function TEST { start powershell -argumentlist "ssh conneb02@EPICTESTDB.mountsinai.org" }
function REL { start powershell -argumentlist "ssh conneb02@ECDBREL01.mountsinai.org" }
function TRN { start powershell -argumentlist "ssh conneb02@ECDBTRN01.mountsinai.org" }
function CLOUDTRAIN { start powershell -argumentlist "ssh conneb02@zeusnldbtrn001.msnyuhealth.org" }
function CLOUDTEST { start powershell -argumentlist "ssh conneb02@zeusnldbtst001.msnyuhealth.org" }



function Cache
{
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "Cache Servers"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  PRD - ECDBPRD01.mountsinai.org"
	Write-host "2.  SHD - ECDBSHD01.mountsinai.org"
	Write-host "3.  BLD,TST,TSTSAC,TSTVS - ECDBBLD01.mountsinai.org"
    Write-Host "4.  BLD2,UPG,UPGPLY - DRACO.mountsinai.org"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "5.  BLD4,UPG2015 - ECDBUPG01.mountsinai.org"	
    Write-host "6.  TESTPRD - EPICTESTDB.mountsinai.org"
    Write-host "7.  DBA,REL - ECDBREL01.mountsinai.org"
    Write-host "8.  EPICSIM,STAGE,TRN,TRAIN1-5 - ECDBTRN01.mountsinai.org"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "9.  Azure CLOUD TRAIN - zeusnldbtrn001"
    Write-host "10. Azure CLOUD TEST - zeusnldbtst001"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Cyan "/epic/bin/epicmenu"
	$MenuOption = Read-host "Selection"
	
	Switch($MenuOption)
    {
		"1"  {PRD}
		"2"  {SHD}
        "3"  {BLD}
		"4"  {BLD2}
        "5"  {UPG}
        "6"  {TEST}
        "7"  {REL}
        "8"  {TRN}
        "9"  {CLOUDTRAIN}
        "10" {CLOUDTEST}
        default {Continue}
    }
}
Cache