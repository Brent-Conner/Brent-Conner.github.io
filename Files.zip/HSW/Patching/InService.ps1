﻿$dest = "C:\ProgramData\Epic\ECSMTools\Maintenance\"
$in = "D:\Scripts\Patching\InService\status.json"

$health = Invoke-WebRequest https://localhost/Hyperspace_PRD/health/healthHandler.ashx?mode=loadbalancer -skipcertificatecheck | % {$_.StatusCode}

if($health -eq 200) { Copy-Item -Path $in -Destination $dest -Force }