﻿$servers = Get-Content D:\Scripts\_Servers\HSW4thThurs.txt
foreach($server in $servers) {
Invoke-Command -ComputerName $server { New-Item -Path D:\Scripts\Patching\ -Type Directory -Force;  }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\Patching" -Destination D:\Scripts\ -Force -recurse -ToSession $s

Invoke-Command -cn $server { Register-ScheduledTask -TaskName "Drain 4th Thurs" -Xml (Get-Content "D:\Scripts\Patching\Drain4thThurs4pm.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
Invoke-Command -cn $server { Register-ScheduledTask -TaskName "InService 4th Fri" -Xml (Get-Content "D:\Scripts\Patching\InService4thFri3am.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
}