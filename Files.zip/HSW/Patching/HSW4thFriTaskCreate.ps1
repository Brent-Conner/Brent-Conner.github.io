﻿$servers = Get-Content D:\Scripts\_Servers\HSW4thFri.txt
foreach($server in $servers) {
Invoke-Command -ComputerName $server { New-Item -Path D:\Scripts\Patching\ -Type Directory -Force;  }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\Patching" -Destination D:\Scripts\ -Force -recurse -ToSession $s
Sleep 2
Invoke-Command -cn $server { Register-ScheduledTask -TaskName "Drain 4th Fri" -Xml (Get-Content "D:\Scripts\Patching\Drain4thFri4pm.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
Invoke-Command -cn $server { Register-ScheduledTask -TaskName "InService 4th Sat" -Xml (Get-Content "D:\Scripts\Patching\InService4thSat3am.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
Invoke-Command -cn $server { Unregister-ScheduledTask -TaskName "Drain 4th Thurs" -Confirm:$false }
Invoke-Command -cn $server { Unregister-ScheduledTask -TaskName "InService 4th Fri" -Confirm:$false }
}