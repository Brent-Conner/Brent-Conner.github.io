﻿$servers = Get-Content D:\Scripts\_Servers\HSW.txt
$outfile = "D:\Scripts\HSWnewinfo.txt"
"Server^vCPU^RAM (GB)^OS^Processor" | out-file $outfile
foreach($server in $servers)
{
Write-Host $server
$ram = Invoke-Command -ComputerName $server { (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property capacity -Sum).sum / 1gb }
$vcpu = Invoke-Command -ComputerName $server { (Get-WmiObject Win32_ComputerSystem).NumberOfLogicalProcessors }
$cpu = Invoke-Command -ComputerName $server { (Get-WmiObject Win32_Processor).Name[0] }
$os = Invoke-Command -ComputerName $server { ((gcim Win32_OperatingSystem).name) }
$os = $os.split(‘|’)[0]
$disks = Invoke-Command -ComputerName $server { get-wmiobject win32_logicaldisk | Select DeviceID,FreeSpace,Size }
$diskv = $null
foreach($disk in $disks) { $diskv = $diskv + $disk.DeviceID + "^" + ($disk.FreeSpace)/1024/1024/1024 + "^" + ($disk.Size)/1024/1024/1024 + "^"}

$out = $server + "^" + $vcpu + "^" + $ram + "^" + $os + "^" + $cpu + "^" + $diskv
$out | out-file $outfile -append
}