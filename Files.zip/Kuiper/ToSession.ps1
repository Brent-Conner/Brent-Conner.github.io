﻿$src = "D:\MyChart\SEPIMYCP01A003\SSO\*"
$s = New-PSSession SEPIMYCT018001 -Credential SEPIMYCT018001\conneb02-pa 
$dst = "D:\Brent\SEPIMYCP01A003\SSO\"
Copy-Item -Path $src -Destination $dst -ToSession $s -Recurse -Force


