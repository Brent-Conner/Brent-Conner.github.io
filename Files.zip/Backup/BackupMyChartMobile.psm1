﻿function BackupMyChartMobile {

# Global Variables
##################
param([string]$Instance)
$BackupBase = "D:\Backup\"
$BasePath = "D:\Epic\Instances\" 
$Subpaths = ("\Web\")
$SaveFiles = ("web.config")
$Date = Get-Date -Format d | % {$_.replace("/","_")}
$BackupTo = $BackupBase + $Date + "\"
##################

foreach($Subpath in $Subpaths)
{

    foreach($File in $SaveFiles)
    {
    $Path = $BasePath + $Instance + $Subpath
    $CreateDir = $BackupTo + $Path.substring(3)
    If (Test-Path $Path) { New-Item $CreateDir -Type Directory -Force | Out-Null }
    $From = $Path + $File
    $To = $BackupTo + $Path.substring(3)
    Copy-Item $From -Destination $To -Force -Recurse -ErrorAction SilentlyContinue
    }
}
}