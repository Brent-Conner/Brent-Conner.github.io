﻿# Global Variables
##################
$BackupBase = "D:\Backup\"
$PathsWithFiles = ("D:\Epic\Bin\8.3\Epic Print Service\","D:\Epic\Bin\8.3\Epic Print Service\plugins\painters\")
$SaveFiles = ("AppConnection.config","eps.env.config","EpicPrintService.config.xml","EventManager.config.xml","SystemPulse.config.xml","Hyland.Types.dll","OnBasePrinterPlugin.config","OnBasePrinterPlugin.dll")
$Date = Get-Date -Format d | % {$_.replace("/","_")}
$BackupTo = $BackupBase + $Date + "\"
##################

# Functions
function BackupEPS
{
    foreach($Path in $PathsWithFiles)
    {
        $CreateDir = $BackupTo + $Path.substring(3)
        If (Test-Path $Path) { New-Item $CreateDir -Type Directory -Force | Out-Null }
        
        foreach($File in $SaveFiles)
        {
            $From = $Path + $File
            $To = $BackupTo + $Path.substring(3)
            Copy-Item $From -Destination $To -Force -Recurse -ErrorAction SilentlyContinue
        }
    }
}

BackupEPS