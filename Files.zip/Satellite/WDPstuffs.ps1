﻿$servers = Get-Content D:\Scripts\_Servers\wdp.txt
$outfile = "D:\Scripts\wdpquery.txt"
$c = ","

Function Query {
foreach ($server in $servers) {
$wdp = $null
$wdp = Invoke-Command -cn $server -ScriptBlock { Get-WmiObject Win32_product | Where {$_.name -eq "Epic Windows Data Provider"} }
    $out = $server + $c + $wdp.name
    $out
    $out | Out-File $outfile -append
} }

Function Uninstall {
foreach ($server in $servers) {
Invoke-Command -cn $server -ScriptBlock { (Get-WmiObject Win32_product | Where {$_.name -eq "Epic Windows Data Provider"}).Uninstall() }
} }