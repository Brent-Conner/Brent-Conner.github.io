﻿$server = Read-Host "Server"

Invoke-Command -cn $server { New-Item -Path C:\Satellite\ -Type Directory -Force }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\Satellite\*" -Destination C:\Satellite\ -Force -recurse -ToSession $s
Invoke-Command -ComputerName $server -ScriptBlock { C:\Satellite\StandAlone.bat }