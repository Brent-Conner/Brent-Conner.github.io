﻿$source = "\\epicfileshare\epicfileshare\Brent\Copy\*"
$destination = "\\letterimagelogo\LetterImageLogo\Letterimages\"

Move-Item -path $source -destination $destination -force
