﻿#### Paths
#$src = "\\Epicwblobtst\wbsUPG2015\"
#$dst = "\\epicwbs\WBSTST\UPG2015\"
#$src = "\\Epicwblobtst\wbsTSTSAC\"
#$dst = "\\epicwbs\WBSTST\TSTSAC\"
#$src = "\\Epicwblobtst\wbsUPGPLY\"
#$dst = "\\epicwbs\WBSTST\UPGPLY\"
#$src = "\\Epicwblobtst\wbsTSTVS\"
#$dst = "\\epicwbs\WBSTST\TSTVS\"
#$src = "\\Epicwblobtst\wbsREL\"
#$dst = "\\epicwbs\WBSTST\REL\"
#$src = "\\Epicwblobtst\wbsBLD2\"
#$dst = "\\epicwbs\WBSTST\BLD2\"
#$src = "\\Epicwblobtst\wbsSTAGE\"
#$dst = "\\epicwbs\WBSTST\PREP\"
#$src = "\\Epicwblobtst\wbsTRN\"
#$dst = "\\epicwbs\WBSTST\MST\"
#$src = "\\Epicwblobtst\wbstrain5\"
#$dst = "\\epicwbs\WBSTST\ACE5\"
#$src = "\\Epicwblobtst\wbstrain4\"
#$dst = "\\epicwbs\WBSTST\ACE4\"
#$src = "\\Epicwblobtst\wbstrain3\"
#$dst = "\\epicwbs\WBSTST\ACE3\"
#$src = "\\Epicwblobtst\wbstrain2\"
#$dst = "\\epicwbs\WBSTST\ACE2\"
$src = "\\Epicwblobtst\wbstrain1\"
$dst = "\\epicwbs\WBSTST\ACE1\"


#### Email
$from = "wbs@mountsinai.org"
#$recipients = @("Brent.Conner@mountsinai.org","Daniel.Schwetz@mountsinai.org","Thomas.Grenier@mountsinai.org")
$recipients = "Brent.Conner@mountsinai.org"
$start = Get-Date


#foreach($src in $srcs) {
#### Do Stuff
$log = Get-Date -Format "MM_dd_HHmm" #d | % {$_.replace("/","_")}

### Use when copying from old root into new root path -- scenario lined out in Galaxy
#robocopy.exe $src $dst /copyall /sec /e /tee /mt /r:3 /w:1 /dcopy:t /xo /log+:C:\logfile.txt
robocopy.exe $src $dst /copy:DAT /e /tee /mt:32 /r:5 /w:1 /dcopy:t /xo /V /log+:D:\Robocopy\Test\$log.txt

### Use when merging WBS paths from bottom up
#robocopy.exe $src $dst /copy:DAT /is /it /im /e /mt:64 /r:5 /w:1 /dcopy:t /v /log+:D:\Robocopy\Test\$log.txt

#}

$end = Get-Date

