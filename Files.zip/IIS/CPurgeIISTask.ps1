$servers = Get-Content D:\Scripts\_Servers\cloudtrain.txt
foreach($server in $servers) {
Invoke-Command -ComputerName $server { New-Item -Path C:\Scripts\ -Type Directory -Force }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\IIS\PurgeIIS.ps1" -Destination C:\Scripts\ -Force -recurse -ToSession $s
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\IIS\CPurgeIIS.xml" -Destination C:\Scripts\ -Force -recurse -ToSession $s

Invoke-Command -cn $server { Register-ScheduledTask -TaskName "Purge IIS" -Xml (Get-Content "C:\Scripts\CPurgeIIS.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
}