# Delete all files older than 14 days
$IISpath = "C:\inetpub\logs\LogFiles\W3SVC1\"
$Days = "-14"
$CurrentDate = Get-Date
$DatetoDelete = $CurrentDate.AddDays($Days)
Get-ChildItem $IISpath -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse