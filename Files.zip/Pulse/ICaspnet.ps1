﻿# Delete Temp ASP NET files from previous CP versions
$servers = ("ZWTSTEPICIFC11","ZWTSTEPICIFC12","ZWPDCEPICIFC11","ZWPDCEPICIFC12","ZWPDCEPICIFC13","ZWPDCEPICIFC14")


foreach($server in $servers) {
$aspnet = "\\$server\C$\Windows\Microsoft.NET\Framework64\v4.0.30319\Temporary ASP.NET Files\"
$paths = Get-ChildItem $aspnet -Directory
    foreach($path in $paths) {
        if($path -match "interconnect") {
        $path = $aspnet + $path
        Get-ChildItem $path -Directory | Sort-Object CreationTime -Descending | Select-Object -Skip 1 | Remove-Item -Recurse -Force
        }
    }
}