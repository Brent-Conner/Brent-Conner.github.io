﻿$servers = ("ZWTSTEPICBCW11","ZWPDCEPICBCW11","ZWPDCEPICBCW12")
$Daysback = "-1"
$CurrentDate = Get-Date
$DatetoEmail = $CurrentDate.AddDays($Daysback)

foreach($server in $servers) {
$Path = "\\$server\d$\Epic\Data\Epic BCA Client\_users_.emp"
Get-ChildItem $Path -File -Recurse | Where-Object { $_.LastWriteTime -lt $Datetoemail } | Send-MailMessage -to "ecsm@phs.org" -from $server@phs.org -subject "TEST 2 User's file date is $datetoemail" -SmtpServer imr2.phs.org
}