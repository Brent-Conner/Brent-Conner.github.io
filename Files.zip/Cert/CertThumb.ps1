﻿$thumb = Read-Host "Thumprint"
Get-ChildItem -path "Cert:\*$thumb" -Recurse