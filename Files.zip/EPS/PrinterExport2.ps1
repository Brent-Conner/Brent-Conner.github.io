﻿#$Printservers = ("EPICTROY64")
$Printservers = ("ZWPDCEPICEPS01")
#$Printservers = ("ZWPDCEPICEPS01","EPICTROY64")

# Create new Excel workbook
cls
$Excel = New-Object -ComObject Excel.Application
$Excel.Visible = $True
$Excel = $Excel.Workbooks.Add()
$Sheet = $Excel.Worksheets.Item(1)
$Sheet.Name = "Printer Inventory"
#======================================================
$Sheet.Cells.Item(1,1) = "Print Server"
$Sheet.Cells.Item(1,2) = "Printer Name"
$Sheet.Cells.Item(1,3) = "Driver Name"
$Sheet.Cells.Item(1,4) = "Port"
#=======================================================
$intRow = 2
$WorkBook = $Sheet.UsedRange
$WorkBook.Interior.ColorIndex = 40
$WorkBook.Font.ColorIndex = 11
$WorkBook.Font.Bold = $True
#=======================================================

# Get printer information
ForEach ($Printserver in $Printservers)
{   $Printers = Get-WmiObject Win32_Printer -ComputerName $Printserver

    ForEach ($Printer in $Printers)
    {
        if ($Printer.Name -notlike "Microsoft XPS*")
        {
            $Sheet.Cells.Item($intRow, 1) = $Printserver
            $Sheet.Cells.Item($intRow, 2) = $Printer.Name
            $Sheet.Cells.Item($intRow, 3) = $Printer.DriverName
            $Sheet.Cells.Item($intRow, 4) = $Printer.PortName
            $intRow ++
        }
    }
    $WorkBook.EntireColumn.AutoFit() | Out-Null
}
 

$intRow ++ 
$Sheet.Cells.Item($intRow,1) = "Printer inventory completed"
$Sheet.Cells.Item($intRow,1).Font.Bold = $True
$Sheet.Cells.Item($intRow,1).Interior.ColorIndex = 40
$Sheet.Cells.Item($intRow,2).Interior.ColorIndex = 40