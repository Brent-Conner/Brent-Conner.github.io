﻿$EPSservers = ("ZWPDCEPICEPS01","ZWPDCEPICEPS02","ZWPDCEPICEPS03","ZWPDCEPICEPS04","ZWPDCEPICEPS05","ZWPDCEPICEPS06")
$binlocation = "D:\Scripts\PrinterBin\"

function DeleteOld
{
    $printers = Get-Content \\pacfile2\groups\epic\brent\input\off.txt
    foreach($server in $EPSservers) { Remove-Printer -computername $server -name $printers }
}

function ApplyBin
{
    $printers = Get-Content \\pacfile2\groups\epic\brent\input\bin.txt
    $i = 0
    $binlist = Get-ChildItem $binlocation -File
    foreach ($bin in $binlist) { Write-Host "$i  - $bin" ; $i++ }
    $MenuOpt = Read-Host "Choose bin to apply"
    $binfile = $binlocation + $binlist[$MenuOpt]
    
    write-host $binfile
    $traycommand='rundll32 PrintUI.dll,PrintUIEntry /Sr /n "\\$server\$printid" /a "$binfile" d g u r p'
    Write-Host "Applying $binfile to $printid"
    #Invoke-Expression $traycommand 

}