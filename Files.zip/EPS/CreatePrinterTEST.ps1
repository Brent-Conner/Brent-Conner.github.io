#This script creates printers in a loop on several servers and is designed to run on the console.

#Create Printer function
function CreatePrinter {
$server = $args[0]
$print = ([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
$print.DeviceID = $args[3] 
$print.Delete() 
 
$print = ([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance() 
$print.drivername = $args[1]
$print.PortName = $args[2]
$print.Shared = $false
$print.EnableBIDI = $false
$print.DoCompleteFirst = $true
$print.RawOnly = $true
$print.Sharename = $args[3]
$print.DeviceID = $args[3]
$date = Get-Date
$print.Comment = "Created by Powershell Script on " + $date
write-host "Creating" $args[3] "on" $args[0] "with driver" $args[1]
$print.Put() 
}

#Create Printer Port function
function CreatePrinterPort {
$server =  $args[0] 
$port = ([WMICLASS]"\\$server\ROOT\cimv2:Win32_TCPIPPrinterPort").createInstance() 
$port.Name= $args[1]
$port.SNMPEnabled=$false 
$port.Protocol=1 
$port.HostAddress= $args[1] 
write-host "Creating port" $args[1] "on" $args[0]
$port.Put() 
}

# Delete the Registry Key given in $deleteKey
Function DeleteRegKey
{
$type = [Microsoft.Win32.RegistryHive]::Users
$Hive = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($type, $args[0])
$objUser = New-Object System.Security.Principal.NTAccount($domain, $epsuser) 
$strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier]) 
$sid = $strSID.Value
$Key = $Hive.OpenSubKey($sid + "\Printers\DevModePerUser", $true)
$Key.DeleteValue($args[1])
}

#Check if printer is in dns/online and driver is valid
function ValidateEntry {
$printertocheck = $args[0]
$drivertocheck = $args[1]
$porttocheck = $printertocheck + $fqdn
$dnscheck = test-connection -computername $porttocheck -count 1 -quiet
If(!$dnscheck){
write-host $porttocheck "is not in DNS or online. Skipping..."
return $true
}
$drivers = Get-WmiObject -Class Win32_PrinterDriver -ComputerName $serverwithdriverlist
foreach($driverlongname in $drivers){
	$driver=$driverlongname.Name -replace ',3,Windows x64',''
	If($drivertocheck -eq $driver){return $True}
}
write-host $drivertocheck "is not a valid driver.  Skipping" $printertocheck "..."
return $False
}

#Creates Bin file for driver/tray combo
#Asks user to configure and exports settings to create bin
function CreateBinFile {
$server = $args[0]
$printerfull = $args[1]
$binlocation = $args[2]
printui.exe /n \\$server\$printerfull /p
read-host "A binary file for this driver doesn't exist.  Please set the defaults for this printer, save and close the window, then press ENTER"
$createbincommand = 'rundll32 PrintUI.dll,PrintUIEntry /Ss /n \\'+ $server + '\' + $printerfull + ' /a "' + $binlocation + '"' 
write-host "Saving defaults to" $binlocation
invoke-expression $createbincommand
Start-Sleep -s 3
}

#Imports tray settings for printer/driver
function SetBinFile {
$server = $args[0]
$printerfull = $args[1]
$binlocation = $args[2]
start-sleep 3
$traycommand = 'rundll32 PrintUI.dll,PrintUIEntry /Sr /n \\'+ $server + '\' + $printerfull + ' /a "' + $binlocation + '" r d u g'
write-host "Setting defaults to" $printerfull
invoke-expression $traycommand
}

function FindERTF{
$file = $args[0]
$folders = @("Failed","Incoming","Processed")
ForEach($server in $ertfservers){
ForEach($folder in $folders){
$path = "\\" + $server + "\c$\Epic\Jobs\" + $folder + "\7.8.6\Epic Print Service\" + $file
$result = Test-Path $path
If($result -eq $True){invoke-item $path}
}
}
return $False
}

##########################################################################################################
#Set our servers and locations
$serverwithdriverlist = "Epic2010EPS1"
$servers = @("Epic2010EPS1")
$ertfservers = @("EpicEPS1","EpicEPS2","EpicEPS3","Epic2010EPS")
$binlocation = "c:\Scripts\Bin"
$fqdn = ""
#$epsuser=""
#$domain=""
##########################################################################################################

#Infinate Loop
while(1){

#Asks for the printer or batch
#If batch, ask for csv path and check it
#If it exists, import printers from file
$printerentry = read-host "Enter the Printer Name"
If($printerentry -eq "ertf"){
$ertffile = read-host "Enter the name of the ERTF file you are looking for"
FindERTF $ertffile
Continue
}
If($printerentry -eq "batch"){
$csvpath = read-host "Enter the path to the csv file"
$csvpath = $csvpath.replace('"','')
$testpath = Test-Path($csvpath)
If($testpath -eq $False){
write-host "There is no csv file at that location."
continue}
$printers = Import-Csv $csvpath
}

#If not batch, ask for driver from list (pulled for $serverwithdriverlist)
Else{
$printeripaddress = read-host "Enter the IP address"
$menu="Select the driver from the following list:`r`n"
$drivers = Get-WmiObject -Class Win32_PrinterDriver -ComputerName $serverwithdriverlist
$i=1
foreach($driverlongname in $drivers)
{
    $driver=$driverlongname.Name -replace ',3,Windows x64',''
    write-host $i': '$driver
    $i++
}

$selection = read-host "Selection: "
$driverselection = $drivers[$selection-1].Name -replace ',3,Windows x64',''

#Ask for type of trays
$ExtraTray = read-host "What type?  1: Plain  2: 30 Up Labels"

#Ask what tray labels are in if building a label tray
If($ExtraTray -eq '2'){$labeltray = read-host "What tray are labels in?"}

#Setup single item array for create loop
$printers = @{}
$printers.PrinterName = $printerentry.ToUpper()
$printers.PrinterIPAddress = $printeripaddress
$printers.DriverName = $driverselection
$printers.ExtraTray = $ExtraTray
$printers.LabelTray = $labeltray
}

#For each item in printers
#Validate printer is online and driver exists
ForEach ($printer in $printers) {
#$result = ValidateEntry $printer.PrinterName $printer.DriverName
#If($result -eq $False){Continue}

$driver = $printer.Drivername
$ExTray = $printer.ExtraTray
$port = $printer.PrinterIPAddress
$LabelTray = $printer.LabelTray


#For each server
Foreach($server in $servers)
{
#Create Port
CreatePrinterPort $server $port
$printerfull = $printer.PrinterName.ToUpper()
$printerfull = $printerfull + '-EPIC'

If($ExTray -ne '2'){

#$binfullpath = $binlocation + $driver + '.bin'
CreatePrinter $server $driver $port $printerfull
#$result = Test-Path $binfullpath
#If ($result -eq $False){CreateBinFile $server $printerfull $binfullpath}
#Else{SetBinFile $server $printerfull $binfullpath}
#DeleteRegKey $server $printerfull
#$bidicommand = 'rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server + '\' + $printerfull + ' attributes -EnableBidi'
#write-host "Disabling BiDirctional Support for" $printerfull
#invoke-expression $bidicommand
}

If($ExTray -eq '2'){

$printerfull = $printerfull + "30UP"
$binfullpath = $binlocation + $driver + '_' + $LabelTray + '.bin'
$binfullpath = $binfullpath.replace("/","_")
CreatePrinter $server $driver $port $printerfull
$result = Test-Path $binfullpath
If ($result -eq $False){CreateBinFile $server $printerfull $binfullpath}
Else{
Start-Sleep -s 3
SetBinFile $server $printerfull $binfullpath}
#DeleteRegKey $server $printerfull
#$bidicommand = 'rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server + '\' + $printerfull + ' attributes -EnableBidi'
#write-host "Disabling BiDirectional Support for" $printerfull
#invoke-expression $bidicommand

}
}
}
}