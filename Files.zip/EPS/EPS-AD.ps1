﻿function QueryAD
{
    $Printers = Get-Printer -ComputerName 'ZWPDCEPICEPS11' | Select Name, PortName, DriverName # | Export-Csv C:\Output\Printers.csv
    $Ports = $Printers.PortName

    $i = 0
    foreach($Port in $Ports)
    {
        if($port -notmatch 'epic'){$ADprinter = Get-AdObject -filter "objectCategory -eq 'printqueue'" -Properties portname,location | Where { $_.portname -match $Port } | Select location, portname}
        #$Port = $Port -replace 'IP_','' -replace '_1','' -replace '_2',''
        #$Port = $ADprinter.portname -replace 'IP_','' -replace '_1',''
        $loc = $ADprinter.location
        
        [string]$out = $Printers[$i].Name + "," + $Port + "," + $loc + "," + $Printers[$i].Drivername
        $out = $out -replace ' ',''
        $out
        $out | Out-File C:\Output\adlocation.txt -append
        $i++
    }
}

QueryAD