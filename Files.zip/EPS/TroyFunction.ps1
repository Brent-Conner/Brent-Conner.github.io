﻿$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")

function TroyConfigTransfer
{
    #$Num = 1
    #foreach($server in $EPSservers) { Write-Host $Num - $server; $Num++ }
    #$Choice = Read-Host "Choose source server"
    #$SrcServer = $EPSServers[$Choice-1]
    #$TroyPort = Read-Host "Troy Port"

    $TroyPort = 1
    while($TroyPort -lt 501)
    {
    [xml]$SrcPantoFile = Get-Content -Path "\\epictroy64\c$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPantographConfiguration.xml"
    [xml]$SrcPrinterFile = Get-Content -Path "\\epictroy64\c$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPortMonitorConfiguration.xml"

    $DestPanto = "\\zwpdcepiceps11\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPantographConfiguration.xml"
    $DestPrinter = "\\zwpdcepiceps11\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPortMonitorConfiguration.xml"
    [xml]$DestPantoFile = Get-Content -Path $DestPanto
    [xml]$DestPrinterFile = Get-Content -Path $DestPrinter
    
    $Counter = 0
    while($Counter -lt 4)
    {
        $SrcDark = $SrcPantoFile.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].BgDarknessFactor
        $SrcDensity1 = $SrcPantoFile.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].DensityPattern1
        $SrcDensity2 = $SrcPantoFile.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].DensityPattern2
                
        $DestPantoFile.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].BgDarknessFactor = $SrcDark
        $DestPantoFile.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].DensityPattern1 = $SrcDensity1
        $DestPantoFile.PantographConfiguration.PantographConfigurations.CustomConfiguration[$Counter].DensityPattern2 = $SrcDensity2
        $DestPantoFile.Save("$DestPanto")
               
        $Counter++
    }
    $SrcPrinter = $SrcPrinterFile.TroyPortMonitorConfiguration.DefaultPrinter
    $DestPrinterFile.TroyPortMonitorConfiguration.DefaultPrinter = $SrcPrinter
    $DestPrinterFile.Save("$DestPrinter")
    Write-Host $TroyPort
    $TroyPort++
    }
}

TroyConfigTransfer