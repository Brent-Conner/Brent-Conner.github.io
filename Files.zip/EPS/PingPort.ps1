﻿    $date = Get-Date -Format d | % {$_.replace("/","_")}
    $ports = Get-Content C:\Input\ports.txt
    foreach($port in $ports)
    {
        Write-Host "Testing -- $port"
        if(Test-Connection -ComputerName $port -count 1 -ea SilentlyContinue) { $status = "Success" } Else { $status = "Fail" }
        $output = $port + "," + $status + "," + $date
        $output | Out-File C:\output\ping.csv -Append
    }