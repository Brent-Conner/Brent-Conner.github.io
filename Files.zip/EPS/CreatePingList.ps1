﻿function CreateList
{
    $server = Read-Host "Server"
    $offprinters = Get-Printer | Select Name,PortName,PrinterStatus | Where { $_.Name -notmatch "Troy_RX" }

    foreach($printer in $offprinters)
    {
        $port = $printer.portname
        $name = $printer.name
        if($port -match "_OM") { $port = $port -replace ".{6}$" }
        Write-Host "Testing -- $name -- $port"
        if(Test-Connection -ComputerName $port -count 1 -ea SilentlyContinue) { $status = "Success" } Else { $status = "Fail" }
        $output = $name + "," + $port + "," + $status
        $output | Out-File D:\scripts\ping.csv -Append
    }
}

function PingPort
{
    $date = Get-Date -Format d | % {$_.replace("/","_")}
    $ports = Get-Content C:\Input\ports.txt
    foreach($port in $ports)
    {
        Write-Host "Testing -- $port"
        if(Test-Connection -ComputerName $port -count 1 -ea SilentlyContinue) { $status = "Success" } Else { $status = "Fail" }
        $output = $port + "," + $status + "," + $date
        $output | Out-File C:\output\ping.csv -Append
    }
    Break
}
