﻿function CreatePrinterPort {
	$server = $args[0] 
	$port = ([WMICLASS]"\\$server\ROOT\cimv2:Win32_TCPIPPrinterPort").createInstance() 
	$port.Name = $args[1]
	$port.SNMPEnabled = $false 
	$port.Protocol = 1 
	$port.HostAddress = "10.243.4.43"
	$port.PortNumber = $args[2] 
	write-host "Creating port" $args[1] "on" $args[0]
	$port.Put() 
	}

function CreatePrinter {
	$server = $args[0]
	$print = ([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	$print.DeviceID = $args[3] 
	$print.Delete() 
	$print = ([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance() 
	$print.drivername = $args[1]
	$print.PortName = $args[2]
	$print.Shared = $false
	$print.Sharename = $args[3]
	$print.DeviceID = $args[3]
	$print.Comment = "Created with port: " + $args[2]
	write-host "Creating" $args[3] "on" $args[0] "with driver" $args[1]
	$print.Put() 
	}


#########################################
$servers = @("Epic2010EPS1")
$driver = "HP LaserJet 4"
#########################################

while(1)
{

	$epr = read-host "Enter the EPR"
	$portnumber = read-host "Enter the Port (ex. 9600)"
	$portname = "10.243.4.43_" + $portnumber
	$printerfull = "MROWP" + $epr + "-EPIC"

	Foreach($server in $servers)
	{
		CreatePrinterPort $server $portname $portnumber
		CreatePrinter $server $driver $portname $printerfull
		$bidi='rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server+'\'+$printerfull+' attributes -EnableBidi'
		#$shared='rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server+'\'+$printerfull+' attributes -Shared'
		$queued='rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server+'\'+$printerfull+' attributes +Queued'
		$spool1='rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server+'\'+$printerfull+' attributes +DoCompleteFirst'
		$advfeat='rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\'+ $server+'\'+$printerfull+' attributes +RawOnly'
		invoke-expression $bidi
		#invoke-expression $shared
		invoke-expression $queued
		invoke-expression $spool1
		invoke-expression $advfeat
		#cd C:\Windows\System32\Printing_Admin_Scripts\en-US\
		#cscript prncnfg.vbs -t -s $server -p $printerfull +docompletefirst
	}
}