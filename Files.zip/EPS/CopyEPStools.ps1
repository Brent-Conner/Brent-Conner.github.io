﻿$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")
foreach($server in $EPSservers)
{ Write-Host "Copying to $server"; Copy-Item -Path '\\pacfile2\groups\epic\Brent\PS\EPSTools.ps1' -Destination \\$server\d$\scripts\ -Force }