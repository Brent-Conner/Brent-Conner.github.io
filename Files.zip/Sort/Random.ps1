$servers = Get-Content C:\Input\epst.txt
foreach ($server in $servers) {
Copy-Item -path "\\bhcs.pvt\dfsdept\EpicTech\Software\Zebra\ZD8-6-2-22850\" -Recurse -Destination "\\$server\c$\_installs\" -Force
}

foreach ($server in $servers) {
#Invoke-Command -cn $server { & cmd /c "msiexec.exe /i C:\_Installs\ECSMMSUrlRewrite2.msi" /qn } }

#Invoke-Command -cn $server { & cmd /c RUNDLL32 PRINTUI.DLL,PrintUIEntry /ia /f "C:\_Installs\ZD8-6-2-22850\ZDesigner.inf" /m "ZDesigner ZT411-203dpi ZPL" } }
