﻿#$pc = Read-Host "Silver tag"

$pcs = Get-Content -Path C:\Input\BCAs.txt

foreach($pc in $pcs) {
$session = New-PSSession $pc
$pc
if(Test-NetConnection -ComputerName $pc -InformationLevel Quiet) {
Invoke-Command -Session $session -Command {Remove-Item 'C:\Users\Public\Desktop\BCA Printing.lnk'} -ErrorAction SilentlyContinue
Invoke-Command -Session $session -Command {Remove-Item 'C:\Users\Presbyterian\Desktop\BCA Printing.lnk'} -ErrorAction SilentlyContinue
}

else { Write-Host "Offline $pc"
$pc | Out-File C:\Output\BCAoff.txt -Append }

}