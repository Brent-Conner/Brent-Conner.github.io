$servers = Get-Content -Path C:\input\testnoon.txt

Function Reboot {
foreach($server in $servers) {
Write-Host "Restarting $server"
#Test-Connection -ComputerName $server -count 1
Restart-Computer -ComputerName $server -Force
} }

Function GetKB {
foreach($server in $servers) {
Write-Host $server
Get-hotfix -ComputerName $server | where { $_.installedon -contains "3/11/2020" }
Get-hotfix -ComputerName $server | where { $_.installedon -contains "3/10/2020" }
} }