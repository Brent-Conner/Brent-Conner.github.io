﻿#$servers = Get-Content C:\Input\TestHSW.txt
$servers = Get-Content C:\Input\ProdHSW.txt

foreach($server in $servers) {
Write-Host "***************** $server start ********************"

Invoke-Command -ComputerName $server { New-Item -Path D:\Certs\ -Type Directory -Force }
$s = New-PSSession $server
Copy-Item -Path "\\pacfile2\groups\epic\brent\ps\newserver\EpicHSW.pfx" -Destination D:\Certs\ -Force -recurse -ToSession $s

Invoke-Command -cn $server {
    Import-PfxCertificate -FilePath "D:\Certs\EpicHSW.pfx" -Password (ConvertTo-SecureString -String "EpicTLS" -AsPlainText -Force) -CertStoreLocation Cert:\LocalMachine\My -Exportable
    New-WebBinding -Name "Default Web Site" -Port 443 -Protocol https;
    $cert = Get-ChildItem -Path Cert:\LocalMachine\My | where-Object {$_.subject -like "*EpicHSW.phs.org*"};
    (Get-WebBinding -Port 443).AddSslCertificate($cert.Thumbprint,"My")
    }
Write-Host "***************** $server end ********************"
}