﻿Invoke-Command -cn ZWPDCEPICWEB11 -credential zwpdcepicweb11\bconner_a { 
Get-EventLog -LogName Application -After '11/7/2018 1:00:00 PM' -Source VBRuntime }