﻿# Delete all files older than 7 days
$servers = Get-Content D:\Scripts\servers.txt

foreach($server in $servers) {
$Path = "\\$server\C$\inetpub\logs\LogFiles\W3SVC1\"
$Days = "-7"
$CurrentDate = Get-Date
$DatetoDelete = $CurrentDate.AddDays($Days)
Get-ChildItem $Path -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse
}