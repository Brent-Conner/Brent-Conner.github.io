﻿#$server = Read-Host "Server"
$servers = Get-Content -path D:\Scripts\servers.txt

#Copy sxs folder to server and install Pre-reqs
foreach($server in $servers) {
$s = New-PSSession $server
Copy-Item -Path 'D:\Server2019\sources\sxs\' -Destination 'D:\sources\sxs' -Force -recurse -ToSession $s
Copy-Item -Path 'D:\Server2019\sources\PreReq.xml' -Destination 'D:\sources\' -Force -recurse -ToSession $s
Invoke-Command -ComputerName $server { Install-WindowsFeature -ConfigurationFilePath "D:\sources\PreReq.xml" -source "D:\sources\sxs\" }
}