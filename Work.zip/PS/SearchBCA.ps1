﻿$PC = Read-Host "Enter silver tag"

$BCAsource = "\\blobcifs\epicblob$\BCA\Outgoing\PROD\IC\-P\HS\-P\RD\-2\"
$Files = Get-ChildItem $BCAsource -Recurse | Where-Object {$_.Mode -match "a"} | $Path = $Files.Fullname | Get-Content $Path | Select-String $PC 

foreach($File in $Files)
{
$Path = $File.FullName
$Search = Get-Content -Path $Path -ErrorAction SilentlyContinue | Select-String -Pattern $PC
$Search
If($Search) {Invoke-Item $Path; Pause}
}
