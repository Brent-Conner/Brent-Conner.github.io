$date = Get-Date -Format "MM_dd_HHmm" #d | % {$_.replace("/","_")}
$dumpcap = “C:\Program Files\Wireshark\dumpcap.exe”
$arguments = “-a duration:240 -i 1 -b filesize:200000 -w \\bhcs.pvt\dfsdept\EpicTech\Scripts\EPS\Dumpcap\$date.pcap”
Start-Process -filepath $dumpcap -argumentlist $arguments