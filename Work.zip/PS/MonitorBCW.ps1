﻿$recipients = ("bconner@phs.org","jdiedrich@phs.org")
$BCWservers = ("ZWPDCEPICBCW11","ZWPDCEPICBCW12","ZWTSTEPICBCW11")
$max = "100"

	foreach ($server in $BCWservers)
	{
		$sender = $server + "@phs.org"
		$folder = get-childitem -Path "\\$server\d$\Epic\Jobs\Incoming\Epic BCA Client" -recurse | Measure-Object
		$count = $folder.count
		write-host "$server has $count jobs"

		#if ($count -ge $max) { }
        Send-Mailmessage -to $recipients -from $sender -Subject "$server has $count jobs in the incoming folder." -body "PS script is running on Pulse server by a scheduled task. D:\Scripts\MonitorBCW.ps1" -SmtpServer "imr2.phs.org"
	}