﻿$pc = Read-Host "Silver tag"

#$pcs = Get-Content -Path C:\Input\BCAs.txt

#foreach($pc in $pcs) {

$session = New-PSSession $pc
Write-Host "Attempting to copy to $pc"
Copy-Item -Path '\\pacfile2\groups\epic\Technical Team\BCA\May2020shortcut\BCA Printing.lnk' -Destination C:\Users\Public\Desktop -Force -ToSession $session

#}