﻿function BCAconfig
{
Copy-Item -Path '\\blobcifs\epicblob$\BCA\Outgoing\BCA Printing - 2017.lnk' -Destination C:\Users\Public\Desktop -Force
}