﻿# Global Variables
##################
$WinRM = ("WinRM")
#$PCs = Get-Content -Path C:\Input\pcs.txt

# Do Stuff
##################
While(1)
#foreach($pc in $pcs)
{
$PC = Read-Host "Silver Tag"
If (Test-Connection -ComputerName $PC -Count 2 -Quiet)
{
Write-Host -foreground green "Starting $WinRM on $PC"
Get-Service -ComputerName $PC -Name $WinRM | Restart-Service -Force
Write-Host -foreground green "Setting $WinRM startup type to automatic on $PC"
Set-Service -ComputerName $PC -Name $WinRM -StartupType Automatic
$status = Get-Service -ComputerName $PC -Name $WinRM
Write-Host "Final settings on $PC"
Write-Host $status.status $status.name $status.StartType
Invoke-Command -ComputerName $pc { 
net user Presbyterian 'Pre$byterian1' /add
net localgroup administrators Presbyterian /add
}
}
Else { Write-Host "Failed to Connect to $PC" }
}