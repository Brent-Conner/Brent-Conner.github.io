﻿# Delete all files older than 4 days
$Path = "\\blobcifs\epicwbs$\PRD\WBS_Stor\Epic\Images\pr\NT\-P\HS\-B\AT\CH\-7\03"
$Daysback = "-7"
$CurrentDate = Get-Date
$DatetoDelete = $CurrentDate.AddDays($Daysback)
Get-ChildItem $Path -File -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse