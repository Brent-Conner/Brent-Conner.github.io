﻿##### Requires Powershell 6 for -skipcertificatecheck, or you can include the server names in the SAN (as with non-prod servers)

Write-Host "EpicWelcome.phs.org"
(Invoke-WebRequest -Uri "https://epicwelcome.phs.org/welcomeweb_phs-prd/serverhealth/getoverallstatus" -skipcertificatecheck).StatusDescription
Write-Host "ZWPDCEPICIFC13"
(Invoke-WebRequest -Uri "https://ZWTSTEPICIFC22.phs.org:6443/welcomeweb_phs-tst/serverhealth/getoverallstatus" -skipcertificatecheck).StatusDescription
Write-Host "ZWPDCEPICIFC14"
(Invoke-WebRequest -Uri "https://ZWTSTEPICIFC23.phs.org:6443/welcomeweb_phs-tst/serverhealth/getoverallstatus" -skipcertificatecheck).StatusDescription
