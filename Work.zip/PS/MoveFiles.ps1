﻿# Move files older than 14 days
$From = "D:\Stanson_Health_Extract_Files\*"
$To = "\\netappb\EpicRW\clarity\Stanson_Health_Extract_Files"
$DaysOld = "-14"
$CurrentDate = Get-Date
$DateVar = $CurrentDate.AddDays($DaysOld)
Get-ChildItem $From -Include *.dat | Where-Object { $_.LastWriteTime -lt $DateVar } | Move-Item -Destination $To -Force