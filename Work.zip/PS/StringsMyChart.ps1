﻿$servers = ("ZWTSTEPICWEB11","ZWTSTEPICWEB12")

$i = 0
foreach($server in $servers) {$i++; Write-Host $i "-" $server}
$srcinput = Read-host "Choose source server"
$src = $servers[$srcinput-1]
$destinput = Read-host "Choose destination server"
$dest = $servers[$destinput-1]

    if($src -ne $dest)
    {
    Write-Host "Copying MyChartJSStrings.js from $src to $dest"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\MyChartJSStrings.js" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\" -Force
    Write-Host "Copying MyChartJSStrings.min.js from $src to $dest"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\MyChartJSStrings.min.js" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\" -Force
    
    Write-Host "Copying v8.3-Custom\asp\CustomStrings from $src to $dest"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\CustomStrings\" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\" -Force -Recurse
    Write-Host "Copying v8.3-Custom\asp\CombinedStrings from $src to $dest"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\CombinedStrings\" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\" -Force -Recurse
    }
    
    Write-Host "Copying MyChartJSStrings.js from $src \v8.3-Source to $dest \v8.3-Custom"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\MyChartJSStrings.js" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\en-US\scripts\" -Force
    Write-Host "Copying MyChartJSStrings.min.js from $src \v8.3-Source to $dest \v8.3-Custom"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\MyChartJSStrings.min.js" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\en-US\scripts\" -Force

    Write-Host "Copying MyChartJSStrings.js from $src \v8.3-Source to $dest \v8.3-PHS-TST"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\MyChartJSStrings.js" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-PHS-TST\asp\en-US\scripts\" -Force
    Write-Host "Copying MyChartJSStrings.min.js from $src \v8.3-Source to $dest \v8.3-PHS-TST"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Source\asp\en-US\scripts\MyChartJSStrings.min.js" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-PHS-TST\asp\en-US\scripts\" -Force

    Write-Host "Copying CustomStrings from $src Custom to $dest Working"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\CustomStrings\" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-PHS-TST\asp\" -Force -Recurse
    Write-Host "Copying CombinedStrings from $src Custom to $dest Working"
    Copy-Item -Path "\\$src\d$\Program Files (x86)\Epic\MyChart\v8.3-Custom\asp\CombinedStrings\" -Destination "\\$dest\d$\Program Files (x86)\Epic\MyChart\v8.3-PHS-TST\asp\" -Force -Recurse
