$servers = Get-Content C:\input\cew.txt
foreach($server in $servers) {
$server
Invoke-Command -computername $server { Invoke-RestMethod http://ipinfo.io/json | Select -exp ip }
}