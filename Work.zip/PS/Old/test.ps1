$a = "phsnt\bconner_a"
$c = Get-Credential $a
Start-Process $PsHome\powershell.exe -Credential $c -ArgumentList �-Command Start-Process $PSHOME\powershell_ise.exe -Verb Runas� -Wait
