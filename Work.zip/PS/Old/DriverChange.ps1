$printers = gwmi win32_printer
$drivernames = get-wmiobject -class win32_printerdriver
$i = -1
foreach($drivername in $drivernames) {$driver = $drivername.name -replace ',3,Windows x64','';$i++; write-host $i "-" $driver}
$old = Read-host "Choose old driver to replace"
$new = Read-host "Choose new driver"
$newdriver = $drivernames[$new].Name -replace ',3,Windows x64'
$olddriver = $drivernames[$old].Name -replace ',3,Windows x64'

foreach($printer in $printers)
{
	$name = $printer.name
    if($printer.drivername -eq $olddriver)
	{
		write-host "Changing $name to driver $newdriver"
		$change = 'rundll32 PrintUI.dll,PrintUIEntry /Xs /n $name DriverName $newdriver'
		invoke-expression $change
		start-sleep -s 10
    }
}