﻿$recipients = ("bconner@phs.org") ##,"gburke@phs.org")
$servers = ("ZWPDCEPICEPS01","ZWPDCEPICEPS02","ZWPDCEPICEPS03","ZWPDCEPICEPS04","ZWPDCEPICEPS05")
$sleep = "300"
$max = "5"

while(1)
{	
$date = Get-Date
write-host $date

	foreach ($server in $servers)
	{
		$sender = $server + "@phs.org"
		$folder = get-childitem -Path "\\$server\d$\Epic\Jobs\Incoming\8.1\Epic Print Service" -recurse | Measure-Object
		$count = $folder.count

		write-host "Counting print jobs on $server"

		if ($count -ge $max)
		{
			write-host "Sending email for $server -- $date"
			Send-Mailmessage -to $recipients -from $sender -Subject "$server has $count jobs waiting to print." -body "$server has $count jobs in the incoming folder." -SmtpServer "imr2.phs.org"
		}

	}
write-host "Counting complete,  sleeping for $sleep seconds"
Start-Sleep -s $sleep
}
