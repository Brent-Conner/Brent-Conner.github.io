$get = Get-ChildItem -Force \\blobcifs\epicblob$\BCA\Outgoing
$names = $get | Select Name
$singles = $names | Select-String Name
$output = $singles -replace ".*=" -replace "}.*"

foreach ($one in $output)
{
# Write-Host "Restarting pull service on $one"
Get-Service -ComputerName $one -Name EpicPullService81 | Restart-Service -Force
}