$ertfservers = @("EPICEPS1","EPICEPS2","EPICEPS3","EPIC2010EPS","EPICEPS4")
while(1){
$file = read-host "Enter the name of the ERTF file you are looking for"
$folders = @("Failed","Incoming","Processed")
ForEach($server in $ertfservers){
ForEach($folder in $folders){
$path = "\\" + $server + "\c$\Epic\Jobs\" + $folder + "\7.8.6\Epic Print Service\" + $file
$result = Test-Path $path
If($result -eq $True){
write-host "Location:" $path
invoke-item $path}
}
}
}