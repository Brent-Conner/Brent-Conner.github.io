﻿$ids = Get-Content "\\bhcs.pvt\dfsdept\EpicTech\Scripts\Imprivata\Input_LWS_Record_IDs.txt"

$date = Get-Date -Format "MM_dd_HHmm" #d | % {$_.replace("/","_")}
$import = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\Imprivata\Ready2Import\$date.txt"

foreach($id in $ids) {
"1,LWS" | Out-File -encoding ascii $import -Append
"2,$id" | Out-File -encoding ascii $import -Append
"3,0" | Out-File -encoding ascii $import -Append
"3,26" | Out-File -encoding ascii $import -Append
"3,36" | Out-File -encoding ascii $import -Append
"4,100000,0" | Out-File -encoding ascii $import -Append
"4,100111,0" | Out-File -encoding ascii $import -Append
"4,100111,0" | Out-File -encoding ascii $import -Append
}