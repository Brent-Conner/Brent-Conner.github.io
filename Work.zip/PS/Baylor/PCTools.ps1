function Menu{

	Clear-Host
	Write-Host "	Device Name: $compname	IP: $pcip"
	Write-Host ""
	Write-Host ""
	Write-Host "1)	Find computer Add/Remove Programs"
	Write-Host "2)	Find Computer Serial Number"
	Write-Host "3)	Find Computer Group Memberships"
	Write-Host "4)	Find Computer Last Logon Date"
	Write-Host "5)	Find Computer Last Password Change"
	Write-Host "6)	Find Computer Uptime"
	Write-Host "7)	List Processes running on Computer"
	Write-Host "8)	Find Computer OS Info"
	Write-Host "9)	Find Computer Model"
	Write-Host "10)	Find Computer Printer Info"
	Write-Host "11)	Find Computer BIOS Version"
	Write-Host "12)	Find Computer SID"
	Write-Host "13)	Find Logged on User"
	Write-Host "14)	Find Computer IE Version"
	Write-Host "15)	Find Computer Citrix Version"
	Write-Host "16)	Find Computer System Type"
	Write-Host "17)	Find Computer Mac Address"
    Write-Host "18)	Get Event Viewer"
    Write-Host "19)	Get Info"
	Write-Host ""
	Write-Host "C)	Change DeviceName"
	Write-Host "X)	Exit Application"
	Write-Host ""
	$a = Read-Host "Please make your numerical selection"
	Main
}

function Main{

	Switch($a)
		{
			1 {ComputerPrograms}
			2 {GetSerialNumber}
			3 {ComputerGroups}
			4 {ComputerLogon}
			5 {ComputerPW}
			6 {ComputerUptime}
			7 {ComputerProcList}
			8 {ComputerOS}
			9 {ComputerModel}
			10 {ComputerPrinters}
			11	{BIOSVer}
			12	{GetCompSID}
			13 	{LoggedUser}
			14	{IEVer}
			15	{CitrixVer}
			16	{SysType}
			17	{MacAddress}
            18  {EventViewer}
            19  {GetInfo}
			c {Clear-Host;$compname="";GetCompName} 
			x {Clear-Host; exit} 
		}
}

function Tryagain{

$answer = Read-Host "Would you like to make another selection? (Y/N)"
If ($answer.StartsWith("Y"))
	{cls
	 Menu}
If ($answer.StartsWith("y"))
	{cls
	 Menu}
If ($answer.StartsWith("N"))
	{Exit}
If ($answer.StartsWith("n"))
	{Exit}
Else 
	{Tryagain}
}

function GetCompName{ 
    $compname = Read-Host "Please enter a computer name or IP" 
    CheckHost ($compname)
} 
 
function CheckHost{ 
    $ping = Get-WMIObject Win32_PingStatus -filter "Address='$compname'" 
    if($ping.StatusCode -eq 0){$pcip=$ping.ProtocolAddress;Menu} 
    else{Pause "Host $compname down...Press any key to continue"; GetCompName} 
} 

function ComputerPrograms{
Get-WMIObject -computer $compname Win32_Product | Sort-Object Name | Format-Table Name,Vendor,Version
Pause
Menu
}

function GetSerialNumber{
Get-WMIObject -computer $compname Win32_BIOS | Select-Object SerialNumber | Format-List 
Pause
Menu
}

function ComputerGroups{
Get-AdComputer -Identity $compname -Properties * | Select Memberof
Pause
Menu
}

function ComputerLogon{
(Get-ADComputer -Identity $compname -Properties *).LastLogonDate
Pause
Menu
}

function ComputerPW{
(Get-ADComputer -Identity $compname -Properties *).PasswordLastSet
Pause
Menu
}

function ComputerUptime{
$wmi = Get-WMIObject -computer $compname Win32_OperatingSystem 
            $localdatetime = $wmi.ConvertToDateTime($wmi.LocalDateTime) 
            $lastbootuptime = $wmi.ConvertToDateTime($wmi.LastBootUpTime) 
             
            "Current Time:      $localdatetime" 
            "Last Boot Up Time: $lastbootuptime" 
             
            $uptime = $localdatetime - $lastbootuptime 
            "" 
            "Uptime: $uptime" 
Pause
Menu
}

function ComputerProcList{
Get-WMIObject -computer $compname Win32_Process | Select-Object Caption,Handle | Sort-Object Caption | Format-Table
Pause
Menu
}

function ComputerOS{
Get-WMIObject -computer $compname Win32_OperatingSystem | Format-List @{Expression={$_.Caption};Label="OS Name"},SerialNumber,OSArchitecture
Pause
Menu
}

function ComputerModel{
Get-WMIObject -computer $compname Win32_ComputerSystem | Format-List Name,Domain,Manufacturer,Model,SystemType
Pause
Menu
}

function ComputerPrinters{
Get-WMIObject -computer $compname Win32_Printer | Select-Object DeviceID,DriverName, PortName | Format-List
Pause
Menu
}

function BIOSVer{
(Get-WmiObject -computer $compname win32_bios).Version
Pause
Menu
}

function GetCompSID{
Get-ADComputer -Identity $compname | Select-Object SID
Pause
Menu
}

function LoggedUser{
Get-WMIObject -computer $compname Win32_ComputerSystem | Format-Table @{Expression={$_.Username};Label="Current User"} 
            "" 
            #May take a very long time if on a domain with many users 
            #"All Users" 
            #"------------" 
            #Get-WMIObject -computer $compname Win32_UserAccount | foreach{$_.Caption} 
Pause
Menu
}

function IEVer{
$keyname = 'SOFTWARE\\Microsoft\\Internet Explorer'
$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $compname)
$key = $reg.OpenSubkey($keyname)
$value1 = $key.GetValue('svcVersion')
$value2 = $key.GetValue('Version')
$value3 = $key.GetValue('svcKBNumber')
$value1
$value2
$value3
Pause
Menu
}

function CitrixVer{
Get-WMIObject -computer $compname Win32_Product | Where-Object {$_.Name -like "*Citrix*"} | Format-Table Name,Vendor,Version
Pause
Menu
}

function SysType{
        $chassis = Get-WmiObject win32_systemenclosure -computer $compname | select chassistypes  
        if ($chassis.chassistypes -contains '3'){Write-Output "Desktop"}  
        elseif ($chassis.chassistypes -contains '4'){Write-Output "Desktop"}  
        elseif ($chassis.chassistypes -contains '5'){Write-Output "Server"}  
        elseif ($chassis.chassistypes -contains '6'){Write-Output "Mini Tower"}  
        elseif ($chassis.chassistypes -contains '7'){Write-Output "Tower"}  
        elseif ($chassis.chassistypes -contains '8'){Write-Output "Laptop"}  
        elseif ($chassis.chassistypes -contains '9'){Write-Output "Laptop"}  
        elseif ($chassis.chassistypes -contains '10'){Write-Output "Laptop"}  
        elseif ($chassis.chassistypes -contains '11'){Write-Output "Hand Held"}  
        elseif ($chassis.chassistypes -contains '12'){Write-Output "Docking Station"}  
        elseif ($chassis.chassistypes -contains '13'){Write-Output "Desktop"}  
        elseif ($chassis.chassistypes -contains '14'){Write-Output "Notebook"}  
        elseif ($chassis.chassistypes -contains '15'){Write-Output "Desktop"}   
        elseif ($chassis.chassistypes -contains '16'){Write-Output "Desktop"}  
        elseif ($chassis.chassistypes -contains '17'){Write-Output "Main System Chassis"}  
        elseif ($chassis.chassistypes -contains '18'){Write-Output "Expansion Chassis"}  
        elseif ($chassis.chassistypes -contains '19'){Write-Output "Sub Chassis"}  
        elseif ($chassis.chassistypes -contains '20'){Write-Output "Bus Expansion Chassis"}  
        elseif ($chassis.chassistypes -contains '21'){Write-Output "Peripheral Chassis"}  
        elseif ($chassis.chassistypes -contains '22'){Write-Output "Storage Chassis"}  
        elseif ($chassis.chassistypes -contains '23'){Write-Output "Rack Mount Chassis"}  
        elseif ($chassis.chassistypes -contains '24'){Write-Output "Desktop"}  
        else {Write-output "Unknown"}
Pause
Menu
}

function MacAddress{
Get-WMIObject -computer $compname -class Win32_NetworkAdapterConfiguration | select Description,MacAddress
Pause
Menu
}

function EventViewer{
Copy-item "\\$compname\C$\Windows\System32\winevt\Logs\Application.evtx"  "\\bhcs.pvt\DFSDept\EpicCrashDumps\ServiceDeskDumps\EventLogs\$($compname)_applog.evtx"
Copy-item "\\$compname\C$\Windows\System32\winevt\Logs\System.evtx"  "\\bhcs.pvt\DFSDept\EpicCrashDumps\ServiceDeskDumps\EventLogs\$($compname)_systemlog.evtx"
Pause
Menu
}

function GetInfo{
Get-WmiObject -class "Win32_PhysicalMemoryArray" -ComputerName $compname
Get-WmiObject Win32_Processor -ComputerName $compname
Get-WMIObject -computer $compname Win32_ComputerSystem | Format-List Name,Domain,Manufacturer,Model,SystemType
Get-WMIObject -computer $compname Win32_OperatingSystem | Format-List @{Expression={$_.Caption};Label="OS Name"},SerialNumber,OSArchitecture
Pause
Menu
}

import-module activedirectory
cls
GetCompName

