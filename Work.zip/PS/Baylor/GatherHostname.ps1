﻿#This is the share where the console export is placed.
$content = "\\bswmsisi01dfs\dfs1$\Dallas\BryanTower\EAS\AD_Team\Imprivata_Backups\bswmsimprivatat01\TapG0AgentDeploymentReport\"
$date = Get-Date -Format "MM_dd_HHmm" #d | % {$_.replace("/","_")}
$HostOut = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\Imprivata\VerifyLWS\$date.txt"
$archive = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\Imprivata\ConsoleExport\"
$array = $null

$Names = Get-ChildItem $content -Recurse
foreach($name in $names) {
$add = Get-Content -path $content$name
$array = $array + $add
Move-Item -path $content$name -destination $archive
}

foreach($line in $array) {
$s = $Line -split '"'
if($s[1] -ne "host") { $s[1] | Out-File $HostOut -append } }