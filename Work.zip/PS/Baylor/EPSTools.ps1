BHPRT00226_T3Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -force

# Global Variables
##################

$ScriptLoc = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\EPS\"
$EPSservice = "EpicPrintService95"
$EPSservices = ("EpicPrintService95","Spooler","PDFreactor Web Service 10")
$ipdns = ".printer.bhcs.pvt"
$binloc = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\EPS\bin\"


Function Brakes { foreach($var in $args) { If(!$var) { Write-Host -foreground red "A variable was NULL, returning to menu."; Pause; Menu } } }

Function GroupSelect {

$slist = Get-ChildItem -path $ScriptLoc"_Servers" -Recurse
$Num = 1
Write-Host -foreground Yellow "***********************"
Write-Host -foreground Yellow ">>>>Server List<<<<"
foreach($list in $slist) { Write-Host $Num - $list; $Num++ }
Write-Host -foreground Yellow "***********************"
$Choice = Read-Host "Choose server list"
$list = $slist[$Choice-1]
$Servers = Get-Content -path $ScriptLoc"_Servers\"$list
Return $Servers
}


Function StatusEPS {

$EPSservers = GroupSelect
foreach($server in $EPSservers) {
    Write-Host -foreground Cyan ">>>>$server<<<<"
    Write-Host -foreground Cyan "***********************"
    foreach($service in $EPSservices) {
        $status = Get-Service -ComputerName $server -ErrorAction SilentlyContinue -Name $service
        Write-Host $status.status $status.name
        if($status.status -ne "Running") { Write-Host -foreground Red "???????????????????????" }
            else { Write-Host -foreground Green "-------------------------------" }
        }
    }
}

Function EnableEPS {

$EPSServers = GroupSelect
foreach($server in $EPSServers) {
    Write-Host -foreground yellow ">>>>$server<<<<"
    Write-Host -foreground cyan "Setting $EPSservice to Automatic"
    Set-Service -ComputerName $server -ErrorAction SilentlyContinue -Name $EPSservice -StartupType Automatic
    Write-Host -foreground cyan "Starting $EPSservice"
    Get-Service -ComputerName $server -ErrorAction SilentlyContinue -Name $EPSservice | Start-Service
    }
}

function DisableEPS { 
$EPSServers = GroupSelect
foreach($server in $EPSServers) {
    Write-Host -foreground yellow ">>>>$server<<<<"
    Write-Host -foreground cyan "Setting $EPSservice to Disabled"
    Set-Service -ComputerName $server -ErrorAction SilentlyContinue -Name $EPSservice -StartupType Disabled
    Write-Host -foreground cyan "Stopping service $EPSservice"
    Get-Service -ComputerName $server -ErrorAction SilentlyContinue -Name $EPSservice | Stop-Service -Force
    }
}

function DriverList {
$EPSservers = GroupSelect

Write-Host -foreground Yellow "***********************"
Write-Host -foreground Yellow ">>>>Driver List<<<<"
$i = 0
$alldrivers = Get-PrinterDriver -ComputerName $epsservers[0]
    
    foreach($drivername in $alldrivers) {
    Write-Host $i " - " $drivername.name
    $i++
    }

    $drivernum = Read-Host "Selection"
    $driver = $alldrivers[$drivernum].name
    Return $driver, $EPSservers
}


function CreatePrinter {

$ip = Read-Host "Printer Port (.printer.bhcs.pvt will be appended)"
$printname = Read-Host "Printer Name (match path of EPR)"
Brakes $ip $printname

$DriverServers = DriverList
$driver = $DriverServers[0]
$EPSservers = $DriverServers[1]

    foreach($server in $EPSservers) {
        Write-Host -foreground Green "Creating: $ip$ipdns >>>> $server"
        Add-PrinterPort -computername $server -name $ip -printerhostaddress $ip$ipdns -ea silentlycontinue

	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$ip
        $print.Shared=$false
        $print.DeviceID=$printname
        $print.Rawonly=$true
	    $print.EnableBIDI=$false
	    Write-Host -foreground Green "Creating: $printname$EPSname >> $server >> $driver"
	    $print.Put()|Out-Null
    }
}

function CreateCustomPrinter {

Write-Host "This must be run from the server if utilized for 101-208 group"
$ip = Read-Host "Printer Port (.printer.bhcs.pvt will be appended)"
$printname = Read-Host "Printer Name (match path of EPR)"
Brakes $ip $printname

$DriverServers = DriverList
$driver = $DriverServers[0]
$EPSservers = $DriverServers[1]

    foreach($server in $EPSservers) {
        #$identify = Read-Host "Add zebra bin file identifier"
        Write-Host -foreground Green "Creating: $ip$ipdns >>>> $server"
        Add-PrinterPort -computername $server -name $ip -printerhostaddress $ip$ipdns -ea silentlycontinue

	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$ip
        $print.Shared=$false
        $print.DeviceID=$printname
        $print.Rawonly=$true
	    $print.EnableBIDI=$false
	    Write-Host -foreground Green "Creating: $printname$EPSname >> $server >> $driver"
	    $print.Put()|Out-Null

        $printid = $print.deviceid
        Start-Sleep 1
        $binfile=$binloc+$driver+$printid+'.bin'
    
        if(test-path $binfile) {
        $traycommand='rundll32 PrintUI.dll,PrintUIEntry /Sr /n "\\$server\$printid" /a "$binfile" d g u r p'
        Write-Host "Applying $binfile to $printid"
        Invoke-Expression $traycommand
        Start-Sleep -s 3
        }

        Else {
        printui.exe /n \\$server\$printid /p
        Write-Host -foreground Yellow "Configure tray settings, close printer, then press enter."
        Pause 
        $createbin='rundll32 PrintUI.dll,PrintUIEntry /Ss /n \\$server\$printid /a $binfile'
        Write-Host -foreground Green "Creating bin file: $binfile"
        Invoke-Expression $createbin
        Start-Sleep -s 3
        }

    }

    Remove-Item $binfile
}

function DuplexLong
{
$EPSservers = GroupSelect
$printname = Read-Host "Queue name"
Brakes $printname
    
    foreach($server in $EPSservers)
    {
    Set-PrintConfiguration -ComputerName $server -PrinterName $printname -DuplexingMode TwoSidedLongEdge
    Write-Host "Applying TwoSidedLongEdge to \\$server\$printname"
    Start-Sleep 1
    }
}

function DuplexRemove
{
$EPSservers = GroupSelect
$printname = Read-Host "Queue name"
Brakes $printname
    
    foreach($server in $EPSservers)
    {
    Set-PrintConfiguration -ComputerName $server -PrinterName $printname -DuplexingMode OneSided
    Write-Host "Applying OneSided to \\$server\$printname"
    Start-Sleep 1
    }
}


##################
Function Menu {

while(1) {
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "Epic Print Server Functions"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  EPS Status"
	Write-host "2.  EPS Enable"
	Write-host "3.  EPS Disable"
    Write-Host "4.  Create Printer"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "5.  Create Printer w/ custom settings"
    Write-host "6.  Duplex - Add"
    Write-host "7.  Duplex - Remove"
    Write-host "8.  "
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "9.  "
    Write-host "10. "
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "11. "
    Write-host "12. "
    Write-host "13. "
    Write-host -foreground Red "---------------------------------------------------"
    Write-Host "14. "
    Write-Host "15. Exit Menu"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
	$MenuOption = Read-host "Selection"
	
	Switch($MenuOption) {
        "1"  {StatusEPS}
		"2"  {EnableEPS}
        "3"  {DisableEPS}
		"4"  {CreatePrinter}
        "5"  {CreateCustomPrinter}
        "6"  {DuplexLong}
        "7"  {DuplexRemove}
        "8"  {}
        "9"  {}
        "10" {}
        "11" {}
        "12" {}
        "13" {}
        "14" {}
        "15" {Exit}
        default {Continue}
        }
    }
}
Menu