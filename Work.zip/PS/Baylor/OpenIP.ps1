﻿Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -force
$p = Read-Host "printer"
#if($p[1] -ne "-") { if($p[0] -ne "b") { $p = $p -replace "p","p-" } }
$dns = $p + ".printer.bhcs.pvt"
$ip = (Resolve-DnsName $dns).IPAddress
$ip
Start-Process -FilePath 'C:\Program Files\Google\Chrome\Application\chrome.exe' -ArgumentList $ip