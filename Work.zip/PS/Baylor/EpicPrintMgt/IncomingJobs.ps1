#============================================================================================================================
#	IncomingJobs.ps1
#============================================================================================================================


#============================================================================================================================
#	NOTES

#	Run as Scheduled Task every 5 minutes
#		PowerShell.exe  -ExecutionPolicy Bypass -Noninteractive -NoProfile -Command ". C:\EpicPrintMgt\Scripts\IncomingJobs.ps1; Exit $LASTEXITCODE"


#	Assumptions
#		Share & NTFS permissions are configured on Incoming Folders
#		Only files which are .csv


#	Monitor Incoming -Recursive for .csv JobFiles
#	ForEach JobFile
#		If Size>0 AND LastWriteTime>59s AND Vetted for Username AND, then
#			Rename & Move Jobs to InProcessing
#			Copy Jobs to Archive


#============================================================================================================================
#	INITIALIZE

	CLS

#	$VerbosePreference = "SilentlyContinue"							# Disable Write-Verbose Output to Console
	$VerbosePreference = "Continue"									# Enable Write-Verbose Output to Console

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

	$IncomingPath = "\\$PrintMaster\C$\EpicPrintMgt\Incoming"
	$InProcessingPath = "\\$PrintMaster\C$\EpicPrintMgt\InProcessing"

	$EPSMgtLog = "\\$PrintMaster\C$\EpicPrintMgt\Logs\EpicPrintMgt.log"

	$VettedEPSMgtFile = "\\$PrintMaster\C$\EpicPrintMgt\Data\VettedEPSMgt.txt"
	$Vetted = $False

#============================================================================================================================


# Check for .csv JobFiles, Exclude Archive SubFolders
	$JobFileList = Get-ChildItem $IncomingPath -Recurse -Filter "*.csv" | Where { $_.FullName -NotLike "*\Archive\*" }
	If ( !( $JobFileList )) {
		Write-Verbose "No Files to process"
		Exit 101
	}

# Check EPSMgtLog Exists, if not Create
	$LogTime = $(Get-Date)
	If ( !( Test-Path $EPSMgtLog )) {
		Try {
			New-Item -Force -ItemType File -Path $EPSMgtLog  -ErrorAction Stop
			Add-Content $EPSMgtLog ( "$LogTime    Created  EPSMgtLog log`n" )
		} Catch {
			Write-Verbose "$LogTime    $EPSMgtLog  NOT accessible"
			Exit 111
		}
	}


# Get-Content VettedEPSMgtFile
	If ( !( Test-Path $VettedEPSMgtFile )) {
		Add-Content $EPSMgtLog ( "$LogTime    VettedEPSMgtFile  NOT accessible`n" )
		Exit 113
	}
	$VettedEPSMgtJobs = Get-Content $VettedEPSMgtFile


	ForEach ( $JobFile in $JobFileList ) {
		If (( $JobFile.Length -Gt 0 )  -And   (( $JobFile.LastWriteTime | New-TimeSpan).TotalSeconds -Gt 59 )) {

# Split Username
			$Username = $JobFile.FullName.Split('\')[6]

# Split Taskname
			$JobTaskName = $JobFile.Name.Split('.')[0]

# Set VettedName
			$VettedName = $JobTaskName +"_"+ $Username

# Check Vetting
			If ( $VettedEPSMgtJobs -Like "*$VettedName*" ) {
				$Vetted = $True

# Get FullName
				$JobFullName = $JobFile.FullName

# Split FullPath
				$JobPathName = Split-Path $JobFullName

# Get Formatted TimeStamp
				$JobTimeStamp = Get-Date ( $JobFile.LastWriteTime ) -Format MMddyyyy_HHmmss

# Split Extension ( Yes, I know this is already .CSV -Filtered )
				$JobExt = $JobFile.Name.Split('.')[1]

# Set InProcessing FullName
				$NewJobFileFullName = $InProcessingPath +"\"+ $JobTaskName +"_"+ $Username +"_"+ $JobTimeStamp +"."+ $JobExt

# Set JobArchivePath, Test and Create Directory
				$JobArchivePath = $JobPathName +"\Archive"
				If ( !( Test-Path $JobArchivePath )) { New-Item $JobArchivePath -Type Directory }

# Set JobArchiveFullName
				$JobArchiveFullName = $JobArchivePath +"\"+ $JobTaskName +"_"+ $Username +"_"+ $JobTimeStamp +"."+ $JobExt

# Rename and Move JobFile to InProcessing folder
				$LogTime = $(Get-Date)
				Try {
					Move-Item -Force -Path $JobFullName -Destination $NewJobFileFullName -ErrorAction Stop
					Add-Content $EPSMgtLog ( "$LogTime    $PrintMaster  Moved         $JobFullName  to  $NewJobFileFullName" )
				} Catch {
					Add-Content $EPSMgtLog ( "$LogTime    $PrintMaster  NOT Moved     $JobFullName  to  $NewJobFileFullName" )
				}

# Archive JobFile
				Try {
					Copy-Item -Force -Path $NewJobFileFullName -Destination $JobArchiveFullName -ErrorAction Stop
					Add-Content $EPSMgtLog ( "$LogTime    $PrintMaster  Archived      $NewJobFileFullName  to  $JobArchiveFullName" )
				} Catch {
					Add-Content $EPSMgtLog ( "$LogTime    $PrintMaster  NOT Archived  $NewJobFileFullName  to  $JobArchiveFullName" )
				}
			}
		}
	}

	IF ( $Vetted ) { Add-Content $EPSMgtLog  ( "" ) }

	Exit 0
