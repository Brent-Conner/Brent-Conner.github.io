#============================================================================================================================
#	C:\Scripts\EpicPrintMgt\EpicPurgeStuckPrintJobs.ps1
#============================================================================================================================

#============================================================================================================================

#   PowerShell.exe  -ExecutionPolicy Bypass -Noninteractive -NoProfile -Command ". C:\Scripts\EpicPrintMgt\EpicPurgeStuckPrintJobs.ps1; Exit $LASTEXITCODE"


#	CHANGE LOG
#	08/09/2021	Changed		.printer.sw.org  to  .printer.bhcs.pvt
#	08/09/2021	Updated		Test-Connection  to  Win32_PingStatus, PingTimeout
#	08/09/2021	Revised		PassMaxTime = StartTime, NOT TaskStartTime
#	08/10/2021	Revised		SecondsBetweenPasses from  120  to  60
#	08/09/2021	Added		.JobStatus -Like '*Printing*'
#	08/09/2021	Added		MaxJobDepth
#	08/09/2021	Added		BlockJobs | Sort -Property TimeSubmitted -Descending ( LIFO Job Deletion )
#	08/10/2021	Added		Context aware server list
#	08/12/2021	Revised		TaskkStart = 3am, StaleMinutes 300->180, MaxRunMinutes 120->240
#	09/02/2021	Fixed		PurgedGrandTotal Multi-Count


#	FUTURE ENHANCEMENTS
#				Skip		PrintServers that have 0 stuck jobs, ZeroStuckJobsList
#				Revise		WMIObject to CimInstance


#============================================================================================================================
# INITIALIZE


	CLS

#	$VerbosePreference = "SilentlyContinue"																					# Disable Write-Verbose Output to Console
	$VerbosePreference = "Continue"																							# Enable  Write-Verbose Output to Console

	$HostName = [system.environment]::MachineName																			# Server Name
	$HostFQDN = $HostName + ".$(( Get-WmiObject Win32_ComputerSystem ).Domain)"												# Server FQDN

# Array of PrintServers
	If ( $HostName -Like "*TechP101" ) {
		$PrintServers = "bswEpicEPSP113","bswEpicEPSP112","bswEpicEPSP111","bswEpicEPSP110","bswEpicEPSP109","bswEpicEPSP108","bswEpicEPSP107","bswEpicEPSP106","bswEpicEPSP105","bswEpicEPSP104","bswEpicEPSP103","bswEpicEPSP102","bswEpicEPSP101"
	} Else {
		$PrintServers  = "bswEpicEPSP213","bswEpicEPSP212","bswEpicEPSP211","bswEpicEPSP210","bswEpicEPSP209","bswEpicEPSP208","bswEpicEPSP207","bswEpicEPSP206","bswEpicEPSP205","bswEpicEPSP204","bswEpicEPSP203","bswEpicEPSP202","bswEpicEPSP201"
		$PrintServers += "bswEpicEPST101","bswEpicEPST102","bswEpicEPST201","bswEpicEPST202"
	}
	$PrintServersTotal = ( $PrintServers ).Count

	$DeleteJob = $True																										# Safety Check
	$StaleMinutes = 180																										# Min=Hrs: 1440=24  720=12  360=6  300=5  180=3
	$StaleMinutesNow = $StaleMinutes																						# Sliding Time
	$SecondsBetweenPasses = 10																								# Delay between passes to allow time for jobs to delete
	$MaxRunMinutes = 240																									# Timelimit for this script to run
	$MaxLogDays = 90																										# Log retention in Days
	$PassNumber = 0
	$PurgedGrandTotal = 0

	$PingTimeout = 30																										# PingTimeout ( ms )

	$StartTime = $(Get-Date)
	$JobTimeStamp = Get-Date -Format MMddyyyy_HHmmss
	$LogFolder = "\\$HostName\C$\Scripts\EpicPrintMgt\Logs"
	$PurgeStuckPrintJobsLog = "$LogFolder" +"\PurgeStuckPrintJobs_"+ $JobTimeStamp +".Log"

	$WMITime = New-Object -ComObject WbemScripting.SwbemDateTime															# SwbemDateTime conversion for readable TimeSubmitted


#============================================================================================================================
# MAIN


# Set Task StartTime
	$PassMaxTime = $StartTime.AddMinutes( $MaxRunMinutes )

	Do {
		$PassNumber ++
		$PrintServerTotal = 0
		$PrintesrStuckTotal = 0
		$JobsToPurgeTotal = 0
		$MaxJobDepth = 0
		$PassStartTime = Get-Date
		$PurgedPrintJobs = "`r`n$PassStartTime`t`tDelete Stuck Print Jobs > $StaleMinutesNow minutes`r`n`r`n"
		Write-Verbose "`r`n$PassStartTime`t`tDelete Stuck Print Jobs > $StaleMinutesNow minutes`r`n`r`n"

		ForEach ( $PrintServer in $PrintServers ) {
			If (( Get-WmiObject Win32_PingStatus -Filter "Address='$PrintServer' AND Timeout=$PingTimeout" ).ResponseTime -GE 0 ) {
				$PrintServerTotal ++

				Try {
					$PrintersErrored = Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServer | Where { $_.JobStatus -Like '*Error*'  -OR  $_.JobStatus -Like '*Deleting*'  -OR  $_.JobStatus -Like '*Offline*'  -OR  $_.JobStatus -Like '*Printing*' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -LT (Get-Date).AddMinutes(-($StaleMinutesNow)) }
#					$PrintersErrored = Get-CimInstance "Win32_PrintJob" -ComputerName $PrintServer | Where { $_.JobStatus -Like '*Error*'  -OR  $_.JobStatus -Like '*Deleting*'  -OR  $_.JobStatus -Like '*Offline*'  -OR  $_.JobStatus -Like '*Printing*' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -LT (Get-Date).AddMinutes(-($StaleMinutesNow)) }
					$PrintersErrored | Sort Name | ForEach {
						$PrintesrStuckTotal ++
						$WMITime.Value = $_.TimeSubmitted
						$StuckJobTime = $WMITime.GetVarDate()
						$StuckJobSize = [string][math]::Round($_.Size / 1KB, 2) +"KB"
						$StuckJobStatus = $_.JobStatus
						$StuckJobPages = $_.TotalPages
						$StuckJobDocument = $_.Document
						$PrinterName = $_.Name.Split(',')[0]
						$PrinterFQDN = ($PrinterName).Split('_')[0] +".printer.bhcs.pvt"
						If (( Get-WmiObject Win32_PingStatus -Filter "Address='$PrinterFQDN' AND Timeout=$PingTimeout" ).ResponseTime -GE 0 ) { $PrinterFQDNOnline = "Online" } Else { $PrinterFQDNOnline = "Offline" }

						Try {
							$BlockedJobs = Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServer | Where { $_.Name -Like "$PrinterName*" } | Sort -Property TimeSubmitted -Descending
#							$BlockedJobs = Get-CimInstance "Win32_PrintJob" -ComputerName $PrintServer | Where { $_.Name -Like "$PrinterName*" } | Sort -Property TimeSubmitted -Descending
							If ( $MaxJobDepth -LT $BlockedJobs.Count ) { $MaxJobDepth = $BlockedJobs.Count }
							ForEach ( $BlockedJob in $BlockedJobs ) {
								If ( $DeleteJob ) { $ReturnValue = $_.Pause() }
								If ( $PassNumber -EQ 1 ) { $PurgedGrandTotal ++ }
								$JobsToPurgeTotal ++
								$WMITime.Value = $BlockedJob.TimeSubmitted
								$BlockedJobTime = $WMITime.GetVarDate()
								$BlockedJobSize = [string][math]::Round($BlockedJob.Size / 1KB, 2) +"KB"
								$BlockedJobJobStatus = $BlockedJob.JobStatus
								$BlockedJobPages = $BlockedJob.TotalPages
								$BlockedJobDocument = $BlockedJob.Document
								Write-Verbose "$PrintServer  $PrinterName  $BlockedJobTime  $BlockedJobJobStatus           $BlockedJobSize   $BlockedJobPages`r`n         $BlockedJobDocument`r`n"
# Delete Innocent blocked Job(s)
								If ( $DeleteJob  -AND  !( $BlockedJobJobStatus -Like '*Error*'  -OR  $BlockedJobJobStatus -Like '*Deleting*'  -OR  $BlockedJobJobStatus -Like '*Offline*'  -OR  $BlockedJobJobStatus -Like '*Printing*' )) {
									$ReturnValue = $_.Delete()
									$PurgedPrintJobs += "$PrintServer  $PrinterName`t$PrinterFQDNOnline`t$BlockedJobTime  $BlockedJobJobStatus`t`t`t`t`t`t`t$BlockedJobSize`t $BlockedJobPages`t $BlockedJobDocument`r`n"
									Write-Verbose "DeletingI:  $PrintServer  $PrinterName`t$PrinterFQDNOnline`t$BlockedJobTime  $BlockedJobJobStatus`t`t`t`t`t`t`t$BlockedJobSize`t $BlockedJobPages`r`n         $BlockedJobDocument`n"
								}
							}
						} Catch { Write-Verbose "Get Win32_PrintJob Error on  $PrintServer`r`n" }
# Delete Guilty stuck Job
						If ( $DeleteJob ) {
							$ReturnValue = $_.Delete()
							$PurgedPrintJobs += "$PrintServer  $PrinterName`t$PrinterFQDNOnline`t$StuckJobTime  $StuckJobStatus`t`t`t$StuckJobSize`t $StuckJobPages`t $StuckJobDocument`r`n`r`n"
							Write-Verbose "DeletingG:  $PrintServer  $PrinterName`t$PrinterFQDNOnline`t$StuckJobTime  $StuckJobStatus`t`t`t$StuckJobSize    $StuckJobPages`r`n         $StuckJobDocument`n`n"
						}
					}
				} Catch { Write-Verbose "Get Win32_PrintJob Error on  $PrintServer`r`n" }
			}
		}

		$PassStopTime = Get-Date
		$ElapsedPassTime = $PassStopTime - $PassStartTime
		$PurgedPrintJobs += "`r`n"
		$PurgedPrintJobs += "Pass Number             $PassNumber`r`n"
		$PurgedPrintJobs += "Elapsed Seconds         $($ElapsedPassTime.TotalSeconds)`r`n"
		$PurgedPrintJobs += "Not to Exceed           $PassMaxTime`r`n"
		$PurgedPrintJobs += "Total Print Servers     $PrintServerTotal`r`n"
		$PurgedPrintJobs += "Total Printers Stuck    $PrintesrStuckTotal`r`n"
		$PurgedPrintJobs += "Total Jobs to Purge     $JobsToPurgeTotal`r`n"
		$PurgedPrintJobs += "Maximum Job Depth       $MaxJobDepth`r`n"
		$PurgedPrintJobs | Out-File -Append $PurgeStuckPrintJobsLog

		Write-Verbose "Total Print Servers     $PrintServerTotal"
		Write-Verbose "Total Printers Stuck    $PrintesrStuckTotal"
		Write-Verbose "Total Jobs to Purge     $JobsToPurgeTotal"
		Write-Verbose "Maximum Job Depth       $MaxJobDepth`r`n"
		Write-Verbose "Elapsed Seconds         $($ElapsedPassTime.TotalSeconds)`r`n"

		Sleep -s $SecondsBetweenPasses
		$ElapsedTotalMinutes = ((Get-Date) - $StartTime ).TotalMinutes
		$StaleMinutesNow = $StaleMinutes + $ElapsedTotalMinutes

#	} While ( $JobsToPurgeTotal -GT 0  -AND  $PassStopTime -LT $PassMaxTime )
	} While ( $PrintesrStuckTotal -GT 0  -AND  $PassStopTime -LT $PassMaxTime )


# Close Log
	$PurgedPrintJobs = "`r`n`r`n"
	$PurgedPrintJobs += "Purge Completed         $(Get-Date)`r`n"
	$PurgedPrintJobs += "Elapsed Minutes         $ElapsedTotalMinutes`r`n"
	$PurgedPrintJobs += "Grand Total Purged      $PurgedGrandTotal`r`n"
	$PurgedPrintJobs | Out-File -Append $PurgeStuckPrintJobsLog

# Cleanup old logs
	$MaxDate = $StartTime.AddDays(-$MaxLogDays)
	If ( Test-Path $LogFolder ) { Get-ChildItem $LogFolder PurgeStuckPrintJobs_*.Log -Force | Where { $_.LastWriteTime -LT $MaxDate } | Remove-Item -Recurse -Force }


# Normal Exit
	Exit 0
