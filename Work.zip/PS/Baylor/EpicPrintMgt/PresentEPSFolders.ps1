$CurrentEPSFoldersCSVUNC = "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt\CurrentEPSFolders.csv"


While ( $True ) {

	$EPSObject = Import-CSV $CurrentEPSFoldersCSVUNC

	CLS
	$EPSObject | FT -Auto
	"CurrentTime:  $(Get-Date)"
	Sleep 1

}
