$CurrentEPSFoldersCSVUNC = "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt\CurrentEPSFolders.csv"
$ArchiveEPSFoldersCSVUNC = "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt\ArchiveEPSFolders.csv"

$ServerNames = ( Get-Content "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt\CheckEPSServerNames.txt" ) | Sort

$EpicVersion = "8.3"

[int]$maxLimit = 25 # Number of file(s) waiting to be processed in Incoming folder for file count to be in RED.
[int]$sshdLimit = 50 # Number of file(s) waiting to be processed in Incoming folder for SSHD service to be stopped.


While ( $True ) {
	$StartTime = $(Get-Date)
	$EPSObject = @()																													# Object for all EPS Servers

    ForEach ( $ServerName in $ServerNames ) {
		$EPSProps = [Ordered]@{																											# Hash for each EPS Server
			'CheckTime' = $StartTime
			'ServerName' = $ServerName
			'PingStatus' = ""
			'IncomingCount' = ""
			'IncomingColor' = "Green"
			'SSDLimit' = "Green"
			'FailedCount' = ""
		}

		If ( Test-Connection -ComputerName $ServerName -BufferSize 16 -Count 1 -EA SilentlyContinue -Quiet ) {
			$EPSProps.PingStatus = "Online"
			$EPSProps.IncomingCount = [System.IO.Directory]::GetFiles( "\\$ServerName\C$\Epic\Jobs\Incoming\$EpicVersion\Epic Print Service", "*.e???" ).Count
			$EPSProps.FailedCount = [System.IO.Directory]::GetFiles( "\\$ServerName\C$\Epic\Jobs\Failed\$EpicVersion\Epic Print Service", "*.e???" ).Count
			If ( $EPSProps.IncomingCount -Ge $maxLimit ) { $EPSProps.IncomingColor = "Red" }
			If ( $EPSProps.IncomingCount -Ge $sshdLimit ) { $EPSProps.SSDLimit = "Red" }
		} Else {
			$EPSProps.PingStatus = "Offline"
			$EPSProps.IncomingColor = "White"
		}

		$EPSObject += New-Object PSObject -Property $EPSProps
	}

	$EPSObject | Export-CSV $CurrentEPSFoldersCSVUNC -NoTypeInformation

}
