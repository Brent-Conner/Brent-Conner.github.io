#============================================================================================================================
#	BuildPrinterDBs.ps1
#============================================================================================================================

# Schedule to run early AM


#============================================================================================================================
# INITIALIZE

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

	$PrinterServerDB = "\\$PrintMaster\C$\EpicPrinterMgt\Reports\PrintServerDB.txt"
	$PrinterErrorDB = "\\$PrintMaster\C$\EpicPrinterMgt\Reports\PrinterErrorDB.csv"
	$PrinterDriverDB = "\\$PrintMaster\C$\EpicPrinterMgt\Reports\PrinterDriverDB.csv"
	$PrinterErrorDBTmp = "\\$PrintMaster\C$\EpicPrinterMgt\Reports\PrinterErrorDB.tmp"
	$PrinterDriverDBTmp = "\\$PrintMaster\C$\EpicPrinterMgt\Reports\PrinterDriverDB.tmp"

	CLS

#============================================================================================================================

	Write-Host "Building PrinterDBs ( Driver & Errored . . . )"


# Check $PrinterServerDB Exists
	If ( ! ( Test-Path $PrinterServerDB ) ) { 
		Write-Host "$PrinterServerDB  NOT found"
		Exit 111
	}

# Delete previous Tmp files, if Exists and Accessible
	Remove-Item $PrinterErrorDBTmp -ErrorAction SilentlyContinue
	Remove-Item $PrinterDriverDBTmp -ErrorAction SilentlyContinue
	Add-Content $PrinterErrorDBTmp ('"SystemName","Name","PortName","Status"')
	Add-Content $PrinterDriverDBTmp ('"SystemName","Name","PortName","DriverName"')

	ForEach ( $PrintServer in Get-Content $PrinterServerDB ) {
		Write-Host "Building PrinterDBs for $PrintServer . . ."
#		$PServerPrinters = Get-WmiObject -Class "Win32_Printer" -namespace "root\CIMV2" -computername $PrintServer 
#		$PServerPrinters | Where-object { $_.Name -Like "P-*" } | Select SystemName, Name, PortName, DriverName | Export-CSV $PrinterDriverDBTmp -Append -NoTypeInformation
#		$PServerPrinters | Where-object { $_.Name -Like "P-*" -And $_.Status -Like "Error*" } | Select SystemName, Name, PortName, Status | Export-CSV $PrinterErrorDBTmp -Append -NoTypeInformation
#		$PServerPrinters = Get-WmiObject -Class "Win32_Printer" -Namespace "root\CIMV2" -Computername $PrintServer | Where-object { $_.Name -Like "P-*" }
		$PServerPrinters = Get-WmiObject -Class "Win32_Printer" -Namespace "root\CIMV2" -Computername $PrintServer | Where-object { $_.Name -Like "P-*" } | Sort-Object Name
		$PServerPrinters | Select-Object SystemName, Name, PortName, DriverName | Export-CSV $PrinterDriverDBTmp -Append -NoTypeInformation
		$PServerPrinters | Where-object { $_.Status -Like "Error*" } | Select-Object SystemName, Name, PortName, Status | Export-CSV $PrinterErrorDBTmp -Append -NoTypeInformation
	}

# Delete previous PrinterDriverDB, if Exists and Accessible, then Rename
	If ( Test-Path $PrinterDriverDB ) { 
		Try { 
			Remove-Item $PrinterDriverDB -ErrorAction Stop
			Rename-Item $PrinterDriverDBTmp $PrinterDriverDB
		} Catch { 
			Write-Host "$PrinterDriverDB  IN use, or NOT accessible"
			Exit 121
		}
	} Else {
		Rename-Item $PrinterDriverDBTmp $PrinterDriverDB
	}

# Delete previous PrinterErrorDB, if Exists and Accessible, then Rename
	If ( Test-Path $PrinterErrorDB ) { 
		Try { 
			Remove-Item $PrinterErrorDB -ErrorAction Stop
			Rename-Item $PrinterErrorDBTmp $PrinterErrorDB
		} Catch { 
			Write-Host "$PrinterErrorDB  IN use, or NOT accessible"
			Exit 123
		}
	} Else {
		Rename-Item $PrinterErrorDBTmp $PrinterErrorDB
	}

	Exit 1000
