	CLS

	$PrinterServers = "D:\PSScripts\EpicPrinters\PrintServerList.txt"
	$PrintersDB = "D:\PSScripts\EpicPrinters\PrintersDB.csv"

# ??? Try-Catch for existance of PrinterServers

# Delete previous Resultant Printer DB, if Exists and Accessible
	If ( Test-Path $PrintersDB ) { 
		Try { Remove-Item $PrintersDB -ErrorAction Stop
		} Catch { 
			Write-Host "$PrintersDB  IN use, or NOT accessible"
			Exit 121
		}
	}
	Add-Content $PrintersDB ('"SystemName","Name","PortName","DriverName"')

	ForEach ( $PrintServer in Get-Content $PrinterServers ) {
		Write-Host "Building Printer Table for $PrintServer . . ."
		$PServerPrinters = Get-WmiObject -Class "Win32_Printer" -namespace "root\CIMV2" -computername $PrintServer
		$PServerPrinters | Where-object { $_.Name -Like "P-*" } | Select SystemName, Name, PortName, DriverName | Export-CSV $PrintersDB -Append -NoTypeInformation
	}
	Exit 100


# NOTES:
#
#
#	Get-WmiObject -class "Win32_Printer" Methods:
#		CancelAllJobs               Method        System.Management.ManagementBaseObject CancelAllJobs()
#		Pause                       Method        System.Management.ManagementBaseObject Pause()
#		PrintTestPage               Method        System.Management.ManagementBaseObject PrintTestPage()
#		Reset                       Method        System.Management.ManagementBaseObject Reset()
#		Resume                      Method        System.Management.ManagementBaseObject Resume()
#
#
#	Properties:
#		ForEach ($objItem in $PServerPrinters) { 
#			  Write-Host "Attributes:			" $objItem.Attributes 
#			  Write-Host "Availability:			" $objItem.Availability 
#			  Write-Host "Available Job Sheets:			" $objItem.AvailableJobSheets 
#			  Write-Host "Average Pages Per Minute:			" $objItem.AveragePagesPerMinute 
#			  Write-Host "Capabilities:			" $objItem.Capabilities 
#			  Write-Host "Capability Descriptions:			" $objItem.CapabilityDescriptions 
#			  Write-Host "Caption:			" $objItem.Caption 
#			  Write-Host "Character Sets Supported:			" $objItem.CharSetsSupported 
#			  Write-Host "Comment:			" $objItem.Comment 
#			  Write-Host "Configuration Manager Error Code:			" $objItem.ConfigManagerErrorCode 
#			  Write-Host "Configuration Manager User Configuration:			" $objItem.ConfigManagerUserConfig 
#			  Write-Host "Creation Class Name:			" $objItem.CreationClassName 
#			  Write-Host "Current Capabilities:			" $objItem.CurrentCapabilities 
#			  Write-Host "Current Character Set:			" $objItem.CurrentCharSet 
#			  Write-Host "Current Language:			" $objItem.CurrentLanguage 
#			  Write-Host "Current MIME Type:			" $objItem.CurrentMimeType 
#			  Write-Host "Current Natural Language:			" $objItem.CurrentNaturalLanguage 
#			  Write-Host "Current Paper Type:			" $objItem.CurrentPaperType 
#			  Write-Host "Default:			" $objItem.Default 
#			  Write-Host "Default Capabilities:			" $objItem.DefaultCapabilities 
#			  Write-Host "Default Copies:			" $objItem.DefaultCopies 
#			  Write-Host "Default Language:			" $objItem.DefaultLanguage 
#			  Write-Host "Default MIME Type:			" $objItem.DefaultMimeType 
#			  Write-Host "Default Number Up:			" $objItem.DefaultNumberUp 
#			  Write-Host "Default Paper Type:			" $objItem.DefaultPaperType 
#			  Write-Host "Default Priority:			" $objItem.DefaultPriority 
#			  Write-Host "Description:			" $objItem.Description 
#			  Write-Host "Detected Error State:			" $objItem.DetectedErrorState 
#			  Write-Host "Device ID:			" $objItem.DeviceID 
#			  Write-Host "Direct:			" $objItem.Direct 
#			  Write-Host "Do Complete First:			" $objItem.DoCompleteFirst 
#			  Write-Host "Driver Name:			" $objItem.DriverName 
#			  Write-Host "Enable BIDI:			" $objItem.EnableBIDI 
#			  Write-Host "Enable Device Query Print:			" $objItem.EnableDevQueryPrint 
#			  Write-Host "Error Cleared:			" $objItem.ErrorCleared 
#			  Write-Host "Error Description:			" $objItem.ErrorDescription 
#			  Write-Host "Error Information:			" $objItem.ErrorInformation 
#			  Write-Host "Extended Detected Error State:			" $objItem.ExtendedDetectedErrorState 
#			  Write-Host "Extended Printer Status:			" $objItem.ExtendedPrinterStatus 
#			  Write-Host "Hidden:			" $objItem.Hidden 
#			  Write-Host "Horizontal Resolution:			" $objItem.HorizontalResolution 
#			  Write-Host "Install Date:			" $objItem.InstallDate 
#			  Write-Host "Job Count Since Last Reset:			" $objItem.JobCountSinceLastReset 
#			  Write-Host "Keep Printed Jobs:			" $objItem.KeepPrintedJobs 
#			  Write-Host "Languages Supported:			" $objItem.LanguagesSupported 
#			  Write-Host "Last Error Code:			" $objItem.LastErrorCode 
#			  Write-Host "Local:			" $objItem.Local 
#			  Write-Host "Location:			" $objItem.Location 
#			  Write-Host "Marking Technology:			" $objItem.MarkingTechnology 
#			  Write-Host "Maximum Copies:			" $objItem.MaxCopies 
#			  Write-Host "Maximum Number Up:			" $objItem.MaxNumberUp 
#			  Write-Host "Maximum Size Supported:			" $objItem.MaxSizeSupported 
#			  Write-Host "MIME Types Supported:			" $objItem.MimeTypesSupported 
#			  Write-Host "Name:			" $objItem.Name 
#			  Write-Host "Natural Languages Supported:			" $objItem.NaturalLanguagesSupported 
#			  Write-Host "Network:			" $objItem.Network 
#			  Write-Host "Paper Sizes Supported:			" $objItem.PaperSizesSupported 
#			  Write-Host "Paper Types Available:			" $objItem.PaperTypesAvailable 
#			  Write-Host "Parameters:			" $objItem.Parameters 
#			  Write-Host "PNP Device ID:			" $objItem.PNPDeviceID 
#			  Write-Host "Port Name:			" $objItem.PortName 
#			  Write-Host "Power Management Capabilities:			" $objItem.PowerManagementCapabilities 
#			  Write-Host "Power Management Supported:			" $objItem.PowerManagementSupported 
#			  Write-Host "Printer Paper Names:			" $objItem.PrinterPaperNames 
#			  Write-Host "Printer State:			" $objItem.PrinterState 
#			  Write-Host "Printer Status:			" $objItem.PrinterStatus 
#			  Write-Host "Print Job Data Type:			" $objItem.PrintJobDataType 
#			  Write-Host "Print Processor:			" $objItem.PrintProcessor 
#			  Write-Host "Priority:			" $objItem.Priority 
#			  Write-Host "Published:			" $objItem.Published 
#			  Write-Host "Queued:			" $objItem.Queued 
#			  Write-Host "Raw-Only:			" $objItem.RawOnly 
#			  Write-Host "Separator File:			" $objItem.SeparatorFile 
#			  Write-Host "Server Name:			" $objItem.ServerName 
#			  Write-Host "Shared:			" $objItem.Shared 
#			  Write-Host "Share Name:			" $objItem.ShareName 
#			  Write-Host "Spool Enabled:			" $objItem.SpoolEnabled 
#			  Write-Host "Start Time:			" $objItem.StartTime 
#			  Write-Host "Status:			" $objItem.Status 
#			  Write-Host "Status Info:			" $objItem.StatusInfo 
#			  Write-Host "System Creation Class Name:			" $objItem.SystemCreationClassName 
#			  Write-Host "System Name:			" $objItem.SystemName 
#			  Write-Host "Time Of Last Reset:			" $objItem.TimeOfLastReset 
#			  Write-Host "Until Time:			" $objItem.UntilTime 
#			  Write-Host "Vertical Resolution:			" $objItem.VerticalResolution 
#			  Write-Host "Work Offline:			" $objItem.WorkOffline 
#
#			  Write-Host $objItem.SystemName  "`t"	$objItem.Name "`t" $objItem.PortName "`t`t" $objItem.DriverName
#		}
