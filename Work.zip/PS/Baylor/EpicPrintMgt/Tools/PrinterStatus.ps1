# Printer Status  ( Working on Prod )

$arrayComp = "Server1" 
foreach ($Server in $arrayComp) 
{  
# Get-WmiObject -class win32_printer -computername $Server | Where-object {$_.status -notmatch "Unknown" -and $_.status -notmatch "Ok"} | sort name | ft name, systemName, shareName, status, location 
Get-WmiObject -class win32_printer -computername $Server | Where-object {$_.status -Like "Error*" } | sort name | ft name, systemName, shareName, status, location 
}


EXIT
