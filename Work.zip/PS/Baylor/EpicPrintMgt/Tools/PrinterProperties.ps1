	CLS

	$PServer = Read-Host -Prompt "Enter PrintServer Name"
	$PName = Read-Host -Prompt "Enter P-Name(*)"

	$Printers = Get-Wmiobject -Class "Win32_Printer" -Namespace "root\CIMV2" -Computername $PServer | Where-Object { $_.Name -Like "$PName" }
	 
	foreach ($Printer in $Printers) { 
		  Write-Host "Attributes:					" $Printer.Attributes 
		  Write-Host "Availability:				" $Printer.Availability 
		  Write-Host "Available Job Sheets:				" $Printer.AvailableJobSheets 
		  Write-Host "Average Pages Per Minute:			" $Printer.AveragePagesPerMinute 
		  Write-Host "Capabilities:					" $Printer.Capabilities 
		  Write-Host "Capability Descriptions:			" $Printer.CapabilityDescriptions 
		  Write-Host "Caption:					" $Printer.Caption 
		  Write-Host "Character Sets Supported:				" $Printer.CharSetsSupported 
		  Write-Host "Comment:				" $Printer.Comment 
		  Write-Host "Configuration Manager Error Code:				" $Printer.ConfigManagerErrorCode 
		  Write-Host "Configuration Manager User Configuration:				" $Printer.ConfigManagerUserConfig 
		  Write-Host "Creation Class Name:				" $Printer.CreationClassName 
		  Write-Host "Current Capabilities:				" $Printer.CurrentCapabilities 
		  Write-Host "Current Character Set:				" $Printer.CurrentCharSet 
		  Write-Host "Current Language:				" $Printer.CurrentLanguage 
		  Write-Host "Current MIME Type:				" $Printer.CurrentMimeType 
		  Write-Host "Current Natural Language:				" $Printer.CurrentNaturalLanguage 
		  Write-Host "Current Paper Type:				" $Printer.CurrentPaperType 
		  Write-Host "Default:					" $Printer.Default 
		  Write-Host "Default Capabilities:				" $Printer.DefaultCapabilities 
		  Write-Host "Default Copies:				" $Printer.DefaultCopies 
		  Write-Host "Default Language:				" $Printer.DefaultLanguage 
		  Write-Host "Default MIME Type:				" $Printer.DefaultMimeType 
		  Write-Host "Default Number Up:				" $Printer.DefaultNumberUp 
		  Write-Host "Default Paper Type:				" $Printer.DefaultPaperType 
		  Write-Host "Default Priority:				" $Printer.DefaultPriority 
		  Write-Host "Description:				" $Printer.Description 
		  Write-Host "Detected Error State:				" $Printer.DetectedErrorState 
		  Write-Host "Device ID:					" $Printer.DeviceID 
		  Write-Host "Direct:						" $Printer.Direct 
		  Write-Host "Do Complete First:				" $Printer.DoCompleteFirst 
		  Write-Host "Driver Name:					" $Printer.DriverName 
		  Write-Host "Enable BIDI:					" $Printer.EnableBIDI 
		  Write-Host "Enable Device Query Print:			" $Printer.EnableDevQueryPrint 
		  Write-Host "Error Cleared:				" $Printer.ErrorCleared 
		  Write-Host "Error Description:				" $Printer.ErrorDescription 
		  Write-Host "Error Information:				" $Printer.ErrorInformation 
		  Write-Host "Extended Detected Error State:			" $Printer.ExtendedDetectedErrorState 
		  Write-Host "Extended Printer Status:			" $Printer.ExtendedPrinterStatus 
		  Write-Host "Hidden:						" $Printer.Hidden 
		  Write-Host "Horizontal Resolution:				" $Printer.HorizontalResolution 
		  Write-Host "Installation Date:				" $Printer.InstallDate 
		  Write-Host "Job Count Since Last Reset:			" $Printer.JobCountSinceLastReset 
		  Write-Host "Keep Printed Jobs:				" $Printer.KeepPrintedJobs 
		  Write-Host "Languages Supported:				" $Printer.LanguagesSupported 
		  Write-Host "Last Error Code:				" $Printer.LastErrorCode 
		  Write-Host "Local:						" $Printer.Local 
		  Write-Host "Location:				" $Printer.Location 
		  Write-Host "Marking Technology:				" $Printer.MarkingTechnology 
		  Write-Host "Maximum Copies:				" $Printer.MaxCopies 
		  Write-Host "Maximum Number Up:				" $Printer.MaxNumberUp 
		  Write-Host "Maximum Size Supported:				" $Printer.MaxSizeSupported 
		  Write-Host "MIME Types Supported:				" $Printer.MimeTypesSupported 
		  Write-Host "Name:						" $Printer.Name 
		  Write-Host "Natural Languages Supported:				" $Printer.NaturalLanguagesSupported 
		  Write-Host "Network:					" $Printer.Network 
		  Write-Host "Paper Sizes Supported:				" $Printer.PaperSizesSupported 
		  Write-Host "Paper Types Available:				" $Printer.PaperTypesAvailable 
		  Write-Host "Parameters:				" $Printer.Parameters 
		  Write-Host "PNP Device ID:				" $Printer.PNPDeviceID 
		  Write-Host "Port Name:					" $Printer.PortName 
		  Write-Host "Power Management Capabilities:				" $Printer.PowerManagementCapabilities 
		  Write-Host "Power Management Supported:				" $Printer.PowerManagementSupported 
		  Write-Host "Printer Paper Names:				" $Printer.PrinterPaperNames 
		  Write-Host "Printer State:					" $Printer.PrinterState 
		  Write-Host "Printer Status:					" $Printer.PrinterStatus 
		  Write-Host "Print Job Data Type:				" $Printer.PrintJobDataType 
		  Write-Host "Print Processor:				" $Printer.PrintProcessor 
		  Write-Host "Priority:					" $Printer.Priority 
		  Write-Host "Published:					" $Printer.Published 
		  Write-Host "Queued:						" $Printer.Queued 
		  Write-Host "Raw-Only:					" $Printer.RawOnly 
		  Write-Host "Separator File:				" $Printer.SeparatorFile 
		  Write-Host "Server Name:				" $Printer.ServerName 
		  Write-Host "Shared:						" $Printer.Shared 
		  Write-Host "Share Name:					" $Printer.ShareName 
		  Write-Host "Spool Enabled:					" $Printer.SpoolEnabled 
		  Write-Host "Start Time:					" $Printer.StartTime 
		  Write-Host "Status:						" $Printer.Status 
		  Write-Host "Status Information:			" $Printer.StatusInfo 
		  Write-Host "System Creation Class Name:			" $Printer.SystemCreationClassName 
		  Write-Host "System Name:					" $Printer.SystemName 
		  Write-Host "Time Of Last Reset:				" $Printer.TimeOfLastReset 
		  Write-Host "Until Time:				" $Printer.UntilTime 
		  Write-Host "Vertical Resolution:				" $Printer.VerticalResolution 
		  Write-Host "Work Offline:					" $Printer.WorkOffline 
		  Write-Host

	}

#	Write-Host "Press any key to continue ..."
#	$KeyPress = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

	Exit