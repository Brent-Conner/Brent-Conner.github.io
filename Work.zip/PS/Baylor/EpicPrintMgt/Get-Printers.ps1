
#	C:\Scripts\EpicPrintMgt\Get-Printers.ps1

	$GetPrintersLog = "C:\Scripts\EpicPrintMgt\Get-Printers.csv"

	$PrintServer = "bswEpicEPSP101.bhcs.pvt"

	$PrintPrefixes = "P-|BHPRT|PRT|ZPRT"

	$AllPrinters = Get-Printer -CimSession $PrintServer | Sort Name

#	$BSWHPrinters = ( $AllPrinters -Match $PrintPrefixes ).Name
#	$BSWHPrinters = $BSWHPrinters | ForEach { $_.Split('_')[0] } | Unique

	$BSWHPrinters = $AllPrinters.Name | ForEach { $_.Split('_')[0] } | Unique

	$BSWHPrinters | FT -Auto | Out-file -Force $GetPrintersLog
