#============================================================================================================================
#	DeleteBlockedPrintJobs.ps1
#============================================================================================================================



#============================================================================================================================
Function Get-EPSPrintJob {
<#
.SYNOPSIS
    Get PrintJobs on local or remote Computer.

.DESCRIPTION
    Get PrintJobs on local or remote Computer using WMI

.PARAMETER ComputerName
    The computer name(s) to retrieve the info from. 
    Default to local Computer

.PARAMETER PrinterName
    An existing Print Queue Name. Wildcard (*) support. 
    Default to '*' (all Print Queues) 

.PARAMETER Credential
    Alternate Credential to connect to the remote Computer

.EXAMPLE
    Get-EPSPrintJob -ComputerName Server1 -PrinterName 'd363*'

    Wildcard support, to list all PrintJobs for all Print Queues with name beginning with 'd363'.

.EXAMPLE
    PS C:\> Get-EPSPrintJob -ComputerName Server1 | where {$_.Status -Eq 'Error'}

    To list all Printjobs of all Print Queues with Status:Error from PrintServer Server1

.EXAMPLE
    Get-EPSPrintJob -ComputerName Server1 | Where { $_.ConvertToDateTime($_.TimeSubmitted) -lt (Get-Date).AddDays(-5) }

    To list all Printjobs of all Print Queues older than 5 Days from PrintServer Server1

.EXAMPLE
	To Delete all Printjobs of all Print Queues older than 5 Days from PrintServer Server1

    Get-EPSPrintJob -ComputerName Server1 | Where { $_.ConvertToDateTime($_.TimeSubmitted) -lt (Get-Date).AddDays(-5) } | Foreach-Object { $_.Delete() }

.EXAMPLE
	To Delete Printjobs with status 'Error' of all Print Queues on PrintServer: Server1,Server2,Server3

	Get-EPSPrintJob -ComputerName Server1,Server,Server3 | where {$_.Status -Eq 'Error'} | Foreach-Object { $_.Delete() }


.INPUTS
    System.String, you can pipe ComputerNames to this Function

.OUTPUTS
    TypeName: System.Management.ManagementObject#root\CIMV2\Win32_PrintJob

.NOTES
    use |select * to see all Properties

    AUTHOR: Pasquale Lantella 
    LASTEDIT: 16.02.2015
    KEYWORDS: PrintJob

.LINK
    Get-WmiObject    

#Requires -Version 2.0
#>
   
[cmdletbinding()]  

[OutputType('System.Management.ManagementObject#root\CIMV2\Win32_PrintJob')]

	Param (
		[Parameter(Position=0,Mandatory=$False,ValueFromPipeline=$True,
			HelpMessage='An array of computer names. The default is the local computer.')]
		[alias("CN")]
		[string[]]$ComputerName = $Env:COMPUTERNAME,

		[Parameter(Position=1)]
		[string]$PrinterName = '*',

		[parameter(Position=2)]
		[Alias('RunAs')]
		[System.Management.Automation.Credential()]$Credential = [System.Management.Automation.PSCredential]::Empty
	)


	BEGIN {
		Set-StrictMode -Version Latest
		${CmdletName} = $Pscmdlet.MyInvocation.MyCommand.Name

		# create WMI filter
		# we need special handling to filter for Printer Names
		If ($PrinterName -match [Regex]::Escape('*'), "*") {
			# Replace * wildcard as WMI uses '%'
			$PrinterName = "$PrinterName" -replace [Regex]::Escape('*'), '%'
			[String]$WMIFilter = "Name like '" + "$PrinterName" + "'"                    
			Write-Debug "`$WMIFilter contains: $WMIFilter"
		} Else {
			# No wildcards, filter for the exact name
			[String]$WMIFilter = "Name like '" + "$PrinterName" + "'"                    
			Write-Debug "`$WMIFilter contains: $WMIFilter"
		} 
	}


	PROCESS {
		ForEach ( $Computer in $ComputerName ) {
			IF ( Test-Connection -ComputerName $Computer -Count 2 -Quiet ) {
				$WMIParam = @{
					ComputerName = $Computer;
					Class = 'Win32_Printjob';
					Namespace = 'root\CIMV2';
					ErrorAction = 'Stop';
				}
				If ( $PSBoundParameters['Credential'] ) {
					$WMIParam.Credential = $Credential;
				}
				Try {
					Get-WmiObject @WMIParam -Filter $WMIFilter | 
					Add-Member -MemberType NoteProperty -Name ComputerName -Value $Computer -PassThru
				} Catch {
					Write-Error $_
				}             
			} Else { 
				Write-Warning "\\$Computer  does NOT reply to ping" 
			}
		} 
	}
}

#============================================================================================================================
	Function Get-PrintJobs {
<#
    .SYNOPSIS
        Return the list of jobs on the current printer
    .DESCRIPTION
        This function returns a list of pending jobs on the specified print server for a given queue
    .PARAMETER ComputerName
        Name of the print sever
    .PARAMETER Name
        Name of the print queue
	.OUTPUTS
		TimeSubmitted REQUIRES GMT Time Adjustment
    .EXAMPLE
        Get-PrintJobs -ComputerName ps -Name HPLJ5000
    .LINK
        https://code.google.com/p/mod-posh/wiki/PrintServerManagement#Get-PrintJobs
#>

		[CmdletBinding()]
		Param (
			$ComputerName,
			$Name
		)
		Begin {
Write-Host "$ComputerName  $Name"
Write-Host "Press any key to continue . . ."
$Host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown,IncludeKeyUp") | Out-Null
			$Host.Runspace.ThreadOptions = "ReuseThread"
			If ((Get-WmiObject -Class Win32_OperatingSystem).OSArchitecture -Eq '64-bit') {
				$SystemPrinting = Get-ChildItem "$($env:systemroot)\assembly\GAC_64\System.Printing"
				$SystemPrintingFile = Get-ChildItem -Name "*system.printing*" -Recurse -Path $SystemPrinting.FullName
				$SystemPrintingFile = "$($SystemPrinting.FullName)\$($SystemPrintingFile)"
			} Else {
				$SystemPrinting = Get-ChildItem "$($env:systemroot)\assembly\GAC_32\System.Printing"
				$SystemPrintingFile = Get-ChildItem -Name "*system.printing*" -Recurse -Path $SystemPrinting.FullName
				$SystemPrintingFile = "$($SystemPrinting.FullName)\$($SystemPrintingFile)"
			}
		}
		Process {
			$ErrorActionPreference = "Stop"
			Try {
				Add-Type -Path $SystemPrintingFile
				$PrintServer = New-Object System.Printing.PrintServer("\\$($ComputerName)")
				$PrintQueue = $PrintServer.GetPrintQueue($Name)
				$PrintJobs = $PrintQueue.GetPrintJobInfoCollection()
			} Catch {
				Write-Error $Error[0].Exception
				Break
			}
		}
		End
		{
			Return $PrintJobs
			}
    }
#============================================================================================================================


#============================================================================================================================
# INITIALIZE

	CLS
#	CMD /C MODE CON: COLS=200 LINES=48

	$VerbosePreference = "SilentlyContinue"							# Disable Write-Verbose Output to Console
#	$VerbosePreference = "Continue"									# Enable  Write-Verbose Output to Console

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

	$WMITime = New-Object -ComObject WbemScripting.SwbemDateTime 

	$StartTime = Get-Date
#	$PrintServerNames = "PPPrint01,PPPrint02,PPPrint03"
#	$PrintServerNames = "EpicPrint01,EpicPrint02,EpicPrint03,EpicPrint04,EpicPrint05,EpicPrint06"
	$ListOjobs = ""
	$DeleteJob = $True
	$BlockJobCount = 0
	$PrinterErroredCount = 0

# Get Formatted TimeStamp
	$JobTimeStamp = Get-Date -Format MMddyyyy_HHmmss
	$DeletedBlockedPrintJobsLog = "\\$PrintMaster\C$\EpicPrintMgt\Reports\DeletedBlockedPrintJobs_"+ $JobTimeStamp +".Log"

#============================================================================================================================
# MAIN


	$PrintersErrored = Get-EPSPrintJob -ComputerName PPPrint01,PPPrint02,PPPrint03 | Where { $_.ConvertToDateTime($_.TimeSubmitted) -lt (Get-Date).AddMinutes(-30) } | Where { $_.JobStatus -Like '*Error*' -Or $_.JobStatus -Like '*Deleting*' -Or $_.JobStatus -Like '*Offline*' }
	$PrinterErroredCount = $PrintersErrored.Count

	$PrintersErrored | Sort-Object -Property HostPrintQueue, Name, [string]TimeSubmitted | ForEach ($_) {
		$PrintServerName = ($_.HostPrintQueue).Replace("\","")
		$PrintJobName = $_.Name.Split(',')[0]
		$BlockedJobs = Get-EPSPrintJob -ComputerName $PrintServerName -PrinterName *$PrintJobName*

		ForEach ( $BlockedJob in $BlockedJobs ) {
			$BlockJobCount++
#			$BlockedJobQueue = $BlockedJob.ComputerName
#			$BlockedJobID = $BlockedJob.JobId
#			$BlockedJobStatus = $BlockedJob.Status
#			$BlockedJobDriver = $BlockedJob.DriverName

			$WMITime.Value = $BlockedJob.TimeSubmitted
			$BlockedJobTime = $WMITime.GetVarDate()
			$BlockedJobJobStatus = $BlockedJob.JobStatus
			$BlockedJobSize = [string][math]::Round($BlockedJob.Size / 1KB, 2) +"KB"
			$BlockedJobPages = $BlockedJob.TotalPages
			$BlockedJobDocument = $BlockedJob.Document

#			Write-Verbose "$PrintServerName  $PrintJobName  $BlockedJobTime  $BlockedJobJobStatus               $BlockedJobSize   $BlockedJobPages  $BlockedJobDocument"
			$ListOjobs += "$PrintServerName  $PrintJobName  $BlockedJobTime  $BlockedJobJobStatus               $BlockedJobSize   $BlockedJobPages  $BlockedJobDocument`r`n"

			If ( $DeleteJob -Eq $True ) { 
				$_.Delete()
				Write-Verbose "DeletingI:  $PrintServerName  $PrintJobName  $BlockedJobTime  $BlockedJobJobStatus               $BlockedJobSize   $BlockedJobPages  $BlockedJobDocument"
			}
		}
		If ( $DeleteJob -Eq $True ) { 
			$_.Delete()
#			$PrintJobName.CancelAllJobs()
			Write-Verbose "DeletingO:  $PrintServerName  $PrintJobName"
		}
	$ListOjobs += "`r`n"
	}


$StopTime = Get-Date
$ElapsedTime = $StopTime - $StartTime

Write-Verbose "Printers Errored  $PrinterErroredCount"
Write-Verbose "Jobs Blocked      $BlockJobCount"
Write-Verbose "Elapsed Seconds   $($ElapsedTime.TotalSeconds)"

$ListOjobs += "`r`n`r`n"
$ListOjobs += "Printers Errored  $PrinterErroredCount`r`n"
$ListOjobs += "Jobs Blocked      $BlockJobCount`r`n"
$ListOjobs += "Elapsed Seconds   $($ElapsedTime.TotalSeconds)`r`n"
$ListOjobs | Out-File $DeletedBlockedPrintJobsLog


Exit 1000
