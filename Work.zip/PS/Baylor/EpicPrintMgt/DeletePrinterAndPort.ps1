#============================================================================================================================
#	D:\PSScripts\Epic\EpicPrintMgt\Scripts\DeletePrinterAndPort.ps1
#============================================================================================================================


# NOTES

# Check PrinterPort exists on EPS
# Check Printer exists on EPS
# Check PortFQDN resolves to IP
# Check PortFQDN resolves to Single IP
# Check IP resolves to PortFQDN
# Check IP Pings
# Check PrinterDriverName is valid
# Check PrinterShareName is "na"
# Check PrinterComment is "na"
# Check PrinterName is "Like" PrinterPortName


#============================================================================================================================
# FUNCTIONS
#============================================================================================================================
	Function CreatePrinterPort {
#	Remove-PrinterPort
		$PrintServer =  $Args[0]																		# PrintServerName
		$NewPort = ([WMICLASS]"\\$PrintServer\ROOT\cimv2:Win32_TCPIPPrinterPort").createInstance()
		$NewPort.Name = $Args[1]																		# PrinterPortName
		$NewPort.HostAddress = $Args[2]																	# PortFQDN
		$NewPort.SNMPEnabled = $Args[3]																	# PortSNMPEnabled
		$NewPort.Protocol = $Args[4]																	# PortProtocol
		$NewPort.Put()
	}

#============================================================================================================================
	Function CreatePrinter {
#	Remove-Printer
		$PrintServer = $Args[0]																			# PrintServerName
		$NewPrinter = ([WMICLASS]"\\$PrintServer\ROOT\cimv2:Win32_Printer").createInstance()
		$NewPrinter.DeviceID = $Args[1]																	# PrinterName
		$NewPrinter.PortName = $Args[2]																	# PrinterPortName
		$NewPrinter.Shared = $Args[3]																	# PrinterShared
		$NewPrinter.ShareName = $Args[4]																# PrinterShareName
		$NewPrinter.DriverName = $Args[5]																# PrinterDriverName
		$NewPrinter.Location = $Args[6]																	# PrinterLocation
		$NewPrinter.Comment = $Args[7]																	# PrinterComment
		$NewPrinter.Put()
	}

#============================================================================================================================
# INITIALIZE

	CLS

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

	$CreatePrinterAndPortJobs = "\\$PrintMaster\C$\EpicPrinterMgt\InProcessing\CreatePrinterAndPortJob.csv"
	$ClearPrinterJobsReport = "\\$PrintMaster\C$\EpicPrinterMgt\Reports\CreatePrinterAndPortReport.csv"

	$NonProdEPSList = "bswEpicPrintT01","bswEpicPrintT02"
	$ProdEPSList = "EPICPRINT01","EPICPRINT02","EPICPRINT03","EPICPRINT04","EPICPRINT05","EPICPRINT06"

	$CTXPrinterDNSZone = ".printer.sw.org"
	$NTXPrinterDNSZone = ".bhcs.pvt"

# Global Printer Settings
	$PortSNMPEnabled = $False
	$PortProtocol = 1

#============================================================================================================================
# MAIN

	Write-Verbose "Creating Printers and Ports . . ."

	$Printers = Import-Csv $CreatePrinterAndPortJobs

	ForEach ( $Printer in $Printers ) {
		$PrintServerName = $Printer.PrintServerName														# PrintServerName
		$PrinterName = $Printer.PrinterName																# PrinterName
		$PrinterPortName= $Printer.PrinterPortName														# PrinterPortName
		$PrinterShareName = $Printer.PrinterShareName													# PrinterShareName
		$PrinterDriverName = $Printer.PrinterDriverName													# PrinterDriverName
		$PrinterLocation = $Printer.PrinterLocation														# PrinterLocation
		$PrinterComment = $Printer.PrinterComment														# PrinterComment

		$EPSName = ""
		If ( $PrintServerName -Match "$ProdEPSList"  -Or  $PrintServerName -Match "$NonProdEPSList" ) { $EPSName = "Single" }
		If ( $PrintServerName -Eq "bswEpicPrintTxx" ) { $EPSName = "NonProdEPSList" }
		If ( $PrintServerName -Eq "bswEpicPrintPxx" ) { $EPSName = "ProdEPSList" }
		If ( $EPSName -Eq "" ) { Exit 300 }

		If ( $PrinterPortName -Like "P-*" ) {
			$PortFQDN = $PrinterPortName + $CTXPrinterDNSZone
		} Else {
			$PortFQDN = $PrinterPortName + $NTXPrinterDNSZone
		}

		If ( $PrinterShareName -Eq "na" -Or  $PrinterShareName -Eq $Null ) { $PrinterShared = $False } Else { $PrinterShared = $True }

		If ( $PrinterComment -Eq "na"  -Or  $PrinterComment -Eq $Null ) { $PrinterComment = "" }


# Branch on EPSName
		Switch ( $EPSName ) {
			"Single" {
				CreatePrinterPort $PrintServerName $PrinterPortName $PortFQDN $PortSNMPEnabled $PortProtocol
				CreatePrinter $PrintServerName $PrinterName $PrinterPortName $PrinterShared $PrinterShareName $PrinterDriverName $PrinterLocation $PrinterComment
				Write-Verbose "Created  $PrintServerName  $PrinterName  $PrinterPortName  $PortFQDN  $PrinterShareName  $PrinterDriverName  $PrinterLocation  $PrinterComment"
			}
			"NonProdEPSList" {
				ForEach ( $NonProdEPS in $NonProdEPSList ) {
					CreatePrinterPort $NonProdEPS $PrinterPortName $PortFQDN $PortSNMPEnabled $PortProtocol
					CreatePrinter $NonProdEPS $PrinterName $PrinterPortName $PrinterShared $PrinterShareName $PrinterDriverName $PrinterLocation $PrinterComment
					Write-Verbose "Created  $NonProdEPS  $PrinterName  $PrinterPortName  $PortFQDN  $PrinterShareName  $PrinterDriverName  $PrinterLocation  $PrinterComment"
			}	}
			"ProdEPSList" {
				ForEach ( $ProdEPS in $ProdEPSList ) {
					CreatePrinterPort $ProdEPS $PrinterPortName $PortFQDN $PortSNMPEnabled $PortProtocol
					CreatePrinter $ProdEPS $PrinterName $PrinterPortName $PrinterShared $PrinterShareName $PrinterDriverName $PrinterLocation $PrinterComment
					Write-Verbose "Created  $ProdEPS  $PrinterName  $PrinterPortName  $PortFQDN  $PrinterShareName  $PrinterDriverName  $PrinterLocation  $PrinterComment"		
			}	}
		}


	}

# Normal Exit
	Exit 0





#============================================================================================================================
# TRASH
EXIT


#<MACRO .PS1 FORMAT NOW>

# CreatePrinterPort  $PrintServerName  $PrinterPortName  $PortFQDN
# CreatePrinterPort 'epicprint01' 'P-19165' 'P-19165.printer.sw.org'

# CreatePrinter  $PrintServerName  $PrinterDriverName  $PrinterPortName  $PrinterShareName  $PrinterLocation  $PrinterComment  $PrinterName
# CreatePrinter 'epicprint01' 'HP Universal Printing PCL 6' 'P-19165' 'na' 'P19165_SSCFM_REG1.102_RTF_T2' 'na' 'P-19165_T2'



#<MACRO .CSV FORMAT FUTURE>

# $PrintServerName  $PrinterName  $PrinterPortName  $PrinterShareName  $PrinterDriverName  $PrinterLocation  $PrinterComment
# "epicprint01","P-17139_T2","P-17139","na","HP Universal Printing PCL 6","P19165_SSCFM_REG1.102_RTF_T2","na"


