	CLS

	$PrinterDriversReport = "D:\PSScripts\EpicPrinters\PrinterDriversReport.csv"
	$PrintersDB = "D:\PSScripts\EpicPrinters\PrintersDB.csv"
	$GetPrinterDrivers = "D:\PSScripts\EpicPrinters\GetPrinterDrivers.txt"

# Check GetPrinterDrivers Exists
	If ( ! ( Test-Path $GetPrinterDrivers ) ) { 
		Write-Host "$GetPrinterDrivers  NOT found"
		Exit 111
	}

# Check GetPrinterDrivers Exists
	If ( ! ( Test-Path $PrintersDB ) ) { 
		Write-Host "$PrintersDB  NOT found"
		Exit 113
	}

# Delete previous Printer Drive Report, if Exists and Accessible
	If ( Test-Path $PrinterDriversReport ) { 
		Try { Remove-Item $PrinterDriversReport -ErrorAction Stop
		} Catch { 
			Write-Host "$PrinterDriversReport  IN use, or NOT accessible"
			Exit 115
		}
	}

	$PrintersDBFileDate = (Get-ChildItem $PrintersDB).LastWriteTime
	Add-Content $PrinterDriversReport ("As of:  " + $PrintersDBFileDate)
	Add-Content $PrinterDriversReport ('"SystemName","Name","PortName","DriverName"')

		ForEach ( $Printer in Get-Content $GetPrinterDrivers ) {
			If ( $Printer -Like "P-*" ) {
				Write-Host "	Searching for $Printer"
#				Get-Content $PrintersDB | Select-String "$Printer" | Write-Host
				Get-Content $PrintersDB | Select-String "$Printer" | Add-Content  $PrinterDriversReport
			}
		}
	Exit 100
