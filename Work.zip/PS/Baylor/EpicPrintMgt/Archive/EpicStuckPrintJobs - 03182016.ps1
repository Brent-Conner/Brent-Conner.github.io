#============================================================================================================================
#	D:\PSScripts\Epic\EpicPrintMgt\Scripts\EpicStuckPrintJobs.ps1
#============================================================================================================================


#============================================================================================================================
# NOTES

#   PowerShell.exe  -ExecutionPolicy Bypass -Noninteractive -NoProfile -Command ". D:\PSScripts\Epic\EpicPrintMgt\Scripts\EpicStuckPrintJobs.ps1; Exit $LASTEXITCODE"

#============================================================================================================================
# INITIALIZE

	CLS

	$VerbosePreference = "SilentlyContinue"								# Disable Write-Verbose Output to Console
#	$VerbosePreference = "Continue"										# Enable  Write-Verbose Output to Console

	$HostName = [system.environment]::MachineName


# Array of PrintServers
#	$PrintServers = "bswEpicPrintP01","EpicPrint01","EpicPrint02","EpicPrint03","EpicPrint04","EpicPrint05","EpicPrint06"
	$PrintServers = "bswEpicPrintP01","bswEpicPrintP02","bswEpicPrintP03","bswEpicPrintP04","bswEpicPrintP05","bswEpicPrintP06","EpicPrint01"

	$PrintServersTotal = ( $PrintServers ).Count

	$StaleMinutes = 5													# Min=Hrs: 1440=24  720=12  360=6
	$PrinterErroredTotal = 0
	$JobErroredTotal = 0
	$AuthorDate = "03/03/2015"
	$SendReportTime = "04:00:00"										# TimeofDay to email report as:  "HH:mm:ss"

	$OfflinePrinters = @()												# Initialize Array Structure for OfflinePrinters

	$PrintJobs = @()													# Initialize Array Structure for PrintJobs
	$PrintJob = @{														# Initialize HashTable Object for individual PrintJobs
		'ServerName' = ""
		'PrinterName' = ""
		'PrinterPings' =""
		'JobID' = ""
		'JobTime' = ""
		'JobStatus' =  ""
		'DocName' =  ""
		'DocSize' =  ""
		'DocPages' =  ""
		'PrintDriver' =  ""
	}

	$StartTime = Get-Date

	$Image = "\\$HostName\D$\PSScripts\Epic\Reports\HTML\EpicStuckPrintJobs\StuckPrintJobs.jpg"
	$StuckPrintJobsUNC = "\\$HostName\D$\PSScripts\Epic\Reports\HTML\EpicStuckPrintJobs\EpicStuckPrintJobs.html"
	$StuckPrintJobsURL = "http://$HostName.swntdomain.sw.org/EpicStuckPrintJobs/EpicStuckPrintJobs.html"

# SwbemDateTime is used to make TimeSubmitted readable
	$WMITime = New-Object -ComObject WbemScripting.SwbemDateTime

#============================================================================================================================
# MAIN


# Get Task Frequency
	$ScriptName = ( $MyInvocation.MyCommand.Name ).Split('.')[0]
	$RepeatEvery = [string]( SchTasks.exe /Query /TN $ScriptName /V /FO List | Select-String "Repeat: Every:" )
	$RepeatEvery = (( $RepeatEvery ).split(',')[1] ).split(' ')[1]

# The HTMLHeader variable sets up the BODY Background, TABLE Background, Headers, and Forground of the HTML Document
	$HTMLHeader  = '<style type="text/css">'
	$HTMLHeader += "BODY{color:white;background-color:black;}"																		# Body White/Black
	$HTMLHeader += "TABLE{border-width:1px;border-style:solid;border-color:white;border-collapse:collapse;}"						# Table Borders
	$HTMLHeader += "TH{border-width:1px;padding:0px;border-style:solid;border-color:white;color:black;background-color:gray}"		# Table Headers White/Gray
	$HTMLHeader += "TD{border-width:1px;padding:5px;border-style:solid;border-color:white;color:white;background-color:black}"		# Table Cells White/Black
	$HTMLHeader += "h3{color:white;font-size:100%;}"																				# Normal Cell
#	$HTMLHeader += "tr:nth-child(even) {background-color:black}"																	# NOT working
#	$HTMLHeader += "tr:nth-child(odd) {background-color:white}"																		# NOT working
	$HTMLHeader += "</style>"
	$HTMLHeader += '<meta http-equiv="refresh" content="300" />'																	# Browser Refresh interval
	$HTMLHeader += '<meta http-equiv="cache-control" content="no-cache" />'															# Browser No-cache flag
	$HTMLHeader += '<title>Epic Stuck Print Jobs</title>'																			# TAB Page Title

# Encode image ( Corporate Logo, Banner, or BCA Workstation Image )
	$ImageBits = [Convert]::ToBase64String(( Get-Content $Image -Encoding Byte ))

# HTMLPre sets up the Pre-Content of the HTML page
	$HTMLPre  = ""
	$HTMLPre += "<img src=data:image/png;base64,$($ImageBits) alt='Stuck Job' height='145' width='300'/>"
	$HTMLPre += "<h1>Epic Stuck Print Jobs</h1>"
	$HTMLPre += "<h3>Last Update at:  $StartTime</h3>"

# HTMLBody sets up the Table-Content of the HTML page
	$HTMLBody  = $HTMLPre
	$HTMLBody += "<table><tr><th><a href=`"$StuckPrintJobsUNC`">Server Name</a></th><th>Printer</th><th>Online</th><th>Job ID</th><th>Time Submitted</th><th>Status</th><th>Document Name</th><th>Size</th><th>Total Pages</th><th>Print Driver</th></tr>"

# HTML SummaryTable for PrintServer Statistics
	$HTMLSummary = "<table><br /><br /><tr><th>PrintServer Name</th><th>Printers Offline</th><th>Printers Stuck</th><th>Jobs Stuck</th>"


# Query each PrintServer in list
	ForEach ( $PrintServer in $PrintServers ) {
		$JobErroredCount = 0
		$PrinterErroredCount = 0
		$OfflinePrintersCount = 0
		If ( Test-Connection -ComputerName $PrintServer -Count 1 -Quiet ) {

# Get all Stuck Printers with Jobs older than StaleMinutes on PrintServer
			Try {
				$PrintersErrored = Get-WMIObject -ComputerName $PrintServer -class "Win32_PrintJob" -namespace "root\CIMV2"  | Where { $_.JobStatus -Like '*Error*' -Or $_.JobStatus -Like '*Deleting*' -Or $_.JobStatus -Like '*Offline*' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -lt (Get-Date).AddMinutes(-($StaleMinutes)) }

# Get all Blocked PrintJobs for each Stuck PrintJob
				$PrintersErrored | Sort-Object -Property Name, [string]TimeSubmitted | ForEach {
					$PrinterErroredCount ++
					$PrinterName = $_.Name.Split(',')[0]
					$PrinterFQDN = ( $PrinterName ).Split('_')[0] +".printer.sw.org"
					If ( Test-Connection -ComputerName $PrinterFQDN -Count 1 -Quiet ) {
						$PrinterFQDNOnline = "Online"
					} Else {
						$PrinterFQDNOnline = "Offline"
						$OfflinePrintersCount ++
						$OfflinePrinters += $PrinterName
					}
					Try {
						Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServer | Where { $_.Name -Like "*$PrinterName*" }  | ForEach {
							$JobErroredCount ++
#							$PS = $_.PSComputerName
							$Job = $_.JobID
							$Status = $_.JobStatus
#							$PrinterName = $_.Name.Split(",")[0]
							$Size = [string][math]::Round($_.Size / 1KB, 2) +"KB"
							$PagesPrinted = $_.PagesPrinted
							$Driver = $_.DriverName
							$DocName = $_.Document.Split("\")[6]
							$TotalPages = $_.TotalPages

# Convert TimeSubmitted to readable format
							$WMITime.Value = $_.TimeSubmitted
							$JobTime = $WMITime.GetVarDate()

# Add content to HTMLBody
							If ( $PrinterFQDNOnline -Eq "Online" ) {
								$HTMLBody += "<tr><td>$PrintServer</td><td>$PrinterName</td><td><font color='green'>$PrinterFQDNOnline</font></td><td><div align='right'>$Job</div></td><td>$JobTime</td><td><font color='yellow'>$Status</font></td><td>$DocName</td><td><div align='right'>$Size</div></td><td><div align='center'>$TotalPages</div></td><td>$Driver</td></tr>"
							} Else {
								$HTMLBody += "<tr><td>$PrintServer</td><td>$PrinterName</td><td><font color='yellow'>$PrinterFQDNOnline</font></td><td><div align='right'>$Job</div></td><td>$JobTime</td><td><font color='yellow'>$Status</font></td><td>$DocName</td><td><div align='right'>$Size</div></td><td><div align='center'>$TotalPages</div></td><td>$Driver</td></tr>"
							}

# Build HashTable Object, then add to Array Structure
							$PrintJob.ServerName = $PrintServer
							$PrintJob.PrinterName = $PrinterName
							$PrintJob.PrinterPings = $PrinterFQDNOnline
							$PrintJob.JobID = $Job
							$PrintJob.JobTime = $JobTime
							$PrintJob.JobStatus = $Status
							$PrintJob.DocName = $DocName
							$PrintJob.DocSize = $Size
							$PrintJob.DocPages = $TotalPages
							$PrintJob.PrintDriver = $Driver
							$PrintJobs += New-Object �TypeName PSObject -Property $PrintJob
						}
					} Catch {}
				}
			} Catch {}
		}
		$PrinterErroredTotal += $PrinterErroredCount
		$JobErroredTotal += $JobErroredCount

# Append PrintServer Statistics to SummaryTable
		$HTMLSummary += "<tr><td>$PrintServer</td><td><div align='center'><font color='yellow' size='3'>$OfflinePrintersCount</font></div></td><td><div align='center'><font color='yellow' size='3'>$PrinterErroredCount</font></div></td><td><div align='center'><font color='yellow' size='3'>$JobErroredCount</font></div></td></tr>"
	}

	$OfflinePrintersTotal = ( $OfflinePrinters  | Sort-Object -Unique ).Count

# Append PrintServer Totals to SummaryTable
	$HTMLSummary += "<tr><th>Total PrintServers</th><th>Total Printers Offline</th><th>Total Printers Stuck</th><th>Total Jobs Stuck</th></tr>"
	$HTMLSummary += "<tr><td><div align='center'>$PrintServersTotal</div></td><td><div align='center'><font color='yellow' size='3'>$OfflinePrintersTotal</font></div></td><td><div align='center'><font color='yellow' size='3'>$PrinterErroredTotal</font></div></td><td><div align='center'><font color='yellow' size='3'>$JobErroredTotal</font></div></td></tr>"
	$HTMLSummary += "</table><br /><br />"

	$HTMLBody += "</table><br /><br />"
	$HTMLBody += $HTMLSummary

	$StopTime = Get-Date
	$ElapsedTotalSeconds = [int]( $StopTime - $StartTime ).TotalSeconds

	$HTMLPost  = "<br /><hr color='yellow' />"
	$HTMLPost += "<h3><br /><br />Jobs Older than:  $StaleMinutes min<br /></h3>"
	$HTMLPost += "<h3>Data Refreshed every: $RepeatEvery minutes</h3>"
	$HTMLPost += "<h3>Elapsed Seconds:   $ElapsedTotalSeconds</h3>"
#	$HTMLPost += "<h3><br /><br />For details, contact Ed Tomlinson</h3>"
	$HTMLPost += "<h3><br /><br />Created on $AuthorDate by the Baylor Scott &amp; White Epic Tech Team</h3>"

# Convert to HTML and output to the StuckPrintJobsUNC file
	ConvertTo-HTML -Head $HTMLHeader -Body $HTMLBody -Post $HTMLPost | Out-File $StuckPrintJobsUNC

	Write-Verbose "Total Print Servers     $PrintServersTotal"
	Write-Verbose "Total Printers Offline  $OfflinePrintersTotal"
	Write-Verbose "Total Printers Stuck    $PrinterErroredTotal"
	Write-Verbose "Total Jobs Stuck        $JobErroredTotal"
	Write-Verbose "Elapsed Seconds         $ElapsedTotalSeconds"


	# Email Report at specified time
	If ( $StartTime -Ge [datetime]$SendReportTime  -And  $StartTime -Lt ( [datetime]$SendReportTime ).AddMinutes( $RepeatEvery )) {
		$MailMessage = @{
#			To = "ETomlinson@sw.org"
			To = "ETomlinson@sw.org", "SButton@sw.org", "MDBrooks@sw.org"
			From = "$ScriptName@$HostName.sw.org"
			Subject = "Epic Stuck Print Jobs -  Printers OfflineCount  $OfflinePrintersTotal"
			Body = "Epic Stuck Print Jobs Report`n$StuckPrintJobsURL`n`n`nIf you wish to be removed from this distribution, please contact the Epic Technical Team"
			Attachments = $StuckPrintJobsUNC
			SmtpServer = "smtp.sw.org"
		}
		Try {
			Send-MailMessage @MailMessage -ErrorAction Stop
		} Catch {
			Write-Host "SMTP failure"
			Exit 190
	}	}


# Normal Exit
	Exit 0
