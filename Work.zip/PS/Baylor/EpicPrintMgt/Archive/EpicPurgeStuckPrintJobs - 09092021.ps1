#============================================================================================================================
#	C:\Scripts\EpicPrintMgt\EpicPurgeStuckPrintJobs.ps1
#============================================================================================================================

#============================================================================================================================

#   PowerShell.exe  -ExecutionPolicy Bypass -Noninteractive -NoProfile -Command ". C:\Scripts\EpicPrintMgt\EpicPurgeStuckPrintJobs.ps1; Exit $LASTEXITCODE"


#	CHANGE LOG
#	


#============================================================================================================================
# INITIALIZE


	CLS

	$VerbosePreference = "SilentlyContinue"																				# Disable Write-Verbose Output to Console
#	$VerbosePreference = "Continue"																						# Enable  Write-Verbose Output to Console

	$HostName = [system.environment]::MachineName																		# Server Name
	$HostFQDN = $HostName + ".$(( Get-WmiObject Win32_ComputerSystem ).Domain)"											# Server FQDN

# Array of PrintServers
	$PrintServers = "bswEpicEPSP113","bswEpicEPSP112","bswEpicEPSP111","bswEpicEPSP110","bswEpicEPSP109","bswEpicEPSP108","bswEpicEPSP107","bswEpicEPSP106","bswEpicEPSP105","bswEpicEPSP104","bswEpicEPSP103","bswEpicEPSP102","bswEpicEPSP101"
	$PrintServersTotal = ( $PrintServers ).Count

	$DeleteJob = $True																									# Safety Check
	$StaleMinutes = 300																									# Min=Hrs: 4320=72 1440=24  840=14  720=12  360=6  300=5:00am
	$StaleMinutesNow = $StaleMinutes
	$PassNumber = 0
	$SecondsBetweenPasses = 120																							# Delay between passes to allow time for jobs to delete
#	$MaxRunMinutes = 50																									# Timelimit for this script to run
	$MaxRunMinutes = 120																								# Timelimit for this script to run
	$MaxLogDays = 90																									# Log retention in Days
	$PurgedGrandTotal = 0

	$StartTime = $(Get-Date)
	$JobTimeStamp = Get-Date -Format MMddyyyy_HHmmss
	$LogFolder = "\\$HostName\C$\Scripts\EpicPrintMgt\Logs"
	$PurgeStuckPrintJobsLog = "$LogFolder" +"\PurgeStuckPrintJobs_"+ $JobTimeStamp +".Log"

# SwbemDateTime is used to make TimeSubmitted readable
	$WMITime = New-Object -ComObject WbemScripting.SwbemDateTime


#============================================================================================================================
# MAIN


# Get Task StartTime
#	$PassMaxTime = $StartTime.Addminutes( $MaxRunMinutes )
	$ScriptName = ( $MyInvocation.MyCommand.Name ).Split('.')[0]
	$TaskStartTime = [DateTime](([string]( SchTasks.exe /Query /TN $ScriptName /V /FO List | Select-String "Start Time:" ) -Split '\s+')[2])
	$PassMaxTime = $TaskStartTime.Addminutes( $MaxRunMinutes )

	Do {
		$PassNumber ++
		$PrintServerTotal = 0
		$PrintesrStuckTotal = 0
		$PurgedJobTotal = 0
		$PassStartTime = Get-Date
		$PurgedPrintJobs = "`r`n$PassStartTime`t`tDelete Stuck Print Jobs > $StaleMinutesNow minutes`r`n`r`n"
		Write-Verbose "`r`n$PassStartTime`t`tDelete Stuck Print Jobs > $StaleMinutesNow minutes`r`n`r`n"

		ForEach ( $PrintServer in $PrintServers ) {
			If ( Test-Connection -ComputerName $PrintServer -Count 1 -Quiet ) {
				$PrintServerTotal ++
				Try {
					$PrintersErrored = Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServer | Where { $_.JobStatus -Like '*Error*'  -OR  $_.JobStatus -Like '*Deleting*'  -OR  $_.JobStatus -Like '*Offline*' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -lt (Get-Date).AddMinutes(-($StaleMinutesNow)) }
					$PrintersErrored | Sort -Property Name, [string]TimeSubmitted | ForEach {
						$PrintesrStuckTotal ++
						$WMITime.Value = $_.TimeSubmitted
						$StuckJobTime = $WMITime.GetVarDate()
						$StuckJobSize = [string][math]::Round($_.Size / 1KB, 2) +"KB"
						$StuckJobStatus = $_.JobStatus
						$StuckJobPages = $_.TotalPages
						$StuckJobDocument = $_.Document
						$PrinterName = $_.Name.Split(',')[0]
						$PrinterFQDN = ($PrinterName).Split('_')[0] +".printer.sw.org"
						If ( Test-Connection -ComputerName $PrinterFQDN -Count 1 -Quiet ) { $PrinterFQDNOnline = "Online" } Else { $PrinterFQDNOnline = "Offline" }

# If ( $PrinterFQDNOnline -Eq "Offline" ) { Delete & Log all Jobs at once } Else { Try ... }

						Try {
							$BlockedJobs = Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServer  | Where { $_.Name -Like "$PrinterName*" }
							ForEach ( $BlockedJob in $BlockedJobs) {
								If ( $DeleteJob ) { $ReturnValue = $_.Pause() }
								$PurgedJobTotal ++
								$PurgedGrandTotal ++
								$WMITime.Value = $BlockedJob.TimeSubmitted
								$BlockedJobTime = $WMITime.GetVarDate()
								$BlockedJobSize = [string][math]::Round($BlockedJob.Size / 1KB, 2) +"KB"
								$BlockedJobJobStatus = $BlockedJob.JobStatus
								$BlockedJobPages = $BlockedJob.TotalPages
								$BlockedJobDocument = $BlockedJob.Document
								Write-Verbose "$PrintServer  $PrinterName  $BlockedJobTime  $BlockedJobJobStatus           $BlockedJobSize   $BlockedJobPages`r`n         $BlockedJobDocument`r`n"
# Delete innocent blocked Job(s)
								If ( $DeleteJob  -And  !( $BlockedJobJobStatus -Like '*Error*'  -OR  $BlockedJobJobStatus -Like '*Deleting*'  -OR  $BlockedJobJobStatus -Like '*Offline*' )) {
									$ReturnValue = $_.Delete()
									$PurgedPrintJobs += "$PrintServer  $PrinterName`t$PrinterFQDNOnline`t$BlockedJobTime  $BlockedJobJobStatus`t`t`t`t`t`t`t$BlockedJobSize`t $BlockedJobPages`t $BlockedJobDocument`r`n"
									Write-Verbose "DeletingI:  $PrintServer  $PrinterName`t$PrinterFQDNOnline`t$BlockedJobTime  $BlockedJobJobStatus`t`t`t`t`t`t`t$BlockedJobSize`t $BlockedJobPages`r`n         $BlockedJobDocument`n"
								}
							}
						} Catch { Write-Verbose "Get-WmiObject Win32_PrintJob Error on  $PrintServer`r`n" }
# Delete guilty stuck Job
# ??? If this is the only Job ???
						If ( $DeleteJob ) {
							$ReturnValue = $_.Delete()
							$PurgedPrintJobs += "$PrintServer  $PrinterName`t$PrinterFQDNOnline`t$StuckJobTime  $StuckJobStatus`t`t`t$StuckJobSize`t $StuckJobPages`t $StuckJobDocument`r`n`r`n"
							Write-Verbose "DeletingO:  $PrintServer  $PrinterName`t$PrinterFQDNOnline`t$StuckJobTime  $StuckJobStatus`t`t`t$StuckJobSize    $StuckJobPages`r`n         $StuckJobDocument`n`n"
						}
					}
				} Catch { Write-Verbose "Get-WmiObject Win32_PrintJob Error on  $PrintServer`r`n" }
			}
		}

		$PassStopTime = Get-Date
		$ElapsedPassTime = $PassStopTime - $PassStartTime
		$PurgedPrintJobs += "`r`n"
		$PurgedPrintJobs += "Pass Number             $PassNumber`r`n"
		$PurgedPrintJobs += "Elapsed Seconds         $($ElapsedPassTime.TotalSeconds)`r`n"
		$PurgedPrintJobs += "Not to Exceed           $PassMaxTime`r`n"
		$PurgedPrintJobs += "Total Print Servers     $PrintServerTotal`r`n"
		$PurgedPrintJobs += "Total Printers Stuck    $PrintesrStuckTotal`r`n"
		$PurgedPrintJobs += "Total Jobs Purged       $PurgedJobTotal`r`n"
		$PurgedPrintJobs | Out-File -Append $PurgeStuckPrintJobsLog

		Write-Verbose "Total Print Servers     $PrintServerTotal"
		Write-Verbose "Total Printers Stuck    $PrintesrStuckTotal"
		Write-Verbose "Total Jobs Purged       $PurgedJobTotal"
		Write-Verbose "Elapsed Seconds         $($ElapsedPassTime.TotalSeconds)`r`n"

		Sleep -s $SecondsBetweenPasses
		$ElapsedTotalMinutes = ( (Get-Date) - $StartTime ).TotalMinutes
		$StaleMinutesNow = $StaleMinutes + $ElapsedTotalMinutes

	} While ( $PurgedJobTotal -Gt 0  -And  $PassStopTime -Lt $PassMaxTime )


# Close Log
	$PurgedPrintJobs = "`r`n`r`n"
	$PurgedPrintJobs += "Elapsed Minutes         $ElapsedTotalMinutes`r`n"
	$PurgedPrintJobs += "Grand Total Purged      $PurgedGrandTotal"
	$PurgedPrintJobs | Out-File -Append $PurgeStuckPrintJobsLog

# Cleanup old logs
	$MaxDate = $StartTime.AddDays(-$MaxLogDays)
	If ( Test-Path $LogFolder ) { Get-ChildItem $LogFolder PurgeStuckPrintJobs_*.Log -Force | Where { $_.LastWriteTime -Lt $MaxDate } | Remove-Item -Recurse -Force }


# Normal Exit
	Exit 0
