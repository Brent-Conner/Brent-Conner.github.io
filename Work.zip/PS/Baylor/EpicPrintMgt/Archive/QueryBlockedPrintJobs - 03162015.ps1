#============================================================================================================================
#	QueryBlockedPrintJobs_v2.ps1
#============================================================================================================================


#============================================================================================================================
# INITIALIZE

	CLS

#	$VerbosePreference = "SilentlyContinue"							# Disable Write-Verbose Output to Console
	$VerbosePreference = "Continue"									# Enable  Write-Verbose Output to Console

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

#	$PrintServers = "PPPrint01", "PPPrint02", "PPPrint03"
	$PrintServers = "EpicPrint01", "EpicPrint02", "EpicPrint03", "EpicPrint04", "EpicPrint05", "EpicPrint06"

	$DeleteJob = $False
	$StaleMinutes = -1440
	$PrintServerCount = 0
	$PrinterErroredCount = 0
	$BlockedJobCount = 0
	$BlockedPrintJobs = ""

	$WMITime = New-Object -ComObject WbemScripting.SwbemDateTime 

	$JobTimeStamp = Get-Date -Format MMddyyyy_HHmmss
	$QueryBlockedPrintJobsLog = "\\$PrintMaster\C$\EpicPrintMgt\Reports\QueryBlockedPrintJobs_"+ $JobTimeStamp +".Log"

#============================================================================================================================
# MAIN


	$StartTime = Get-Date

	ForEach ( $PrintServer in $PrintServers ) {

# Validate PrintServer Pings
#		If ( Test-Connection -ComputerName $PrintServer -Count 1 -Quiet ) {

			$PrintServerCount++
			$PrintersErrored = Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServer | Where { $_.JobStatus -Like '*Error*' -Or $_.JobStatus -Like '*Deleting*' -Or $_.JobStatus -Like '*Offline*' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -lt (Get-Date).AddMinutes($StaleMinutes) }
			$PrintersErrored | Sort-Object -Property HostPrintQueue, Name, [string]TimeSubmitted | ForEach {
				$PrinterErroredCount++
				$PrintServerName = ($_.HostPrintQueue).Replace("\","")
				$PrinterName = $_.Name.Split(',')[0]
				$BlockedJobs = Get-WmiObject -Class "Win32_PrintJob" -Namespace "root\CIMV2" -ComputerName $PrintServerName  | Where { $_.Name -Like "*$PrinterName*" }

				ForEach ( $BlockedJob in $BlockedJobs) {
					$BlockedJobCount++
					$WMITime.Value = $BlockedJob.TimeSubmitted
					$BlockedJobTime = $WMITime.GetVarDate()
					$BlockedJobJobStatus = $BlockedJob.JobStatus
					$BlockedJobSize = [string][math]::Round($BlockedJob.Size / 1KB, 2) +"KB"
					$BlockedJobPages = $BlockedJob.TotalPages
					$BlockedJobDocument = $BlockedJob.Document

					Write-Verbose "$PrintServerName  $PrinterName  $BlockedJobTime  $BlockedJobJobStatus           $BlockedJobSize   $BlockedJobPages`r`n         $BlockedJobDocument`r`n"
					$BlockedPrintJobs += "$PrintServerName  $PrinterName  $BlockedJobTime  $BlockedJobJobStatus           $BlockedJobSize   $BlockedJobPages  $BlockedJobDocument`r`n"
				}
			$BlockedPrintJobs += "`r`n"
			}
#		}
	}


	$StopTime = Get-Date
	$ElapsedTime = $StopTime - $StartTime

	Write-Verbose "Total Print Servers     $PrintServerCount"
	Write-Verbose "Total Printers Stuck    $PrinterErroredCount"
	Write-Verbose "Total Jobs Stuck        $BlockedJobCount"
	Write-Verbose "Elapsed Seconds         $($ElapsedTime.TotalSeconds)"

	$BlockedPrintJobs += "`r`n`r`n"
	$BlockedPrintJobs += "Total Print Servers     $PrintServerCount`r`n"
	$BlockedPrintJobs += "Total Printers Stuck    $PrinterErroredCount`r`n"
	$BlockedPrintJobs += "Data Refreshed every    5 minutes"
	$BlockedPrintJobs += "Elapsed Seconds         $($ElapsedTime.TotalSeconds)"
	$BlockedPrintJobs | Out-File $QueryBlockedPrintJobsLog


	Exit 0
