﻿#============================================================================================================================
#	C:\Scripts\EpicPrintMgt\StuckPrintJobs.ps1
#============================================================================================================================


#   PowerShell.exe  -ExecutionPolicy Bypass -Noninteractive -NoProfile -Command ". C:\Scripts\EpicPrintMgt\StuckPrintJobs.ps1; Exit $LASTEXITCODE"

#	http://bswEpicMonP101.bhcs.pvt/EpicStuckPrintJobs/StuckPrintJobs.html


#	CHANGE LOG
#	02/20/2017	Added		Offline_xxHrs & Offline_xxDays ( Tracks NOT_in_DNS status also )
#	02/20/2017	Added		Blank values for Blocked Jobs ( IP, Pings, Driver )
#	02/20/2017	Optimized	Code and Variables
#	02/20/2017	Added		IPAddress DNS Lookup
#	03/07/2017	Migrated	to bswEpicMonP01
#	03/21/2017	Added		FavIcon
#	04/05/2017	Added		PrinterIPColor & PrinterOnlineStatusColor
#	04/05/2017	Added		EpicVerDotP0 from ConfigXMLFileName
#	10/03/2017	Added		JobsFailedCount
#	10/03/2017	Refactored	VariablesNames
#	10/04/2017	Refactored	using Create-HTMLTable $HTMLRows
#	10/04/2017	Added		JobStatusColor
#	10/04/2017	Added		PrinterJobSummary
#	10/04/2017	Refactored	using Create-HTMLTableSummary $HTMLRowsSUM
#	05/08/2018	Relocate	PrintersOffLineCSV file
#	07/11/2018	Updated		New MainStreet Epic Print Servers ( Commented out Temple servers )
#	07/30/2018	Updated		email using FROM:BSWHealth.org
#	08/06/2018	Refactor	HostFQDN
#	08/06/2018	Added		PrinterFQDN to HTML
#	08/06/2018	Refactored	PrinterFQDN
#	08/06/2018	Added		PrinterWebAdminURL
#	08/06/2018	Refactored	PrinterName  TO  PrinterQName
#	08/06/2018	Refactored	PrinterName  AS  Printer DNS HostName
#	08/07/2018	Added		PrinterNameReplyIP
#	08/07/2018	Refactored	IP
#	08/07/2018	TuneUp		Small tweaks here and there ( JobStatus = "^", etc, ... )
#	08/07/2018	Refactored	Test-Connection  TO  Get-WmiObject Win32_PingStatus  for speedup No-Reply
#	03/02/2019	Removed		JobsFailedCount, JobsFailedTotal  ( Epic v2018 related )
#	05/29/2019	Removed		Jobs Failed Columns
#	05/29/2019	Removed		EpicVerDotP0 & ConfigXMLFileName
#	03/11/2020	Added		PagesPrinted
#	03/11/2020	Fixed		DocumentName
#	03/11/2020	Added		DebugLog
#	03/11/2020	Added		PrintersErroredCount
#	04/08/2020	Fixed		Major Bugs


#	FUTURE ENHANCEMENTS
#				Refactor	Test-Connection
#				Refactor	Get-CimInstance
#				Fix			Sort [string]TimeSubmitted  (  Maybe Not ?? )
#				Query		AD for Epic EPS servers list
#				Fix			Low Confidence in PrinterOnlineStatus Times
#				Add			PrinterWebAdminURL Validation
#				Add			PrintersOffLineCSV HTML link
#				Fix			$NotInDNSPrintersTotal in email
#				Fix 		$NotInDNSPrinters not appearing in email


#============================================================================================================================
# FUNCTIONS


#1 Build Table1 Rows - Conditionally vary color, size and alignment					'$($_.PrinterIPColor)'
	Function Create-HTMLTable {
		Param ( $TableRowObject )
		$Global:HTMLRows  = "<tr>"
		$TableRowObject | ForEach {
			$Global:HTMLRows += "<td><font color='White' size='2'>$($_.ServerName)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'>$($_.PrinterQName)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'><div align='center'>$($_.PrinterQNameStuckJobsCount)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'>$($_.PrinterFQDN)</font></td>"
			$Global:HTMLRows += "<td><font color='$($_.PrinterIPColor)' size='2'>$($_.PrinterIP)</font></td>"
			$Global:HTMLRows += "<td><font size='2'><a style='Color:White);' href=$($_.PrinterWebAdminURL) target='_blank'>$($_.PrinterWebAdminName)</a></font></td>"
			$Global:HTMLRows += "<td><font color='$($_.PrinterOnlineStatusColor)' size='2'><div align='center'>$($_.PrinterOnlineStatus)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'><div align='right'>$($_.JobID)</div></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'>$($_.JobTime)</font></td>"
			$Global:HTMLRows += "<td><font color='$($_.JobStatusColor)' size='2'>$($_.JobStatus)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'>$($_.DocName)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'><div align='right'>$($_.DocSize)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'><div align='center'>$($_.DocPages)</font></td>"
			$Global:HTMLRows += "<td><font color='White' size='2'>$($_.PrintDriver)</font></td>"
			$Global:HTMLRows += "</tr>"
		}
		Return
	}


#1 Build Table2 Rows - Conditionally vary color, size and alignment
	Function Create-HTMLTableSummary {
		Param ( $TableRowObject )
		$Global:HTMLRowsSUM  = "<tr>"
		$TableRowObject | ForEach {
			$Global:HTMLRowsSUM += "<td><font color='White' size='2'>$($_.ServerName)</font></td>"
			$Global:HTMLRowsSUM += "<td><div align='center'><font color='yellow' size='3'>$($_.OfflinePrintersCount)</font></div></td>"
			$Global:HTMLRowsSUM += "<td><div align='center'><font color='yellow' size='3'>$($_.PrinterErroredCount)</font></div></td>"
			$Global:HTMLRowsSUM += "<td><div align='center'><font color='yellow' size='3'>$($_.JobErroredCount)</font></div></td>"
#			$Global:HTMLRowsSUM += "<td><div align='center'><font color='yellow' size='3'>$($_.JobsFailedCount)</font></div></td>"
			$Global:HTMLRowsSUM += "</tr>"
		}
		Return
	}


#============================================================================================================================
# INITIALIZE


	CLS

	$StartTime = $(Get-Date)
	$AuthorDate = "03/03/2015"

	$HostName = [system.environment]::MachineName																		# Host Name
	$HostFQDN = $HostName + ".$(( Get-WmiObject Win32_ComputerSystem ).Domain)"											# Host FQDN
	$ScriptPath = Split-Path $Script:MyInvocation.MyCommand.Path														# Path to Script  ( Drive:\Path\Folder )
	$ScriptPathUNC = "\\"+ $HostFQDN +"\"+ $ScriptPath.Replace(':','$')													# UNC Path to Script  ( \\HostFQDN\Drive$\Path\Folder )

# Get Task Frequency
	$ScriptName = ( $MyInvocation.MyCommand.Name ).Split('.')[0]
	Try {
		$ScheduledTaskInfo = Get-ScheduledTaskInfo -EA Stop $ScriptName
		$RepeatEvery = [int]( $ScheduledTaskInfo.NextRunTime - $ScheduledTaskInfo.LastRunTime ).TotalMinutes
	 } Catch {}

	$Debug = 0																											# Set to Debug Logging Level ( 0=Disable, 1=Low, 2=Medium, 3=High, 4=Extreme )
	Switch ( $Debug ) {
		0       { $VerbosePreference = "SilentlyContinue" }																# Disable Write-Verbose Output to Console
		Default { $VerbosePreference = "Continue" }																		# Enable  Write-Verbose Output to Console
	}
	$DebugLog = "\\$HostFQDN\C$\Scripts\EpicPrintMgt\StuckPrintJobsDebug.log"											# Debug Log

# Test for existence of Epic_COMMON_Config.XML file with Custom settings
#	$ConfigXMLFileName = "C:\Scripts\Common_ConfigData\Epic_COMMON_Config.xml"											# Common Config Items .XML
#	If ( !( Test-Path $ConfigXMLFileName )) { Exit 103 }

# Read ConfigXMLFileName and [cast] Settings
#	[xml]$ConfigXML = Get-Content $ConfigXMLFileName																	# Read and assign configuration settings from XML file
#	[string]$EpicVerDotP0 = $ConfigXML.Settings.EpicVerDotP0															# Epic Version Dotted ( Current )

	$SendMail = $False
	$ExitCode = 0

# Array of PrintServers
#	$PrintServers = "bswEpicEPSP201","bswEpicEPSP202","bswEpicEPSP203","bswEpicEPSP204","bswEpicEPSP205","bswEpicEPSP206","bswEpicEPSP207","bswEpicEPSP208","bswEpicEPSP209","bswEpicEPSP210","bswEpicEPSP211","bswEpicEPSP212","bswEpicEPSP213"
	$PrintServers = "bswEpicEPSP101","bswEpicEPSP102","bswEpicEPSP103","bswEpicEPSP104","bswEpicEPSP105","bswEpicEPSP106","bswEpicEPSP107","bswEpicEPSP108","bswEpicEPSP109","bswEpicEPSP110","bswEpicEPSP111","bswEpicEPSP112","bswEpicEPSP113"
#	$PrintServers = "bswEpicEPSP101"
	$PrintServersTotal = $PrintServers.Count

	$StaleMinutes = 5																									# Hrs:Min 24:1440  12:720  6:360
	$PrinterErroredTotal = 0
	$JobErroredTotal = 0
	$SendReportTime = "04:00:00"																						# TimeofDay to email report as:  "HH:mm:ss"

	$PrintJobs = @()																									# Initialize Array Structure for PrintJobs
	$PrinterJobSummary = @()																							# Initialize Array Structure for PrinterJobSummary
	$OfflinePrinters = @()																								# Initialize Array Structure for OfflinePrinters

	$FavIcon = "http://$HostFQDN/EpicStuckPrintJobs/StuckPrintJob_favicon.ico"											# Browser Tab FavIcon URL
	$ImageUNC = "\\$HostFQDN\C$\Scripts\Reports\HTML\Images\StuckPrintJobs.jpg"											# Image Logo UNC
	$ImageEncoded = [Convert]::ToBase64String(( Get-Content $ImageUNC -Encoding Byte ))									# Image Logo Encoded

	$StuckPrintJobsURL = "http://$HostFQDN/EpicStuckPrintJobs/StuckPrintJobs.html"
	$StuckPrintJobsUNC = "\\$HostFQDN\C$\Scripts\Reports\HTML\EpicStuckPrintJobs\StuckPrintJobs.html"
	$PrintersOffLineCSV = "\\$HostFQDN\C$\Scripts\Reports\HTML\EpicStuckPrintJobs\PrintersOffline.csv"					# PrintersOffLine .csv UNC
	$PrintersOffLineURL = "http://$HostFQDN/EpicStuckPrintJobs/PrintersOffline.csv"										# PrintersOffLine .csv URL

# SwbemDateTime is used to make TimeSubmitted readable
	$WMITime = New-Object -ComObject WbemScripting.SwbemDateTime														# Convert TimeSubmitted to readable format

	$OfflinePrintersBlah = @()
	$PingTimeout = 30																									# PingTimeout ( ms )
	$CIMTimeout = 30																									# CimTimeout ( s )

	$PrintJobProps = @{}																								# HashTable Object for PrintJobs properties
	$PrinterJobSummaryProps = @{}																						# HashTable Object for PrinterJobSummary properties


#============================================================================================================================
# MAIN


# Delete previous Debug Log file, if Exists and Accessible
	If ( Test-Path $DebugLog ) { 
		Try { Remove-Item -EA Stop -Force $DebugLog
		} Catch { 
			Write-Verbose "$DebugLog  IN use, or NOT accessible"
			Exit 123
	}	}
	"$StartTime`t`t`tPrintServersTotal:`t`t$PrintServersTotal" | Out-File -Append $DebugLog



# Import PrintersOffLineCSV data
	If ( Test-Path $PrintersOffLineCSV ) { $PrintersOffLine = Import-CSV $PrintersOffLineCSV }

# Query each PrintServer in list
	ForEach ( $PrintServer in $PrintServers ) {
		$JobErroredCount = 0
		$PrinterErroredCount = 0
		$OfflinePrinters = @()
#		If ( Test-Connection $PrintServer -Count 1 -Quiet ) {
		If ( ( Get-WmiObject Win32_PingStatus -Filter "Address='$BCANameReplyIP' AND Timeout=$PingTimeout" ).ResponseTime -GE 0 ) {
		"$(Get-Date)`tStart`t$PrintServer" | Out-File -Append $DebugLog

#	Get Failed print jobs logs count
#			$JobsFailedCount = [System.IO.Directory]::GetFiles( "\\$PrintServer\C$\Epic\Jobs\Failed\$EpicVerDotP0\Epic Print Service", "*.log" ).Count
#			$JobsFailedCount = "n/a"

# Get all Stuck Printers with Jobs older than StaleMinutes on PrintServer
			Try {
				$StuckPrintJobs = Get-WMIObject -ComputerName $PrintServer "Win32_PrintJob" | Where { $_.ConvertToDateTime($_.TimeSubmitted) -LT (Get-Date).AddMinutes(-($StaleMinutes)) }
#				$PrinterJobs = Get-WMIObject -ComputerName $PrintServer "Win32_PrintJob" | Where { $_.JobStatus -Like '*Error*' -Or $_.JobStatus -Like '*Deleting*' -Or $_.JobStatus -Like '*Offline*' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -LT (Get-Date).AddMinutes(-($StaleMinutes)) }
#				$PrinterJobs = Get-WMIObject -ComputerName $PrintServer "Win32_PrintJob" | Where { $_.JobStatus -Like '*Error*' -Or $_.JobStatus -Like '*Deleting*' -Or $_.JobStatus -Like '*Offline*' -Or $_.JobStatus -Like '' } | Where { $_.ConvertToDateTime($_.TimeSubmitted) -LT (Get-Date).AddMinutes(-($StaleMinutes)) }
#				$PrinterJobs = ( Get-CimInstance -EA Stop -OperationTimeoutSec $CIMTimeout -ComputerName $PrintServer "Win32_PrintJob" -Filter 'JobStatus LIKE "%Deleting%" OR  JobStatus LIKE "%Error%"  OR  JobStatus LIKE "%Offline%"'  OR  JobStatus LIKE "''" ) | Where { $_.TimeSubmitted -LT (Get-Date).AddMinutes(-($StaleMinutes)) }
				$StuckPrintJobs | ForEach { $_.Name = $_.Name.Split(',')[0] }											# Clean up the .Name
				$StuckPrintJobs =  $StuckPrintJobs | Sort Name
				$StuckPrintJobsCount = $StuckPrintJobs.Count
				"$(Get-Date)`t`t`tStuckPrintJobsCount:`t$StuckPrintJobsCount" | Out-File -Append $DebugLog


# Get all Blocked PrintJobs for each Stuck PrintJob
#				$PrintersErrored | Sort -Property Name, [string]TimeSubmitted | ForEach {
				ForEach ( $StuckPrintJob in $StuckPrintJobs ) {
				If ( $StuckPrintJob.JobStatus -Match "Error"  -OR  $StuckPrintJob.JobStatus -Match "Deleting"  -OR  $StuckPrintJob.JobStatus -Match "Offline" ) {
					$PrinterErroredCount ++

					$PrintJobProps = [Ordered]@{
						'ServerName' = ""
						'PrinterQName' = ""
						'PrinterQNameStuckJobsCount' = ""
						'PrinterName' = ""
						'PrinterFQDN' = ""
						'PrinterIP' = ""
						'PrinterIPColor' = "White"
						'PrinterWebAdminURL' = ""
						'PrinterWebAdminName' = "Click Me"
						'PrinterOnlineStatus' = ""
						'PrinterOnlineStatusColor' = "White"
						'PingTime' = ""
						'JobID' = ""
						'JobTime' = ""
						'JobStatus' = ""
						'JobStatusColor' = "Yellow"
						'DocName' = ""
						'DocSize' = ""
						'DocPages' = ""
						'PrintDriver' = ""
					}

					$PrinterJobSummaryProps = @{
						'ServerName' = ""
						'OfflinePrintersCount' = ""
						'PrinterErroredCount' = ""
						'JobErroredCount' = ""
#						'JobsFailedCount' = ""
					}

					$PrinterQName = $StuckPrintJob.Name																	# Get Print Queue Name
					$PrinterName = $PrinterQName.Split('_')[0]															# Get Printer HostName for DNS lookup
					"$(Get-Date)`t`t`t`t$PrinterQName`t$PrinterName" | Out-File -Append $DebugLog

					$PrinterFQDN = " "
					$IP = " "
					$PrinterNameReplyIP = " "
					Try {																								# Get PrinterFQDN, IPs & PrinterNameReplyIP ( Programmatic Method )
						$PrinterFQDNIPs = [System.Net.Dns]::GetHostByName( $PrinterName )
						$PrinterFQDN = $PrinterFQDNIPs.Hostname
						$IP = $PrinterFQDNIPs.AddressList.IPAddressToString
						If ( $IP.Count -Gt 1 ) {
							$IP | ForEach {
								If (( Get-WmiObject -EA Stop Win32_PingStatus -Filter "Address='$_' AND Timeout=$PingTimeout" ).ResponseTime -Ge 0 ) { $PrinterNameReplyIP = $_ }
								$PrintJobProps.PrinterIP += $_ +" "
							}
							$PrintJobProps.PrinterIPColor = "Red"
						} Else {
							If (( Get-WmiObject -EA Stop Win32_PingStatus -Filter "Address='$IP' AND Timeout=$PingTimeout" ).ResponseTime -Ge 0 ) { $PrinterNameReplyIP = $IP }
							$PrinterNameReplyIP = $IP
							$PrintJobProps.PrinterIP = $IP
						}
					} Catch {
						$PrinterFQDN = " "
#						$PrinterFQDN = $PrinterName
						$PrintJobProps.PrinterIPColor = "Red"
						$PrintJobProps.PrinterIP = "NOT_in_DNS"
						$PrintJobProps.PrinterWebAdminName = ""
					}

					If (( Get-WmiObject Win32_PingStatus -Filter "Address='$PrinterFQDN' AND Timeout=$PingTimeout" ).ResponseTime -Ge 0 ) {				# Get Printer Online status
						$PrintJobProps.PrinterOnlineStatusColor = "green"
						$PrintJobProps.PingTime = $StartTime
						$PrintJobProps.PrinterOnlineStatus = "Online"
					} Else {
						$PrintJobProps.PrinterOnlineStatusColor = "yellow"
						If ( $PrintersOffLine.PrinterQName -Contains $PrinterQName ) {
							$PrintJobProps.PingTime = [DateTime]( $StartTime, $PrintersOffLine[ $PrintersOffLine.PrinterQName.IndexOf( $PrinterQName ) ].PingTime | Measure -Minimum ).Minimum
						} Else {
							$PrintJobProps.PingTime = $StartTime
						}
						If (( $StartTime - $PrintJobProps.PingTime ).TotalDays -Ge 1.0 ) {
							$PrintJobProps.PrinterOnlineStatus = "Offline_" + [string][math]::Round(( $StartTime - $PrintJobProps.PingTime ).TotalDays, 1 ) +"Days"
						} Else {
							$PrintJobProps.PrinterOnlineStatus = "Offline_" + [string][math]::Round(( $StartTime - $PrintJobProps.PingTime ).TotalHours, 2 ) +"Hrs"
						}
						$OfflinePrintersBlah += $PrinterName
						$OfflinePrinters += $PrinterName
					}

# Assign PrintJobProps values
					$PrintJobProps.ServerName = $PrintServer
					$PrintJobProps.PrinterQName = $PrinterQName
					$PrintJobProps.PrinterFQDN = $PrinterFQDN
					$PrintJobProps.PrinterName = $PrinterName
					$PrintJobProps.PrinterWebAdminURL = "http://$PrinterNameReplyIP"									# Set WebAdmin URL & Validate, if Online


					Try {
						$PrinterQStuckJobs = Get-CimInstance -EA Stop -OperationTimeoutSec $CIMTimeout -ComputerName $PrintServer "Win32_PrintJob" -Filter "Name LIKE '%$PrinterQName%'"
					} Catch { $ExitCode = 201 }

					$PrintJobProps.PrinterQNameStuckJobsCount = $PrinterQStuckJobs.Count

					ForEach ( $PrinterQStuckJob in $PrinterQStuckJobs ) {
#					Try {
#																														# WHY DO ANOTHER Get-CimInstance, DON'T WE HAVE PrintersErrored ??
#						Get-CimInstance -EA Stop -OperationTimeoutSec $CIMTimeout -ComputerName $PrintServer "Win32_PrintJob" -Filter "Name LIKE '%$PrinterQName%'" | ForEach {
#						Get-WmiObject -ComputerName $PrintServer "Win32_PrintJob" -Filter "Name Like '%$PrinterQName%'" | ForEach {
							$JobErroredCount ++
							$PrintJobProps.JobID  = $PrinterQStuckJob.JobID
#							$WMITime.Value = $PrinterQStuckJob.TimeSubmitted											# Step #1 - Convert TimeSubmitted to readable format
#							$PrintJobProps.JobTime = $WMITime.GetVarDate()												# Step #2 - Convert TimeSubmitted to readable format
							$PrintJobProps.JobTime = $PrinterQStuckJob.TimeSubmitted
							$PrintJobProps.JobStatus = $PrinterQStuckJob.JobStatus
#							$PrintJobProps.DocName = $PrinterQStuckJob.Document.Split("\")[6]
							$PrintJobProps.DocName = $PrinterQStuckJob.Document
							$PrintJobProps.DocSize = [string][math]::Round( $PrinterQStuckJob.Size / 1KB, 1 ) +"KB"
#							$PrintJobProps.DocPages = $PrinterQStuckJob.TotalPages
							$PrintJobProps.DocPages = [string]$PrinterQStuckJob.PagesPrinted +" of "+ [string]$PrinterQStuckJob.TotalPages
							$PrintJobProps.PrintDriver = $PrinterQStuckJob.DriverName
#							"$(Get-Date)`t`t`t`t`t$($PrintJobProps.DocPages)  $($PrintJobProps.PrintDriver)" | Out-File -Append $DebugLog


# Blank out values for Blocked Jobs		( $PrintJobProps.JobStatus -Like "" )  NOT -Eq ""
							If ( $PrintJobProps.JobStatus -Eq $Null ) {
								$PrintJobProps.PrinterQNameStuckJobsCount = ""
								$PrintJobProps.JobStatus = "^"
								$PrintJobProps.PrinterFQDN = ""
								$PrintJobProps.PrinterWebAdminURL = ""
								$PrintJobProps.PrinterWebAdminName = ""
								$PrintJobProps.PrinterIP = ""
								$PrintJobProps.PrinterOnlineStatus = ""
#								$PrintJobProps.PrintDriver = ""
							}


# Add HashTable Object to Array Structure
#							$PrintJobs += New-Object -TypeName PSObject -Property $PrintJobProps
#							"$(Get-Date)`t`t`t`t`t$($PrintJobProps.PrinterIP)  $($PrintJobProps.PrinterOnlineStatus)  $($PrintJobProps.DocPages)" | Out-File -Append $DebugLog
#						}

# Add HashTable Object to Array Structure
							$PrintJobs += New-Object -TypeName PSObject -Property $PrintJobProps
							"$(Get-Date)`t`t`t`t`t$($PrintJobProps.PrinterIP)  $($PrintJobProps.PrinterOnlineStatus)" | Out-File -Append $DebugLog
						}

				} Else { "Handle Odd Jobs - $($PrintJobProps.PrinterOnlineStatus)" }
				}
			} Catch { $ExitCode = 203 }
		}

# Assign PrinterJobSummaryProps values
		$PrinterJobSummaryProps.ServerName = $PrintServer
		$PrinterJobSummaryProps.OfflinePrintersCount = ( $OfflinePrinters | Sort -Unique ).Count
		$PrinterJobSummaryProps.PrinterErroredCount = $PrinterErroredCount
		$PrinterJobSummaryProps.JobErroredCount = $JobErroredCount
#		$PrinterJobSummaryProps.JobsFailedCount = $JobsFailedCount
		$PrinterJobSummary += New-Object -TypeName PSObject -Property $PrinterJobSummaryProps

# Grand Totals
		$PrinterErroredTotal += $PrinterErroredCount
		$JobErroredTotal += $JobErroredCount
#		$JobsFailedTotal += $JobsFailedCount
	}


	$StopTime = $(Get-Date)
	$ElapsedTotalMinutes = [int]( $StopTime - $StartTime ).TotalMinutes
	"$StartTime`t`t`tCompleted:`t`tElapsedTotalMinutes`t$ElapsedTotalMinutes" |  Out-File -Append $DebugLog

	$OfflinePrintersTotal = ( $OfflinePrintersBlah | Sort -Unique ).Count
	$NotInDNSPrinters = $PrintersOffLine | Where { $StuckPrintJob.PrinterIP -Eq "NOT_in_DNS" } | Select PrinterQName | Sort PrinterQName -Unique
	$NotInDNSPrintersTotal = $NotInDNSPrinters.Count

#	$PrinterJobSummary | Measure PrinterErroredCount -Sum
#	$PrinterJobSummary | Measure JobErroredCount -Sum
#	$PrinterJobSummary | Measure JobsFailedCount -Sum

# The HTMLHeader variable sets up the BODY Background, TABLE Background, Headers, and Foreground of the HTML Document
	$HTMLHeader  = '<style type="text/css">'
	$HTMLHeader += "BODY{color:white;background-color:black;}"																		# Body White/Black
	$HTMLHeader += "TABLE{border-width:1px;border-style:solid;border-color:white;border-collapse:collapse;}"						# Table Borders
	$HTMLHeader += "TH{border-width:1px;padding:0px;border-style:solid;border-color:white;color:black;background-color:gray}"		# Table Headers White/Gray
	$HTMLHeader += "TD{border-width:1px;padding:5px;border-style:solid;border-color:white;color:white;background-color:black}"		# Table Cells White/Black
	$HTMLHeader += "h3{color:white;font-size:100%;}"																				# Normal Cell
#	$HTMLHeader += "tr:nth-child(even) {background-color:black}"																	# NOT working
#	$HTMLHeader += "tr:nth-child(odd) {background-color:white}"																		# NOT working
	$HTMLHeader += "</style>"
	$HTMLHeader += '<meta http-equiv="refresh" content="300" />'																	# Browser Refresh interval
	$HTMLHeader += '<meta http-equiv="cache-control" content="no-cache" />'															# Browser No-cache flag
	$HTMLHeader += '<title>Epic Stuck Print Jobs</title>'																			# TAB Page Title
	$HTMLHeader += '<link rel="shortcut icon" href="' + $FavIcon + '" />'															# Browser Tab FavIcon ( IE is "Special" )
	$HTMLHeader += '<link rel="icon" href="' + $FavIcon + '" />'																	# Browser Tab FavIcon ( Normal Browsers )

# Import Master Navigation Bar HTML file
	$HTMLNavBar = Get-content "\\$HostFQDN\C$\Scripts\EpicMasterRecon\MasterNavBarHTML.html"										# This is the NavBar HTML file for import

# HTMLPre sets up the Pre-Content of the HTML page
	$HTMLPre  = $HTMLNavBar
	$HTMLPre += "<a href=`"$StuckPrintJobsURL`"><img src=data:image/png;base64,$($ImageEncoded) alt='Stuck Job' height='145' width='300'/></a>"
	$HTMLPre += "<h1>Epic Stuck Print Jobs</h1><h3> (Since 5am purge)</h3>"
	$HTMLPre += "<h1><font color='Yellow'>### Under Construction ###</font></h1><br>"
	$HTMLPre += "<h3>Start Update at:  $StartTime</h3>"

# HTMLBody sets up the Table1-Content of the HTML page ( Print Jobs )
	$HTMLBody  = $HTMLPre
	$HTMLBody += "<table><tr>"
	$HTMLBody += "<th><a href=`"$StuckPrintJobsURL`">Server Name</a></th>"
	$HTMLBody += "<th>Print Queue</th>"
	$HTMLBody += "<th>Stuck<br>Jobs</th>"
	$HTMLBody += "<th>Printer FQDN</th>"
	$HTMLBody += "<th>IP Address</th>"
	$HTMLBody += "<th>Printer WebAdmin</th>"
	$HTMLBody += "<th>Online</th>"
	$HTMLBody += "<th>Job ID</th>"
	$HTMLBody += "<th>Time Submitted</th>"
	$HTMLBody += "<th>Status</th>"
	$HTMLBody += "<th>Document Name</th>"
	$HTMLBody += "<th>Size</th>"
	$HTMLBody += "<th>Pages<br>Printed / Total</th>"
	$HTMLBody += "<th>Print Driver</th>"
	$HTMLBody += "</tr>"
	Create-HTMLTable ( $PrintJobs )
	$HTMLBody  = $HTMLBody + $Global:HTMLRows
	$HTMLBody += "</table><br /><br />"

# HTMLBody sets up the Table2-Content of the HTML page ( Print Server Totals )
	$HTMLBody += "<br /><br /><table><tr>"
	$HTMLBody += "<th>PrintServer Name</th>"
	$HTMLBody += "<th>Printers Offline</th>"
	$HTMLBody += "<th>Queues Stuck</th>"
	$HTMLBody += "<th>Jobs Stuck</th>"
#	$HTMLBody += "<th>Jobs in Failed</th>"
	$HTMLBody += "</tr>"
	Create-HTMLTableSummary ( $PrinterJobSummary )
	$HTMLBody = $HTMLBody + $Global:HTMLRowsSUM

# HTMLBody sets up the Table3-Content of the HTML page ( Grand Totals )
	$HTMLBody += "<tr>"
	$HTMLBody += "<th>Total PrintServers</th>"
	$HTMLBody += "<th>Total Printers Offline</th>"
	$HTMLBody += "<th>Total Queues Stuck</th>"
	$HTMLBody += "<th>Total Jobs Stuck</th>"
#	$HTMLBody += "<th>Total Jobs Failed</th>"
	$HTMLBody += "</tr>"
	$HTMLBody += "<tr>"
	$HTMLBody += "<td><div align='center'>$PrintServersTotal</div></td>"
	$HTMLBody += "<td><div align='center'><font color='yellow' size='3'>$OfflinePrintersTotal</font></div></td>"
	$HTMLBody += "<td><div align='center'><font color='yellow' size='3'>$PrinterErroredTotal</font></div></td>"
	$HTMLBody += "<td><div align='center'><font color='yellow' size='3'>$JobErroredTotal</font></div></td>"
#	$HTMLBody += "<td><div align='center'><font color='yellow' size='3'>$JobsFailedTotal</font></div></td>"
	$HTMLBody += "</tr>"
	$HTMLBody += "</table><br /><br />"

# HTMLPost sets up the Post-Content Summary of the HTML page
	$HTMLPost  = "<br><hr color='yellow' />"
	$HTMLPost += "<br><h3>Last Update at:  $StopTime</h3><br><br>"
	$HTMLPost += "<h3>Jobs Older than:  $StaleMinutes min<br /></h3>"
	$HTMLPost += "<h3>Data Refreshed every: $RepeatEvery minutes</h3>"
	$HTMLPost += "<h3>Elapsed Minutes:   $ElapsedTotalMinutes</h3>"
#	$HTMLPost += "<h3><br /><br />For details, contact Ed Tomlinson</h3>"
	$HTMLPost += "<br><br><h3>Created on $AuthorDate by the Baylor Scott &amp; White Epic Tech Team</h3>"

# Convert to HTML and output to the StuckPrintJobsUNC file
	ConvertTo-HTML -Head $HTMLHeader -Body $HTMLBody -Post $HTMLPost | Out-File -Force $StuckPrintJobsUNC

# Export to .CSV file
	$PrintJobs | Where { $_.PrinterOnlineStatus -Like "Offline*" } | Select PrinterQName,PrinterIP,PrinterOnlineStatus,PingTime | Sort PrinterQName -Unique | Export-CSV -Force $PrintersOffLineCSV -NoTypeInformation


# Email Report at specified time, if True
	If ( $SendMail  -And  $StartTime -Ge [datetime]$SendReportTime  -And  $StartTime -Lt ( [datetime]$SendReportTime ).AddMinutes( $RepeatEvery )) {
		$MailMessage = @{
			To = "ETomlinson@BSWHealth.org"
			From = "$ScriptName@$HostName.BSWHealth.org"
			Subject = "Epic Stuck Print Jobs -  Printers OfflineCount  $OfflinePrintersTotal   Not_in_DNS  $NotInDNSPrintersTotal"
			Body = "Epic Stuck Print Jobs Report`n$StuckPrintJobsURL`n`n`n $NotInDNSPrintersTotal Printers NOT_in_DNS`n`n $($NotInDNSPrinters) `n`nIf you wish to be removed from this distribution, please contact the Epic Technical Team"
			Attachments = $StuckPrintJobsUNC
			SmtpServer = "smtp.sw.org"
		}
		Try {
			Send-MailMessage @MailMessage -ErrorAction Stop
		} Catch {
			Write-Host "SMTP failure"
			Exit 190
	}	}

# Normal Exit
	Exit $ExitCode
