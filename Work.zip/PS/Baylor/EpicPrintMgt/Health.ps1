CLS 
$arrayComp ="Server1" 
foreach ($machine in $arrayComp) 
{  
get-WmiObject -class win32_printer -computername $machine |` 
where-object {$_.status -notmatch "Unknown" -and $_.status -notmatch "Ok"} | sort name | ft name, systemName, shareName, status, location 
}
