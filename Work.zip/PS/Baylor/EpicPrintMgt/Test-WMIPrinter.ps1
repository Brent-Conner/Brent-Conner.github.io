
#	C:\Scripts\EpicPrintMgt\Test-WMIPrinter.ps1

	CLS

	$PrintServers ="Server1"

	foreach ( $PrintServer in $PrintServers ) {
#		get-WmiObject -computername $PrintServer win32_printer | Where {$_.status -notmatch "Unknown" -and $_.status -notmatch "Ok"} | sort name | ft name, systemName, shareName, status, location
		get-wmiobject -computername $PrintServer Win32_Printer -namespace "root\CIMV2"

	}
