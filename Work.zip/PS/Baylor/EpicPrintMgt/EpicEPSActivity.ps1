﻿[CmdletBinding()]
Param(
  [alias("f")]
  [string]$runFunction = ( "getEPSFileCount" )
, [alias("e")]
  [string]$runEnvironment = "T"
)

<#
        $countObjectProps = [Ordered]@{
                        'Header' = ( "Detail" )
                      'DateTime' = ( $( Get-Date ) )
                    'sshdStatus' = ( ( Get-Service -Name "*sshd*" ).Status )
                'folderIncoming' = ( "$PSComputerName\Epic\Jobs\Incoming\8.3\Epic Print Service\" )
                 'filesIncoming' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Incoming\8.3\Epic Print Service\", "$Using:EpicFileExt" ).Count )
                 'folderPending' = ( "$PSComputerName\Epic\Jobs\Incoming\8.3\Epic Print Service\Pending" )
                  'filesPending' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Incoming\8.3\Epic Print Service\Pending", "$Using:EpicFileExt" ).Count )
                  'folderFailed' = ( "$PSComputerName\Epic\Jobs\Failed\8.3\Epic Print Service\" )
                   'filesFailed' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Failed\8.3\Epic Print Service\", "$Using:EpicFileExt" ).Count )
               'folderProcessed' = ( "$PSComputerName\Epic\Jobs\Processed\8.3\Epic Print Service\" )
                'filesProcessed' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Processed\8.3\Epic Print Service\", "$Using:EpicFileExt" ).Count )
            'filesIncomingMoved' = ( "No" )
        }
#>

$Global:EpicVersion = "8.3"
$Global:EpicFileExt = "*.e???"
$Global:folderName = ( "\\bswepicmonp101.bhcs.pvt\C$\Scripts\EpicPrintMgt" )
#$Global:reportFolder = ( "\\bswepicmonp101.bhcs.pvt\C$\Scripts\Reports\HTML\EpicEPS\data" )
$Global:serviceName = ( "sshd" )
$Global:processName = ( "splwow64.exe" )
$Global:destComputer = "bswEpicEPS$( $runEnvironment.ToUpper() )101.bhcs.pvt"

# [ Production --> P || Non-Production --> T ]
if ( $runEnvironment.ToUpper() -eq "P" ) {
    $Global:computerList = ( "EpicEPSProdServerNames.txt" )
    $Global:redCount = 25
    $Global:stopCount = 50
    $Global:csvInFile = $Global:csvOutFile = ( "$folderName\getEPSFileCount.csv" )
    $Global:csvMoveFile = ( "$folderName\moveEPSFiles.csv" )
    $Global:csvLogFile = ( "$folderName\moveEPSFilesLog.csv" )
    #$Global:csvReportFile = ( "$reportFolder\getEPSFileCount.csv" )
} else {
    $Global:computerList = ( "EpicEPSTestServerNames.txt" )
    $Global:redCount = 2
    $Global:stopCount = 5
    $Global:csvInFile = $Global:csvOutFile = ( "$folderName\getEPSFileCount-$( $runEnvironment.ToUpper() ).csv" )
    $Global:csvMoveFile = ( "$folderName\moveEPSFiles-$( $runEnvironment.ToUpper() ).csv" )
    $Global:csvLogFile = ( "$folderName\moveEPSFilesLog-$( $runEnvironment.ToUpper() ).csv" )
    #$Global:csvReportFile = ( "$reportFolder\getEPSFileCount-$( $runEnvironment.ToUpper() ).csv" )
}

"[
        Epic Version : $EpicVersion
      Epic File Ext. : $EpicFileExt
Destination Computer : $destComputer
       Computer List : $computerList
           Red Count : $redCount
          Stop Count : $stopCount
       Source Folder : $folderName
         csv In File : $csvInFile
       csv Move File : $csvMoveFile
        csv Log File : $csvLogFile
     csv Report File : $csvReportFile
   Stop Service Name : $serviceName
   Stop Process Name : $processName
]" | Write-Debug

# Begin - function(s) block

# Begin - function getEPSFileCount

function getEPSFileCount {

    [CmdletBinding()]
    Param(
    #  [string]$folderName = ( "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt" )
    #, [string]$csvOutFile = ( "$folderName\getEPSFileCount.csv" )
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "[ In - getEPSFileCount ]" )
    } # Begin

    Process {

        $Computers = ( Get-Content ( "$folderName\$computerList" ) | ?{ $_.Trim() -ne '' } )
        Write-Debug ( "[ Computers : `n$( $Computers ) ]" )

        $serverSessions += New-PSSession -ComputerName $Computers

        $countObjectArray = @()
        $countObjectArray += Invoke-Command -Session $serverSessions -ScriptBlock {

            $countObjectProps = [Ordered]@{
                            'Header' = ( "Detail" )
                          'DateTime' = ( $( Get-Date ) )
                        'sshdStatus' = ( ( Get-Service -Name "*sshd*" ).Status )
                    'folderIncoming' = ( "$PSComputerName\Epic\Jobs\Incoming\$Using:EpicVersion\Epic Print Service\" )
                     'filesIncoming' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Incoming\$Using:EpicVersion\Epic Print Service\", $Using:EpicFileExt ).Count )
                     'folderPending' = ( "$PSComputerName\Epic\Jobs\Incoming\$Using:EpicVersion\Epic Print Service\Pending" )
                      'filesPending' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Incoming\$Using:EpicVersion\Epic Print Service\Pending", $Using:EpicFileExt ).Count )
                      'folderFailed' = ( "$PSComputerName\Epic\Jobs\Failed\$Using:EpicVersion\Epic Print Service\" )
                       'filesFailed' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Failed\$Using:EpicVersion\Epic Print Service\", $Using:EpicFileExt ).Count )
                   'folderProcessed' = ( "$PSComputerName\Epic\Jobs\Processed\$Using:EpicVersion\Epic Print Service\" )
                    'filesProcessed' = ( [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Processed\$Using:EpicVersion\Epic Print Service\", $Using:EpicFileExt ).Count )
                'filesIncomingMoved' = ( "No" )

            }

            if ( $countObjectProps.sshdStatus -eq "Stopped" ) {
                $countObjectProps.filesIncomingMoved = ( "Yes" )
            }

            Return ( $countObject = New-Object PSObject -Property $countObjectProps )

        } # Invoke-Command -Session $serverSessions

        Write-Debug ( "[ countObjectArray : `n$($countObjectArray) ]" )
        $countObjectArray | sort PSComputerName | Export-CSV $csvOutFile -NoTypeInformation
        #$countObjectArray | sort PSComputerName | Export-CSV $csvReportFile -NoTypeInformation
        
        Get-PSSession | Remove-PSSession

    } # Process

    End {
        Write-Debug ( "[ Out - getEPSFileCount ]" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function getEPSFileCount

Set-Alias -Name EPSgfc -Value getEPSFileCount -Description "Get EPS File Count(s) form Incoming, Pending, Failed, Processed folder(s)."

# End - function getEPSFileCount

# Begin - function showEPSFileCount

function showEPSFileCount {

    [CmdletBinding()]
    Param(
    #  [string]$folderName = ( "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt" )
    #, [string]csvInFile = ( "$folderName\getEPSFileCount.csv" )
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "[ In - showEPSFileCount ]" )
    } # Begin

    Process {

        if ( Test-Path $csvInFile -PathType Leaf ) {

            Write-Host "Computer".PadLeft(14), "sshd".PadLeft(7), "In".PadLeft(5), "Pe".PadLeft(5), "Fa".PadLeft(5), "Pr".PadLeft(7) -BackgroundColor DarkMagenta

            ( Import-Csv ( "$csvInFile" ) ) | %{

                Write-Host -NoNewline $_.PSComputerName.split(".")[0]
                if ( $_.sshdStatus -match "Running" ) { $showIn = "Green" } else { $showIn = "Red" }
                Write-Host -NoNewline $_.sshdStatus.padleft(8) -ForegroundColor $showIn
                if ( [long]$($_.filesIncoming) -lt [long]$redCount ) { $showIn = "Green" } else { $showIn = "Red" }
                Write-Host -NoNewline $_.filesIncoming.padleft(6) -ForegroundColor $showIn
                if ( [long]$($_.filesPending) -lt [long]$redCount ) { $showIn = "Green" } else { $showIn = "Red" }
                Write-Host -NoNewline $_.filesPending.padleft(6) -ForegroundColor $showIn
                if ( [long]$($_.filesFailed) -lt [long]$redCount ) { $showIn = "Green" } else { $showIn = "Red" }
                Write-Host -NoNewline $_.filesFailed.padleft(6) -ForegroundColor $showIn
                Write-Host            $_.filesProcessed.padleft(8)

            } # ( Import-Csv ( "$csvInFile" ) )

        } else { # if ( Test-Path $csvInFile -PathType Leaf )
            Write-Debug ( "[ File $( $csvInFile ) does not exist. ]" )
        }

    } # Process

    End {
        Write-Debug ( "[ Out - showEPSFileCount ]" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function showEPSFileCount

Set-Alias -Name EPSsfc -Value showEPSFileCount -Description "Show EPS File Count(s) form Incoming, Pending, Failed, Processed folder(s)."

# End - function showEPSFileCount

# Begin - function stopEPSService

function stopEPSService {

    [CmdletBinding()]
    Param(
    #  [string]$folderName = ( "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt" )
    #, [string]$csvInFile = ( "$folderName\getEPSFileCount.csv" )
    #, [string]$csvMoveFile = ( "$folderName\moveEPSFiles.csv" )
    #, [string]$serviceName = ( "*sshd*" )
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "[ In - stopEPSService ]" )
    } # Begin

    Process {

        if ( Test-Path $csvInFile -PathType Leaf ) {

            $csvDataFile = ( Import-Csv ( "$csvInFile" ) )
            Write-Debug ( "[ csvDataFile : `n$( $csvDataFile ) ]" )

            Foreach ( $csvDataRow in $csvDataFile ) {

                Write-Debug ( "[ PSComputerName : $( $csvDataRow.PSComputerName ) ]" )

                #if ( [string]$csvDataRow.PSComputerName -notmatch "101" ) {
                #if ( [string]$csvDataRow.PSComputerName -notmatch "101" -and [string]$csvDataRow.PSComputerName -notmatch "109" ) {
                if ( [string]$csvDataRow.PSComputerName -notmatch "01" -and [string]$csvDataRow.PSComputerName -notmatch "09" ) {

                    Write-Debug ( "[ filesIncoming : $( $csvDataRow.filesIncoming ) ][ sshdStatus : $( $csvDataRow.sshdStatus ) ]" )
    
                    if ( ( [long]$($csvDataRow.filesIncoming) -ge [long]$stopCount ) -And ( $csvDataRow.sshdStatus -eq "Running" ) ) {

                        $sourceDir = "\\$($csvDataRow.PSComputerName)" + "\C$" + "$( $csvDataRow.folderIncoming )"
                        $destinationDir = "\\$destComputer" + "\C$" + "$( $csvDataRow.folderIncoming )"
                        $newcsvMoveFileEntry = $true

                        Write-Debug ( "[ sourceDir : $( $sourceDir ) ][ destinationDir : $( $destinationDir ) ]" )
                        Write-Debug ( "[ newcsvMoveFileEntry : $( $newcsvMoveFileEntry ) ]" )

                        # Check if move file exists, if exists, if no match row then entry.
                        if ( Test-Path $csvMoveFile -PathType Leaf ) {

                            $csvMoveDataFile = ( Import-Csv ( "$csvMoveFile" ) )
                            Write-Debug ( "[ csvMoveDataFile : `n$( $csvMoveDataFile ) ]" )

                            Foreach ( $csvMoveDataRow in $csvMoveDataFile ) {

                                if ( ( $csvMoveDataRow.PSComputerName -eq $csvDataRow.PSComputerName ) -And ( $csvMoveDataRow.DateTime -eq $csvDataRow.DateTime ) ) {
                                    Write-Debug "Record matched `n`t S: [ $( $csvMoveDataRow.PSComputerName ) ] [ $( $csvMoveDataRow.DateTime ) ] `n`t D: [ $( $csvDataRow.PSComputerName ) ] [ $( $csvDataRow.DateTime ) ]"
                                    $newcsvMoveFileEntry = $false
                                    Write-Debug ( "[ newcsvMoveFileEntry : $( $newcsvMoveFileEntry ) ]" )
                                }

                            } # Foreach $csvMoveDataRow

                        } # if ( Test-Path $csvMoveFile -PathType Leaf )

                        Write-Debug ( "[ newcsvMoveFileEntry : $( $newcsvMoveFileEntry ) ]" )
                        if ( $newcsvMoveFileEntry ) {

                            try {

                                Write-Debug ( "[ ( Get-Service -Name $( $serviceName ) -ComputerName $( $csvDataRow.PSComputerName ) | ?{ $( $_.Status ) -eq ""Running"" } ) | Stop-Service #-WhatIf ]" )
                                ( Get-Service -Name $serviceName -ComputerName $csvDataRow.PSComputerName | ?{ $_.Status -eq "Running" } ) | Stop-Service #-WhatIf

                                $csvDataRow.sshdStatus = ( Get-Service -Name $serviceName -ComputerName $csvDataRow.PSComputerName ).Status
                                $csvDataRow.filesIncomingMoved = "Yes"

                                Write-Debug ( "[ sshdStatus : $( $csvDataRow.sshdStatus ) ]" )
                                Write-Debug ( "[ csvDataRow : `n$( $csvDataRow ) ]" )

                                $csvDataRow | Export-CSV $csvMoveFile -NoTypeInformation -Append
                                $csvDataRow | Export-CSV $csvLogFile -NoTypeInformation -Append

                                $mailMessage = @"

                                Source : $( $MyInvocation.MyCommand.Name )

                                    $( $csvDataRow.PSComputerName ) has $( $csvDataRow.filesIncoming ) file(s) in '$( $sourceDir )' folder.
                                    'CYGWIN sshd' Service has been stopped.
                                    An attempt will be made to move file(s) to '$( $destinationDir )' folder.
                                    Please investigate ...
"@
                            } catch {
                                $errorMessage = $_

                                Write-Debug ( "[ errorMessage : $( $errorMessage ) ]" )

                                $mailMessage = @"

                                Source : $( $MyInvocation.MyCommand.Name )

                                    $( $csvDataRow.PSComputerName ) has $( $csvDataRow.filesIncoming ) file(s) in '$( $sourceDir )' folder.
                                    An attempt has been made to stop 'CYGWIN sshd' Service but exception has been raised.
                                    An attempt will 'NOT' be made to move file(s) to '$( $destinationDir )' folder.
                                    Please investigate ...

                                    Command:
                                        $errorMessage.Exception.InvocationInfo.Line

                                    Exception:
                                        $errorMessage.Exception.Message
"@
                            } finally {
                                Write-Debug ( "[ sendEPSeMail $( $csvDataRow.PSComputerName ) $( $mailMessage ) ]" )
                                sendEPSeMail $( $csvDataRow.PSComputerName ) $mailMessage
                            }

                        } # if ( $newcsvMoveFileEntry )

                    } # if ( ( [long]$($csvDataRow.filesIncoming) -ge [long]$stopCount ) -And ( $csvDataRow.sshdStatus -eq "Running" ) )

                } # if ( $csvDataRow.PSComputerName -notmatch "101" )

            } # Foreach ( $csvDataRow in $csvDataFile )

        } else { # if ( Test-Path $csvInFile -PathType Leaf )
            Write-Debug ( "[ File $( $csvInFile ) does not exist. ]" )
        }

    } # Process

    End {
        Write-Debug ( "[ Out - stopEPSService ]" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function stopEPSService

Set-Alias -Name EPSses -Value stopEPSService -Description "Stop EPS 'CYGWIN sshd' Service."

# End - function stopEPSService

# Begin - function sendEPSeMail

function sendEPSeMail {

    [cmdletbinding()]
    Param (
      [string]$computerName = "localhost"
    , [string]$mailMessage = "Test Message: about 'CYGWIN sshd' Service on server [ $computerName ]"
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "[ In - sendEPSeMail ]" )
    } # Begin

    Process {

        Write-Debug ( "[ computerName : $( $computerName ) ][ mailMessage : $( $mailMessage ) ]" )
        #"To" = "IS CLINICAL TECHSUPPORT <ISCLINICALTECHSUPPORT@BSWHealth.org>"

        $mailParams = @{
            "From" = "EPS Activity Script <EpicEPSActivity@bswepicmonp01.swntdomain.sw.org>"
            "To" = "IS CLINICAL TECHSUPPORT <ISCLINICALTECHSUPPORT@BSWHealth.org>"
    
            "Subject" = "about 'CYGWIN sshd' Service on server $computerName"
            "Body" = "$mailMessage"

			"SmtpServer" = "mailrelaybswhealth.org"
        }

        Write-Debug ( "[ Send-MailMessage $( $mailParams ) ]" )
        Send-MailMessage @mailParams

    } # Process

    End {
        Write-Debug ( "[ Out - sendEPSeMail ]" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function sendEPSeMail

Set-Alias -Name EPSsem -Value sendEPSeMail -Description "Send EPS email when 'CYGWIN sshd' Service is stopped."

# End - function sendEPSeMail

# Begin - moveEPSFiles

function moveEPSFiles {

    [CmdletBinding()]
    Param(
    #  [string]$folderName = ( "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt" )
    #, [string]$csvInFile = ( "$folderName\getEPSFileCount.csv" )
    #, [string]$csvMoveFile = ( "$folderName\moveEPSFiles.csv" )
    #, [string]$csvLogFile = ( "$folderName\moveEPSFilesLog.csv" )
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "[ In - moveEPSFiles ]" )
    } # Begin

    Process {

        if ( Test-Path $csvMoveFile -PathType Leaf ) {

            $csvMovedData = @()
            $updateData = $false
            $preMoveCount = $postMoveCount = $filesWereMoved = 0

            Write-Debug ( "[ updateData : $( $updateData ) ][ preMoveCount : $( $preMoveCount ) ][ postMoveCount : $( $postMoveCount ) ]" )

            $csvDataFile = ( Import-Csv ( "$csvMoveFile" ) )
            Write-Debug ( "[ csvDataFile : `n$( $csvDataFile ) ]" )

            Foreach ( $csvDataRow in $csvDataFile ) {

                Write-Debug ( "[ filesIncomingMoved : $( $csvDataRow.filesIncomingMoved ) ]" )

                if ( $csvDataRow.filesIncomingMoved -match "Yes" ) {

                    $sourceDir = "\\$($csvDataRow.PSComputerName)" + "\C$" + "$( $csvDataRow.folderIncoming )"
                    $destinationDir = "\\$destComputer" + "\C$" + "$( $csvDataRow.folderIncoming )"

                    Write-Debug ( "[ sourceDir : $( $sourceDir ) ][ destinationDir : $( $destinationDir ) ]" )
                    
                    # Attempt One - to move files from source to destination folder(s).
                    try{
                        $preMoveCount = ( Get-ChildItem -File $sourceDir -Filter $EpicFileExt | Measure-Object ).Count

                        Write-Debug "Get-ChildItem -File $sourceDir -Filter $EpicFileExt | Move-Item -Destination $destinationDir -Force"
                        Get-ChildItem -File $sourceDir -Filter $EpicFileExt | Move-Item -Destination $destinationDir -Force #-WhatIf

                        $postMoveCount = ( Get-ChildItem -File $sourceDir -Filter $EpicFileExt | Measure-Object ).Count

                        $filesWereMoved = ( [long]$( $preMoveCount ) - [long]$( $postMoveCount ) )

                        $csvDataRow.filesIncomingMoved = "StartService"
                        $updateData = $true

                        Write-Debug ( "[ updateData : $( $updateData ) ][ preMoveCount : $( $preMoveCount ) ][ postMoveCount : $( $postMoveCount ) ][ filesWereMoved : $( $filesWereMoved ) ]" )
                        Write-Debug ( "[ csvDataRow : `n$( $csvDataRow ) ]" )
                        $csvMovedData += $csvDataRow # echo to read the row back into $csvMovedData

                        $mailMessage = @"

                        Source : $( $MyInvocation.MyCommand.Name )

                            $( $csvDataRow.PSComputerName ) has $( $csvDataRow.filesIncoming ) file(s) in '$( $sourceDir )' folder.
                            An attempt has been made to move file(s) to '$( $destinationDir )' folder.
                            [ $( $filesWereMoved ) ] out of [ $( $preMoveCount ) ] file(s) have been moved.

"@
                    } catch {
                        Write-Debug ( "Issues moving file(s) from source to destination folder(s)." )

                        $errorMessage = $_
                        Write-Debug ( "[ errorMessage : $( $errorMessage ) ]" )

                        $mailMessage = @"

                        Source : $( $MyInvocation.MyCommand.Name )

                            $( $csvDataRow.PSComputerName ) has $( $csvDataRow.filesIncoming ) file(s) in '$( $sourceDir )' folder.
                            An attempt has been made to move file(s) to '$( $destinationDir )' folder.
                            Please investigate ...

                            Command:
                                $errorMessage.Exception.InvocationInfo.Line

                            Exception:
                                $errorMessage.Exception.Message
"@
                    } finally {
                        Write-Debug ( "[ sendEPSeMail $( $csvDataRow.PSComputerName ) $( $mailMessage ) ]" )
                        sendEPSeMail $( $csvDataRow.PSComputerName ) $mailMessage
                    }

                } # if ( $csvDataRow.filesIncomingMoved -match "No" )

            } # Foreach $csvMovedData

            Write-Debug ( "[ updateData : $( $updateData ) ][ preMoveCount : $( $preMoveCount ) ][ postMoveCount : $( $postMoveCount ) ][ filesWereMoved : $( $filesWereMoved ) ]" )

            if ( $updateData ) {
            
                $csvMovedData | Export-CSV $csvLogFile -NoTypeInformation -Append
                Write-Debug ( "[ csvMovedData : `n$( $csvMovedData ) ]" )

                # Update $csvMovedData with $csvMoveFile instead of overwriting the file since additional data could have written to $csvMoveFile during move-item/start service activity.
                syncEPSFiles $csvMovedData $csvMoveFile
                
            } # if ( $updateData )

        } else { # if ( Test-Path $csvInFile -PathType Leaf )
            Write-Debug ( "File $( $csvMoveFile ) does not exist." )
        }

    } # Process

    End {
        Write-Debug ( "Out - moveEPSFiles" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function moveEPSFiles

Set-Alias -Name EPSmef -Value moveEPSFiles -Description "Get EPS File Count(s) form Incoming, Pending, Failed, Processed folder(s)."

# End - moveEPSFiles

# Begin - syncEPSFiles

function syncEPSFiles {

    [CmdletBinding()]
    Param(
      [PSObject]$csvInSync
    , [string]$csvOutSync
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "In - syncEPSFiles" )
    } # Begin

    Process {

        # Update $csvInFile with $csvMovedData instead of overwriting the file since additional data could have written to $csvInFile during move-item activity.
        $csvDataSync = @()
        $csvOutSyncFile = ( Import-Csv ( "$csvOutSync" ) )
        Write-Debug ( "[ csvOutSyncFile : `n$( $csvOutSyncFile ) ]" )

        # $csvMoveFile
        Foreach ( $csvOutSyncRow in $csvOutSyncFile ) {

            # $csvMovedData
            Foreach ( $csvInSyncRow in $csvInSync ) {

                Write-Debug "[ S : $( $csvOutSyncRow.PSComputerName ) ] [ $( $csvOutSyncRow.DateTime ) ][ D : $( $csvInSyncRow.PSComputerName ) ] [ $( $csvInSyncRow.DateTime ) ]"

                if ( ( $csvOutSyncRow.PSComputerName -eq $csvInSyncRow.PSComputerName ) -And ( $csvOutSyncRow.DateTime -eq $csvInSyncRow.DateTime ) ) {
                    Write-Debug "Record matched `n`t S: [ $( $csvOutSyncRow.PSComputerName ) ] [ $( $csvOutSyncRow.DateTime ) ] `n`t D: [ $( $csvInSyncRow.PSComputerName ) ] [ $( $csvInSyncRow.DateTime ) ]"
                    $csvOutSyncRow = $csvInSyncRow
                }

            } # Foreach ( $csvInSyncRow in $csvInSync )

            $csvDataSync += $csvOutSyncRow

        } # Foreach ( $csvOutSyncRow in $csvOutSyncFile )

        $csvDataSync | Export-CSV $csvOutSync -NoTypeInformation
        Write-Debug ( "[ csvDataSync : `n$( $csvDataSync ) ]" )

    } # Process

    End {
        Write-Debug ( "Out - syncEPSFiles" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function syncEPSFiles

Set-Alias -Name EPSsef -Value syncEPSFiles -Description "Get EPS File Count(s) form Incoming, Pending, Failed, Processed folder(s)."

# End - syncEPSFiles

# Begin - startEPSService

function startEPSService {

    [CmdletBinding()]
    Param()

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "In - startEPSService" )
    } # Begin

    Process {

        if ( Test-Path $csvMoveFile -PathType Leaf ) {

            $csvMovedData = @()
            $updateData = $false

            $csvDataFile = ( Import-Csv ( "$csvMoveFile" ) )
            Write-Debug ( "[ csvDataFile : `n$( $csvDataFile ) ]" )

            Foreach ( $csvDataRow in $csvDataFile ) {

                Write-Debug ( "filesIncomingMoved : $($csvDataRow.filesIncomingMoved)" )

                if ( $csvDataRow.filesIncomingMoved -match "StartService" ) {

                    # Attempt One - to stop splwow64 process and start sshd service.
                    try{
                        Write-Debug ( "$splwow64ProcIds = ( Get-WmiObject -ComputerName $( $csvDataRow.PSComputerName ) -Class Win32_Process -Filter ""name='$( $processName )'"" )" )
                        $splwow64ProcIds = ( Get-WmiObject -ComputerName $( $csvDataRow.PSComputerName ) -Class Win32_Process -Filter "name='$( $processName )'" )
                        Write-Debug ( "splwow64ProcIds : $( $splwow64ProcIds )" )

                        if ( $splwow64ProcIds ) {
                            Write-Debug ( "Terminating splwow64ProcIds : $( $splwow64ProcIds )" )
                            $splwow64ProcIds | %{ $_.terminate() }
                        }
                        # --- End Change

                        Write-Debug ( "( Get-Service -Name $serviceName -ComputerName $csvDataRow.PSComputerName ) | ?{ $_.Status -eq ""Stopped"" } | Start-Service" )
                        ( Get-Service -Name $serviceName -ComputerName $csvDataRow.PSComputerName ) | ?{ $_.Status -eq "Stopped" } | Start-Service #-WhatIf

                        $csvDataRow.filesIncomingMoved = "Complete"

                        $updateData = $true
                        $csvMovedData += $csvDataRow # echo to read the row back into $csvMovedData
                        Write-Debug ( "[ csvDataRow : `n$( $csvDataRow ) ]" )

                        $mailMessage = @"

                        Source : $( $MyInvocation.MyCommand.Name )

                            $( $processName ) has been terminated and $( $serviceName ) has been re-started on $( $csvDataRow.PSComputerName ).
                            Please validate process(es)/service(s) ...
"@
                    } catch {
                        Write-Debug ( "Issues stopping splwow64.exe process and/or starting sshd service." )

                        $errorMessage = $_
                        Write-Debug ( "[ errorMessage : $( $errorMessage ) ]" )

                        $mailMessage = @"

                        Source : $( $MyInvocation.MyCommand.Name )

                            An attempt has been made to terminate $( $processName ) process and starting $( $serviceName ) service on $( $csvDataRow.PSComputerName ).
                            Please investigate ...

                            Command:
                                $errorMessage.Exception.InvocationInfo.Line

                            Exception:
                                $errorMessage.Exception.Message
"@
                    } finally {
                        Write-Debug ( "[ sendEPSeMail $( $csvDataRow.PSComputerName ) $( $mailMessage ) ]" )
                        sendEPSeMail $( $csvDataRow.PSComputerName ) $mailMessage
                    }

                } # if ( $csvDataRow.filesIncomingMoved -match "No" )

            } # Foreach $csvMovedData

            if ( $updateData ) {
                
                $csvMovedData | Export-CSV $csvLogFile -NoTypeInformation -Append 
                Write-Debug ( "[ csvMovedData : `n$( $csvMovedData ) ]" )           
                # Update $csvMovedData with $csvMoveFile instead of overwriting the file since additional data could have written to $csvMoveFile during stop-service/move-itemstart-service activity.
                syncEPSFiles $csvMovedData $csvMoveFile
                
            } # if ( $updateData )

        } else { # if ( Test-Path $csvInFile -PathType Leaf )
            Write-Debug ( "[ File $( $csvMoveFile ) does not exist. ]" )
        }
    } # Process

    End {
        Write-Debug ( "Out - startEPSService" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function startEPSService

Set-Alias -Name EPSres -Value startEPSService -Description "Get EPS File Count(s) form Incoming, Pending, Failed, Processed folder(s)."

# End - startEPSService

#

function checkEPSFileEntry {

    [CmdletBinding()]
    Param(
      [PSObject]$csvInSync
    , [string]$csvOutSync
    )

    Begin {
        Write-Debug ( "[ $( Get-Date ) ]" )
        Write-Debug ( "In - checkEPSFileEntry" )
    } # Begin

    Process {

        $newFileEntry = $true
        Write-Debug ( "[ newFileEntry : $( $newFileEntry ) ]" )

        # Check if move csvOutSync file exists, if exists.
        if ( Test-Path $csvOutSync -PathType Leaf ) {

            $csvOutSyncFile = ( Import-Csv ( "$csvOutSync" ) )
            Write-Debug ( "[ csvOutSyncFile : `n$( $csvOutSyncFile ) ]" )

            Foreach ( $csvOutSyncRow in $csvOutSyncFile ) {

                if ( ( $csvOutSyncRow.PSComputerName -eq $csvInSync.PSComputerName ) -And ( $csvOutSyncRow.DateTime -eq $csvInSync.DateTime ) ) {
                    Write-Debug "Record matched `n`t S: [ $( $csvOutSyncRow.PSComputerName ) ] [ $( $csvOutSyncRow.DateTime ) ] `n`t D: [ $( $csvInSync.PSComputerName ) ] [ $( $csvInSync.DateTime ) ]"
                    $newFileEntry = $flase
                    Write-Debug ( "[ newFileEntry : $( $newFileEntry ) ]" )
                }

            } # Foreach $csvMoveDataRow

        } # if ( Test-Path $csvMoveFile -PathType Leaf )

        Write-Debug ( "[ newFileEntry : $( $newFileEntry ) ]" )
        $newFileEntry
    } # Process

    End {
        Write-Debug ( "Out - checkEPSFileEntry" )
        Write-Debug ( "[ $( Get-Date ) ]" )
    } # End

} # function checkEPSFileEntry

Set-Alias -Name EPScfe -Value checkEPSFileEntry -Description "Check EPS File Entry."

# End - startEPSService


#


# End - function(s) block

# Begin - Main Block

Write-Debug ( "[ $( Get-Date ) ]" )
Write-Debug ( "[ In - Main Block ]" )

While ( $true ) {

    if ( -not ( $DebugPreference -eq 'Continue' ) ) {
        cls
    }

    "[
         runFunction : $runFunction
               runEnvironment : $runEnvironment
    ]" | Write-Debug

    switch ( $runFunction ) {
         "getEPSFileCount" { getEPSFileCount; Write-Debug ( Get-Date ); break }
        "showEPSFileCount" { showEPSFileCount; Get-Date; sleep 1; break }
          "stopEPSService" { stopEPSService; Write-Debug ( Get-Date ); sleep 1; break }
            "sendEPSeMail" { sendEPSeMail; sleep 1; Write-Debug ( Get-Date ); break }
            "moveEPSFiles" { moveEPSFiles; sleep 1; Write-Debug ( Get-Date ); break }
         "startEPSService" { startEPSService; sleep 1; Write-Debug ( Get-Date ); break }
                   default { Write-Debug "Function $( $runFunction ) not available yet."; sleep 1; Write-Debug ( Get-Date ); break }
    }

    #exit # Testing Purpose Only

}

Write-Debug ( "[ Out - Main Block ]" )
Write-Debug ( "[ $( Get-Date ) ]" )

# End - Main Block
