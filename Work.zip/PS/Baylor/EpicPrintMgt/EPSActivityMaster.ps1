# Start the following functions in background.

$parent = "\\bswepicmonp01\C$\Scripts\EpicPrintMgt\EpicEPSActivity.ps1"
$children = ( "getEPSFileCount", "showEPSFileCount", "stopEPSService", "moveEPSFiles", "startEPSService" )

$children | %{
    Write-Host "Parent : $parent`tChild : $_"
    Write-Host "PowerShell.exe -ExecutionPolicy Bypass -Command ""& '$( $parent )' -f '$_' -e 'P'"" "
}
