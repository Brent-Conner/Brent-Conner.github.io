#============================================================================================================================
#	InProcessingJobs.ps1
#============================================================================================================================


#============================================================================================================================
#	NOTES

#	Run as Scheduled Task every 5 minutes
#		PowerShell.exe  -ExecutionPolicy Bypass -Noninteractive -NoProfile -Command ". C:\EpicPrintMgt\Scripts\InProcessingJobs.ps1; Exit $LASTEXITCODE"


#	Assumptions
#		Only files that are
#			from IncommingJobs.ps1
#				.csv
#				vetted
#				Aged 2 Minutes


#	Check for Job Files
#		For each unique JobFilePrefix
#			Invoke/Start-Job JobFile Script


#============================================================================================================================
#	INITIALIZE

	CLS

#	$VerbosePreference = "SilentlyContinue"							# Disable Write-Verbose Output to Console
	$VerbosePreference = "Continue"									# Enable  Write-Verbose Output to Console

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

	$InProcessingPath = "\\$PrintMaster\C$\EpicEPSMgt\InProcessing"
	$EPSMgtInProcessingLog = "\\$PrintMaster\C$\EpicEPSMgt\Logs\EPSInProcessing.log"

	$CreatePrinterAndPortJob = "\\$PrintMaster\C$\EpicEPSMgt\Scripts\CreatePrinterAndPort.ps1"


#============================================================================================================================
#	MAIN


# Check InProcessing .csv Jobs
	$JobFileList = Get-ChildItem $InProcessingPath -Filter "*.csv"
	If ( !( $JobFileList )) {
		Write-Verbose "No Job Files to process"
		Exit 101
	}


# Get Unique Job Names
	$JobFileNames = $JobFileList | Select-Object -ExpandProperty Name
	$JobFilePrefixes = ForEach ( $JobFileName in $JobFileNames ) { ($JobFileName -Split '_')[0] }
	$UniqueJobFilePrefixes = $JobFilePrefixes | Sort-Object -Unique
Write-Verbose "Unique Jobs Found:  $UniqueJobFilePrefixes"


#	Invoke-Expression $CreatePrinterAndPortJob
# OR
	Start-Job -Filepath $CreatePrinterAndPortJob

EXIT



# Invoke Job Script
	ForEach ( $UniqueJobFilePrefix in $UniqueJobFilePrefixes ) {
		Switch ($UniqueJobFilePrefix) {
		"CreatePrinterAndPort"    { Start-Job -Filepath $CreatePrinterAndPortJob }
		Default { EXIT 131 }
		}
	}


# Normal Exit
	Exit 0



#============================================================================================================================
# TRASH
EXIT


# | Sort-Object $_.Name.Split("_").[0] -Unique

# (Get-ChildItem $InProcessingPath -Filter "*.csv" | Where-Object { $_.Name.Split('_')[0] } | Sort-Object ) -Split '_'
# (Get-ChildItem $InProcessingPath -Filter "*.csv" | Where-Object { $_.Name } | Sort-Object ) -Split '_'
# (((Get-ChildItem $InProcessingPath -Filter "*.csv") | Select-Object -ExpandProperty Name) | Sort-Object) -split '_'
# [string](Get-ChildItem $InProcessingPath -Filter "*.csv" | Sort-Object $_.Name) -split '_'
# [string](Get-ChildItem $InProcessingPath -Filter "*.csv" | Sort-Object $_.Name) -split '_'[0]
