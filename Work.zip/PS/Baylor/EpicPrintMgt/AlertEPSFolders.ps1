$CurrentEPSFoldersCSVUNC = "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt\CurrentEPSFolders.csv"
$ArchiveEPSFoldersCSVUNC = "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt\ArchiveEPSFolders.csv"


While ( $True ) {

	$EPSCurrentObject = Import-CSV $CurrentEPSFoldersCSVUNC
	$EPSARchiveObject = Import-CSV $ArchiveEPSFoldersCSVUNC

	ForEach ( $EPServer In $EPSObject ) {

	}

}
