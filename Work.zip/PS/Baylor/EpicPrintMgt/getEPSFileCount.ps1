﻿# function block
function getEPSFileCount {

    [CmdletBinding()]
    Param(
      $folderName = ( "\\bswEpicMONP01.swntdomain.sw.org\C$\Scripts\EpicPrintMgt" )
    , $Computers = ( Get-Content ( "$folderName\CheckEPSServerNames.txt" ) )
    , $DataFile = ( "$folderName\EPSfilesCount.xml" )
    )

    Begin {

        Write-Debug ( Get-Date )

    } # Begin

    Process {

        $serverSessions += New-PSSession -ComputerName $Computers
        Write-Debug ( "$serverSessions" )

        $countArray = @()
        $countArray += Invoke-Command -Session $serverSessions -ScriptBlock {

        $filesObject = [PSCustomObject]@{
            'Header' = "Detail"
            'sshdStatus' = ( Get-Service -Name "*sshd*" ).Status
            'Incoming' = [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Incoming\8.3\Epic Print Service\", "*.e???" ).Count
            'Pending' = [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Incoming\8.3\Epic Print Service\Pending", "*.e???" ).Count
            'Failed' = [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Failed\8.3\Epic Print Service\", "*.e???" ).Count
            'Processed' = [System.IO.Directory]::GetFiles( "$PSComputerName\Epic\Jobs\Processed\8.3\Epic Print Service\", "*.e???" ).Count
            }

        Return $filesObject

        } # Invoke-Command -Session $serverSessions

        Write-Debug ( "$countArray" )
        #$countArray | sort PSComputerName | Export-Clixml $DataFile # Export-CSV $DataFile -NoTypeInformation
        cls;Write-Host "$( Get-Date )"
        $countArray | Sort PSComputerName | Select PSComputerName, sshdStatus, Incoming, Pending, Failed, Processed | Format-Table
        
        
        Get-PSSession | Remove-PSSession

    } # Process

    End {
        Write-Debug ( Get-Date )
    } # End

} # function getEPSFileCount

# main block
cls
While ( $true ) {
    getEPSFileCount
}

