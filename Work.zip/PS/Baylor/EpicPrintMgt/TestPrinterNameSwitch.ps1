

		Do {
					$PrinterName = Read-Host -Prompt "`n    PrinterName`t"


					Switch -WildCard ( $PrinterName) {
					   "*P-0*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".printer.sw.org" }
					   "*P-1*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".printer.sw.org" }
					   "*P-2*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".printer.sw.org" }
					   "*P-3*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".bhcs.pvt" }
					   "*P-4*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".bhcs.pvt" }
					   "*P-5*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".bhcs.pvt" }
					   "BHPRT*" { $PrinterFQDN = $PrinterName.Split('_')[0] +".bhcs.pvt" }
					   "PRT*"   { $PrinterFQDN = $PrinterName.Split('_')[0] +".bhcs.pvt" }
					   "ZPRT*"  { $PrinterFQDN = $PrinterName.Split('_')[0] +".bhcs.pvt" }
					   Default  { $PrinterFQDN = $PrinterName.Split('_')[0] }										# "Hmmm... New Printer Prefix ???"
					}

$PrinterFQDN

		} Until ( $PrinterName -Eq "" )

