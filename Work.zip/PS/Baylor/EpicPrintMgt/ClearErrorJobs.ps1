#============================================================================================================================
#	ClearErrorJobs.ps1
#============================================================================================================================


# ??? Copy PrinterErrorDB to ClearPrinterJobs
# ??? Move file from InProcessing to Processed and log
# ??? Capture & Log details of the stuck job
# Get-PrintJob & Remove-PrintJob are ONLY availabe on Windows Server 2012 R2 with PowerShell 3.0


#============================================================================================================================
# INITIALIZE

	CLS

	$ServerName = [system.environment]::MachineName
	$PrintMaster = $ServerName

# This is temporary static naming
	$PrinterErrorDB = "\\$PrintMaster\C$\EpicPrintMgt\Reports\PrinterErrorDB.csv"
	$ClearPrinterJobs = "\\$PrintMaster\C$\EpicPrintMgt\InProcessing\ClearPrinterErrorsJob.csv"

	$ClearPrinterJobsReport = "\\$PrintMaster\C$\EpicPrintMgt\Reports\ClearPrinterErrorsReport.csv"

#============================================================================================================================


# Check ClearPrinterJobs Exists
	If ( ! ( Test-Path $ClearPrinterJobs ) ) { 
		Write-Host "$ClearPrinterJobs  NOT found"
		Exit 111
	}

# Delete previous ClearPrinterJobsReport, if Exists and Accessible
	If ( Test-Path $ClearPrinterJobsReport ) { 
		Try { Remove-Item $ClearPrinterJobsReport -ErrorAction Stop
		} Catch { 
			Write-Host "$ClearPrinterJobsReport  IN use, or NOT accessible"
			Exit 113
		}
	}


	Write-Host "Clearing Printer Error Jobs . . ."

	$ClearPrinterJobsHash = Import-CSV $ClearPrinterJobs



	Add-Content $ClearPrinterJobsReport ( '"SystemName","Name","PortName","Status","Result"' )
	ForEach ( $Printer in $ClearPrinterJobsHash ) {
#		If ( $Printer.Name -Like "P-*"  -And  $Printer.PortName -NotLike "LAN*" ) {
		If ( $Printer.Name -Like "P-*" ) {
			Write-Host "	Identifying Jobs on  " $Printer.SystemName "  " $Printer.Name "  " $Printer.PortName
# IDENTIFY STUCK AND BACKEDUP JOBS
			Get-PrintJob -ComputerName $Printer.SystemName -PrinterName $Printer.Name | where JobStatus -like "Error" 
			Get-PrintJob -ComputerName $Printer.SystemName -PrinterName $Printer.Name | where JobStatus -Notlike "Error" 

EXIT

			Write-Host "	Clearing Jobs on  " $Printer.SystemName "  " $Printer.Name "  " $Printer.PortName
# CLEAR ALL JOBS
#			Try {
#				Get-PrintJob -ComputerName $Printer.SystemName -PrinterName $Printer.Name | where JobStatus -like "*" | Remove-PrintJob
#				$Result = "All Cleared"
#				$Printer | Select *, @{Name="Result";Expression={ $Result }} | Export-CSV $ClearPrinterJobsReport -Append -NoTypeInformation
#			} Catch {
#				$Result = "NOT Cleared"
#				$Printer | Select *, @{Name="Result";Expression={ $Result }} | Export-CSV $ClearPrinterJobsReport -Append -NoTypeInformation
#			}
		}
	}


	Write-Host "ErrorJob Cleared, Report is  $ClearPrinterJobsReport"


# Normal Exit
	Exit 1000



#============================================================================================================================
# TRASH
EXIT

		$PServerPrinters = Get-WmiObject -Class "Win32_Printer" -Namespace "root\CIMV2" -Computername $PrintServer | Where-object { $_.Name -Like "P-*" } | Sort-Object Name
		$PServerPrinters | Select-Object SystemName, Name, PortName, DriverName | Export-CSV $PrinterDriverDBTmp -Append -NoTypeInformation
		$PServerPrinters | Where-object { $_.Status -Like "Error*" } | Select-Object SystemName, Name, PortName, Status | Export-CSV $PrinterErrorDBTmp -Append -NoTypeInformation
	}

$PrintServer = "PPPrint01"
$objWMIService = GetObject("winmgmts:\\" & $PrintServer & "\root\cimv2")

Set colInstalledPrinters = objWMIService.ExecQuery _
    ("Select * from Win32_Printer Where Name = 'ArtDepartmentPrinter'")

For Each objPrinter in colInstalledPrinters
    objPrinter.CancelAllJobs()
Next

