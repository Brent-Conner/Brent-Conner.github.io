#============================================================================================================================
#	QueryPrintServiceEvents.ps1
#============================================================================================================================

#	Prompt for DaysBackToSearch
#	Prompt for SearchString
#	ForEach EPS server
#		Query the Windows PrintService ( Admin & Operational ) Event Logs for SearchString
#	Output to Screen

# ??? Query AD for PrintServers -Like "EpicPrint*"

#============================================================================================================================
# INITIALIZE

	CLS
	CMD /C COLOR 1F
	CMD /C MODE CON: COLS=180 LINES=48

	$PrintServers = "EpicPrint01", "EpicPrint02", "EpicPrint03", "EpicPrint04", "EpicPrint05", "EpicPrint06"

	$DefaultDaysBackToSearch = 1

#============================================================================================================================


	$DaysBackToSearch = Read-Host -Prompt "`nSearch Windows PrintService ( Admin & Operational ) event logs back how many days? [ $DefaultDaysBackToSearch ]"
	If  ( $DaysBackToSearch -Eq "" ) { $DaysBackToSearch = $DefaultDaysBackToSearch }
	$DateBack = ($(Get-Date)).AddDays(-$DaysBackToSearch)


	Write-Host "`nEnter the P-Name, DocumentName, Document #, or Job # ( or portion thereof below ):  "
	$SearchString = Read-Host
	$SearchString = "*"+ $SearchString +"*"
	Write-Host


	ForEach ( $PrintServer in $PrintServers ) {
		Write-Host "Searching  $PrintServer,  $DaysBackToSearch Day(s),  for `"$SearchString`""
		$PrinterAdminEvents = Get-WinEvent  -ComputerName $PrintServer -FilterHashTable @{LogName='Microsoft-Windows-PrintService/Admin'; StartTime=$DateBack} -ErrorAction SilentlyContinue | Where { $_.Message -Like $SearchString }
		$PrinterAdminEvents | Format-Table -Autosize -Wrap
		$PrinterOperaEvents = Get-WinEvent  -ComputerName $PrintServer -FilterHashTable @{LogName='Microsoft-Windows-PrintService/Operational'; StartTime=$DateBack} -ErrorAction SilentlyContinue | Where { $_.Message -Like $SearchString }
		$PrinterOperaEvents | Format-Table -Autosize -Wrap
	}


# Pause
	Write-Host "`nPress any key to continue . . ." -NoNewline
	$Host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown,IncludeKeyUp") | Out-Null


# Normal Exit
	Exit 1000
