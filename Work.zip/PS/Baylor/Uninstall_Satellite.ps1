$computerNames = Get-Content C:\Scripts\RemoteInstall\ServerList.txt
$appName = "Epic Satellite"
$service = "EpicSatellite"
#$yourAccount = Get-Credential

 

ForEach ($computer in $computerNames) {
    Write-Host "`n`nRunning on " $computer
    Stop-Service -InputObject $(Get-Service -Computer $computer -Name $service)
    
    Invoke-Command -ComputerName $computer -ScriptBlock {
        cd "C:\Program Files (x86)\Epic\Satellite\91.1.0.0"
        .\Satellite.exe /X
        }
 }