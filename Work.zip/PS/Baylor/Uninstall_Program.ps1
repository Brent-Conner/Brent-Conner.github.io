﻿$computerNames = Get-Content C:\Machines\BCA.txt
$appName = "LibreOffice 6.3.5.2"
$yourAccount = Get-Credential
ForEach ($computerName in $computerNames) {
    Invoke-Command -ComputerName $computerName -Credential $yourAccount -ScriptBlock {
        Get-WmiObject Win32_product | Where {$_.name -eq $appName} | ForEach {
            $_.Uninstall()
        }
    }
}