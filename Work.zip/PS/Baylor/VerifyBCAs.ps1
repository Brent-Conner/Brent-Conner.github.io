$computers = Get-Content \\bhcs.pvt\dfsdept\EpicTech\Scripts\BCA\BCAList.txt
import-module activedirectory
$SourceFolder = "\\bhcs.pvt\DFSDept\EpicBCADowntimeContent\Master"
$DestinationFolder = "c$\EpicBCADowntimeContent\Master_BCADowntime_Forms"

foreach ($computer in $computers)
 {
  Write-Host "`n`nRunning on " $computer

  If (( Get-WmiObject Win32_PingStatus -Filter "Address='$computer' AND Timeout=20" ).ResponseTime -Ge 0 ) 
  { 
        CLS
        write-host -ForegroundColor Yellow "`n`nChecking Operating System of "$computer
        write-host "`nIf workstation is not running Windows 10, send ticket to FS to reimage or replace the device since it will not function correctly"
        $OS = Get-WmiObject -EA Stop -ComputerName $computer -Class Win32_OperatingSystem | Select Name, Caption, OSArchitecture
    	$OSName = $OS.Caption
        $OSBits = $OS.OSArchitecture
        Write-Host "`nThis workstation is running " $OSName " " $OSBits
        Write-Host "`n`n-------------------------------------------------------------------------------------------------"
        	
        write-host -ForegroundColor Yellow "`n`nChecking membership of Local Administrators group on " $computer
        write-host "`n`nCheck for Epic Admins and EpicAdminService`n"
        write-host "`n`nIf either are missing, uncomment out the lines below to add and run script again`n"
        write-host "`n`nNote: Community Connect sites may not report Local Administrators accurately since they use VPN so ok to ignore this for those`n"
		Invoke-Command -ComputerName $computer -ScriptBlock { net localgroup Administrators }
       
       	write-host "`n`nAdding bhcs\Epic Admins to Administrators group ..."
		#Invoke-Command -ComputerName $computer { Add-LocalGroupMember -Group "Administrators" -Member "bhcs\Epic Admins"}
        #Invoke-Command -ComputerName $computer { Get-LocalGroupMember -Group "Administrators" | Select Name }

		#write-host "`n`nAdding bhcs\EpicAdminService to Administrators group ..."
		#Invoke-Command -ComputerName $computer { Add-LocalGroupMember -Group "Administrators" -Member "bhcs\EpicAdminService"}
        #Invoke-Command -ComputerName $computer { Get-LocalGroupMember -Group "Administrators" | Select Name }
		
        Write-Host "`n`n-------------------------------------------------------------------------------------------------"

		write-host -ForegroundColor Yellow "`n`nChecking AD membership of autologin user and workstation of " $computer
        write-host -ForegroundColor Yellow "`n`nUser AD groups"
        write-host "Check for MSC_AUTOLOGON_BCA_USERS and/or EPIC_BCA_Autologin_Users"
        write-host "If workstation is autologin and user is not in one of the groups above, you can send ticket to FS to add to collection and re-run the install"
        write-host "But it won't necessarily affect useablity of Epic BCA if the groups are missing`n"
        #(New-Object System.DirectoryServices.DirectorySearcher("(&(objectCategory=User)(samAccountName=$($computer)))")).FindOne().GetDirectoryEntry().memberOf
        ([adsisearcher]"(&(objectCategory=user)(samAccountName=$computer))").FindOne().Properties.memberof -replace '^CN=([^,]+).+$','$1'

        write-host -ForegroundColor Yellow "`n`nWorkstation AG groups"        
        write-host "Check for EPIC_BCA_PC"
        write-host "If workstation is not in EPIC_BCA_PC, send ticket to FS to add to collection and re-run the install`n"
        #(New-Object System.DirectoryServices.DirectorySearcher("(&(objectCategory=computer)(samAccountName=$($computer)))")).FindOne().GetDirectoryEntry().memberOf
        ([adsisearcher]"(&(objectCategory=computer)(cn=$computer))").FindOne().Properties.memberof -replace '^CN=([^,]+).+$','$1'
            
        
        Write-Host "`n`n-------------------------------------------------------------------------------------------------"

  		write-host -ForegroundColor Yellow "`n`nChecking if Epic BCA services are running on  " $computer   
        write-host "`n`nIf no Epic BCA services are running or if they are wrong version, send ticket to Field Services to add device to Epic BCA PC collection."
        #Invoke-Command -ComputerName $computer { Get-Service -Name Epic* }
        Get-Service -ComputerName $computer | Where{$_.Name -like "Epic*"}
		
		write-host -ForegroundColor Yellow "`n`nAttempting to register $computer"
		Invoke-Command -cn $computer -scriptblock {& "C:\Epic\Bin\9.5\Epic Print Service\RegisterClient.exe" -K �eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJ1cm46U1dDYXJlRXZlcnl3aGVyZTpDRS1QUkQiLCJleHAiOjE2NTc2NDI3NTksImlhdCI6MTYyNjEwNjc1OSwiaXNzIjoiYTBhZjI3ODEtMjdjZS00NTQ1LWI5YWUtYzM1YzBhMzI5MTAyIiwianRpIjoiN2Q3NjNmZjktMzBhNS00MzRlLWJjODYtZmQyNDM4Y2QxOGMwIiwibmJmIjoxNjI2MTA2NzU5LCJzdWIiOiJhMGFmMjc4MS0yN2NlLTQ1NDUtYjlhZS1jMzVjMGEzMjkxMDIifQ.SrVgtSRc08xbtSLO9YmEIYnTe1Z0c_BH5ecuX3x1AgZMzBQHiqXrfMQM6dfuU1WNTBNXp_0t_1eU2a6Hgd7Xf-8R0cWDlEcgUgg4D0EfZVhnzJafA1wwyJTh--6oBIsGKmBwwEpWuKlj6J5WFtzK6R9DxirHFUrSI_4NagPI6uu_QwN4esa5gFutysP3z8ZcYImLWR32iqKWQDpgOyQ2WSfpDyHoUSHYIAzURfBhU-LMZQbLBuVcTaFjTAP3wvYystLABnntE0die1xlFba0mHI5r6Kn7YS0Zi5mT6hGo74y6KfrOFVrNwkyGuyuo3mbHgOFJwe-BEf3zVQ6OePNAg� }
                
        write-host -ForegroundColor Yellow "`n`nCopying BCA LAST Synched file to local computer on " $computer
        Remove-Item \\$computer\$DestinationFolder\LAST*.txt
        Copy-Item �Path $SourceFolder\LAST*.txt �Destination \\$computer\$DestinationFolder
        
        Write-Host "`n`nIf everything looks correct, close the incident`n"

        pause
		
  }
  ELSE
  {
  Write-Host $computer "timed out. Send ticket to Field Services to bring device online."
  }  
}
Write-Host "`n`nCompleted`n`n"


