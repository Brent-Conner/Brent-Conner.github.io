﻿
$ScriptLoc = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\DR\"

Function Brakes { foreach($var in $args) { If(!$var) { Write-Host -foreground red "A variable was NULL, returning to menu."; Pause; Menu } } }

Function GroupSelect {

$slist = Get-ChildItem -path $ScriptLoc"_Servers" -Recurse
$Num = 1
Write-Host -foreground Yellow "***********************"
Write-Host -foreground Yellow ">>>>Server List<<<<"
foreach($list in $slist) { Write-Host $Num - $list; $Num++ }
Write-Host -foreground Yellow "***********************"
$Choice = Read-Host "Choose server list"
$list = $slist[$Choice-1]
$Servers = Get-Content -path $ScriptLoc"_Servers\"$list
Return $Servers
}


Function FlushDNS {
#Flush DNS for all Internal servers
$DRservers = GroupSelect
foreach($server in $DRservers) {
Write-Host "Flushing DNS on $server"
Invoke-Command -ComputerName $server -ScriptBlock { Clear-DnsClientCache -AsJob } } }

Function RestartIIS {
#Restart IIS for all Internal servers
$DRservers = GroupSelect

foreach($server in $DRservers) {
Write-Host "Restarting w3svc on $server"
Get-Service -ComputerName $server -Name "w3svc" | Restart-Service -Force } }


Function Menu {

while(1) {
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "Epic DR Functions"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  Flush DNS for internal servers"
	Write-host "2.  Restart IIS for internal servers"
	Write-host "3.  Load Interconnect Tools"
    Write-Host "4.  Load EPS Tools"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "5.  "
    Write-host "6.  "
    Write-host "7.  "
    Write-host "8.  Exit Menu"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
	$MenuOption = Read-host "Selection"
	
	Switch($MenuOption) {
        "1"  {FlushDNS}
		"2"  {RestartIIS}
        "3"  {\\bhcs.pvt\dfsdept\EpicTech\Scripts\Interconnect\ICTools.ps1}
		"4"  {\\bhcs.pvt\dfsdept\EpicTech\Scripts\EPS\EPSTools.ps1}
        "5"  {}
        "6"  {}
        "7"  {}
        "8"  {Exit}
        "9"  {}
        "10" {}
        "11" {}
        "12" {}
        "13" {}
        "14" {}
        "15" {}
        default {Continue}
        }
    }
}
Menu