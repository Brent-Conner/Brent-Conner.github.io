﻿$pc = Read-Host "PC"
Invoke-Command -Computername $pc { Get-ItemProperty -Path 'HKLM:\SYSTEM\ControlSet001\Enum\FTDIBUS\VID_0403+PID_6001+A702SD8PA\0000\Device Parameters' | Select PortName }