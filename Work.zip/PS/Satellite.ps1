﻿#$pcs = Get-Content C:\input\bca.txt1
#foreach($pc in $pcs) {
$pc = read-host "PC"
$s = New-Pssession $pc
Invoke-Command -ComputerName $pc { New-Item -Path C:\BCAPC\ -Type Directory -Force }
#TST Copy-Item -Path "\\pacfile2\groups\epic\Technical Team\BCA\Satellite\BCAPCTST.bat" -Destination C:\BCAPC\ -Force -recurse -ToSession $s
Copy-Item -Path "\\pacfile2\groups\epic\Technical Team\BCA\Satellite\BCAPCPRD.bat" -Destination C:\BCAPC\ -Force -recurse -ToSession $s
Copy-Item -Path \\netappb\EpicRA\Independent\Kuiper\SatelliteSetup.exe -Destination C:\BCAPC\ -Force -recurse -ToSession $s
#TST Invoke-Command -ComputerName $pc -ScriptBlock { C:\BCAPC\BCAPCTST.bat }
Invoke-Command -ComputerName $pc -ScriptBlock { C:\BCAPC\BCAPCPRD.bat }
#}