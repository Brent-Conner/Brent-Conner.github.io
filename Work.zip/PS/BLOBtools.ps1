﻿Clear-Host
# Global Variables
##################
$BackupBase = "C:\ConfigBackup\"
$PathsWithFiles = ("C:\FromDir1\","C:\FromDir1\1sub\","C:\FromDir2\")
$SaveFiles = ("*.xml","*.config")
$Date = Get-Date -Format d | % {$_.replace("/","_")}
$BackupTo = $BackupBase + $Date + "\"
##################

# Menu Functions
function BackupConfig
{
    foreach($Path in $PathsWithFiles)
    {
        $CreateDir = $BackupTo + $Path.substring(3)
        If (Test-Path $Path) { New-Item $CreateDir -Type Directory -Force | Out-Null }
        
        foreach($File in $SaveFiles)
        {
            $From = $Path + $File
            $To = $BackupTo + $Path.substring(3)
            Write-Host -foreground Green "Copying $From"
            Write-Host "To $To"
            Copy-Item $From -Destination $To -Force -Recurse -ErrorAction SilentlyContinue
        }
    }
}

function RestoreConfig
{
    $i = 0
    $Folders = Get-ChildItem $BackupBase -Dir
    foreach ($Folder in $Folders) { Write-Host "$i  - $Folder" ; $i++ }
    $MenuOpt = Read-Host "Choose folder to restore files from"
    $RestoreFromBase = $BackupBase + $Folders[$MenuOpt] + "\"
    foreach ($File in $SaveFiles)
    {
        foreach ($Path in $PathsWithFiles)
        {
            $From = $RestoreFromBase + $Path.substring(3) + $File
            Write-Host -foreground Green "Attempting to copy $From"
            Copy-Item $From -Destination $Path -Force -Recurse -ErrorAction SilentlyContinue
        }
    }
}

function Find
# Menu
##################
while(1)
{
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "Menu Title"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  Backup files to $BackupTo"
    Write-host "2.  Restore files from $BackupBase"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    $MenuOption = Read-host "Selection"
    
    Switch($MenuOption)
    {
        "1"  {BackupConfig}
        "2"  {RestoreConfig}
        default {Continue}
    }
}
##################
