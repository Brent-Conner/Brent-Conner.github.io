$binloc = "c:\scripts\bin\"
$ScriptLoc = "\\bhcs.pvt\dfsdept\EpicTech\Scripts\EPS\temp\"



Function GroupSelect {



$slist = Get-ChildItem -path $ScriptLoc"_Servers" -Recurse
$Num = 1
Write-Host -foreground Yellow "***********************"
Write-Host -foreground Yellow ">>>>Server List<<<<"
foreach($list in $slist) { Write-Host $Num - $list; $Num++ }
Write-Host -foreground Yellow "***********************"
$Choice = Read-Host "Choose server list"
$list = $slist[$Choice-1]
$Servers = Get-Content -path $ScriptLoc"_Servers\"$list
Return $Servers
}




function ApplyBin {



$EPSservers = GroupSelect



$printers = Get-Content \\bhcs.pvt\dfsdept\EpicTech\Scripts\EPS\temp\Printers2.txt #Get-Printer -ComputerName $EPSservers[0] | Where { $_.DriverName -match "ZDesigner" }



foreach($printer in $printers) {



$printid = $printer
Start-Sleep 1
$binfile=$binloc+$printid+'.bin'



foreach($server in $EPSservers) {

if($server -match "BSWEPICEPSP110") {
$createbin='rundll32 PrintUI.dll,PrintUIEntry /Ss /n \\$server\$printid /a $binfile'
Write-Host -foreground Green "Creating bin file: $binfile"
Invoke-Expression $createbin
Start-Sleep -s 2



}



Else {
$traycommand='rundll32 PrintUI.dll,PrintUIEntry /Sr /n "\\$server\$printid" /a "$binfile" d g u r p'
Write-Host "Applying $binfile to $server\$printid"
Invoke-Expression $traycommand
Start-Sleep -s 2
} }
Remove-Item $binfile
}
}