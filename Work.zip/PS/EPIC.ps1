﻿# CreatePrinter From File
$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")
$names = Get-Content -Path C:\Input\names.txt
$drivers = Get-Content -Path C:\Input\drivers.txt
$ips = Get-Content -Path C:\Input\ips.txt

$count = 0
foreach($name in $names)
{
$ip = $ips[$count]
$driver = $drivers[$count]

    foreach($server in $EPSservers)
    {
        Write-Host -foreground Green "Creating: $ip >>>> $server"
        Add-PrinterPort -computername $server -name $ip -printerhostaddress $ip -ea silentlycontinue

	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$ip
        $print.Shared=$false
        $print.DeviceID=$name
        $print.Rawonly=$true
	    $print.EnableBIDI=$false  
	    Write-Host -foreground Green "Creating: $name >> $server >> $driver"
	    $print.Put()|Out-Null
    }
    $count++
}