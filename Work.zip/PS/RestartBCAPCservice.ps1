$get = Get-ChildItem -Force \\blobcifs\epicblob$\BCA\Outgoing
$names = $get | Select Name
$singles = $names | Select-String Name
$output = $singles -replace ".*=" -replace "}.*"
$i = "0"
foreach ($one in $output)
{
$i=0
while($i -lt "3")
{
$i++
# Write-Host "Restarting pull service on $one"
Write-Host "Restart attempt $i on $one"
Get-Service -ComputerName $one -Name EpicPullService81 | Restart-Service -Force
}
}