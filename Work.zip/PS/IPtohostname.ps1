﻿$ips = get-content c:\input\ips.txt
foreach($ip in $ips) {
$name = "null"
$name = [System.Net.Dns]::GetHostEntry("$ip")
$out = $ip + "," + $name.hostname
$out | Out-file C:\output\nat.txt -Append
}