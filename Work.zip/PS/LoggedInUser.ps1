﻿$pc = Read-Host "PC"
$user = Get-WmiObject -Class win32_computersystem -ComputerName $pc
$user
$user.username