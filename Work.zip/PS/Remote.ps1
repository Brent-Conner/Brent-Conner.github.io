﻿# Production Servers
$BCA = ("ZWPDCEPICBCA11","ZWPDCEPICBCA12")
$BCW = ("ZWPDCEPICBCW11","ZWPDCEPICBCW12")
$BLOB = ("ZWPDCEPICBLB11","ZWPDCEPICBLB12")
$EPS = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")
$IFC = ("ZWPDCEPICIFC11","ZWPDCEPICIFC12","ZWPDCEPICIFC13","ZWPDCEPICIFC14")
$MyChart = ("ZWPDCEPICWEB11","ZWPDCEPICWEB12")
$LINK = ("ZWPDCEPICWEB13","ZWPDCEPICWEB14")
$HSW = ("ZWPDCEPICHSW12","ZWPDCEPICHSW13","ZWPDCEPICHSW14","ZWPDCEPICHSW15","ZWPDCEPICHSW16","ZWPDCEPICHSW17","ZWPDCEPICHSW18","ZWPDCEPICHSW19","ZWPDCEPICHSW20","ZWPDCEPICHSW21","ZWPDCEPICHSW22","ZWPDCEPICHSW23","ZWPDCEPICHSW24","ZWPDCEPICHSW25","ZWPDCEPICHSW26","ZWPDCEPICHSW27","ZWPDCEPICHSW28","ZWPDCEPICHSW29","ZWPDCEPICHSW30","ZWPDCEPICHSW31","ZWPDCEPICHSW32","ZWPDCEPICHSW33","ZWPDCEPICHSW34","ZWPDCEPICHSW35","ZWPDCEPICHSW36","ZWPDCEPICHSW37","ZWPDCEPICHSW38","ZWPDCEPICHSW39","ZWPDCEPICHSW40","ZWPDCEPICHSW41","ZWPDCEPICHSW42","ZWPDCEPICHSW43","ZWPDCEPICHSW44","ZWPDCEPICHSW45","ZWPDCEPICHSW46","ZWPDCEPICHSW47","ZWPDCEPICHSW48","ZWPDCEPICHSW49","ZWPDCEPICHSW50","ZWPDCEPICHSW51","ZWPDCEPICHSW52","ZWPDCEPICHSW53","ZWPDCEPICHSW54")
$CEW = ("ZWPDCEPICCEW11","ZWPDCEPICCEW12")
$SFD = ("ZWPDCEPICSFD11","ZWPDCEPICSFD12")
$PRX = ("ZWPDCEPICPRX11","ZWPDCEPICPRX12")
$FAX = ("ZWPDCEPICFAX11","ZWPDCEPICFAX12","ZWPDCEPICSQL15")
$PULSE = ("ZWPDCEPICPUL11","ZWPDCEPICSQL11")

$AllProd = $BCA + $BCW + $BLOB + $EPS + $IFC + $MyChart + $LINK + $HSW + $CEW + $SFD + $PRX + $FAX + $PULSE

# Test Servers
$BCAtest = ("ZWTSTEPICBCA12","ZWTSTEPICBCA13")
$BCWtest= ("ZWTSTEPICBCW11")
$BLOBtest = ("ZWTSTEPICBLB12","ZWTSTEPICBLB13")
$CEWtest = ("ZWTSTEPICCEW11","ZWTSTEPICCEW12")
$SFDtest = ("ZWTSTEPICSFD11","ZWTSTEPICSFD12")
$LINKtest = ("ZWTSTEPICWEB13","ZWTSTEPICWEB14")
$EPStest = ("ZWTSTEPICEPS11","ZWTSTEPICEPS12","ZWTSTEPICEPS13")
$HSWtest = ("ZWTSTEPICHSW11","ZWTSTEPICHSW12")
$IFCtest = ("ZWTSTEPICIFC11","ZWTSTEPICIFC12")
$MyCharttest = ("ZWTSTEPICWEB11","ZWTSTEPICWEB12")
$PRXtest = ("ZWTSTEPICPRX11","ZWTSTEPICPRX12")
$FAXtest = ("ZWTSTEPFXFAX11")

$AllTest = $BCAtest + $BCWtest + $BLOBtest + $CEWtest + $SFDtest + $LINKtest + $EPStest + $HSWtest + $IFCtest + $MyCharttest + $PRXtest + @($FAXtest)

$ALL = $AllProd + $AllTest

function EPSftp
{
    foreach($server in $EPS) { $i++; Write-Host "$i  - $server" }
    $opt = Read-Host "Selection"
    $server = $EPS[$opt-1]
    Get-Service -ComputerName $server -Name ftpsvc | Stop-Service -Force
}

function Services
{
Write-host -foreground Blue "<><><><><><><><><><><><><><>"
Write-host "1.  Start Service"
Write-host "2.  Stop Service"
Write-host "3.  Restart Service"
Write-host -foreground Blue "<><><><><><><><><><><><><><>"
	
$MenuOption = Read-host "Selection"
$server = Read-Host "Server"
$service = Read-Host "Service"
	
	Switch($MenuOption)
    {
		"1"  {Get-Service -ComputerName $server -Name $service | Start-Service}
		"2"  {Get-Service -ComputerName $server -Name $service | Stop-Service -Force}
        "3"  {Get-Service -ComputerName $server -Name $service | Restart-Service -Force}
		default {Continue}
    }
}

function AllocationSize
{
foreach($server in $ALL)
{
$out = "NULL"
$Query = "NULL"

Write-Host $server
$Query = Get-WmiObject Win32_Volume -ComputerName $server | Where-Object { $_.Label -match 'Application' } | Select-Object Name, Blocksize
$out = $server + "," + $query.name + "," + $query.blocksize
$out | Out-File C:\Output\Cluster.txt -Append
}
}

function RAM
{
foreach($server in $HSW)
{
Write-Host $server
Get-WmiObject Win32_PhysicalMemory -computername $server
}
}

function Menu
{
while(1)
{
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "From local PC options"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  Stop ftp on EPS server"
	Write-host "2.  Start, Stop, or Restart Service"
	Write-host "3.  Allocation size"
    Write-host "4.  RAM Info"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
	$MenuOption = Read-host "Selection"
	
	Switch($MenuOption)
    {
		"1"  {EPSftp}
		"2"  {Services}
        "3"  {AllocationSize}
		"4"  {RAM}
        "5"  {}
		default {Continue}
    }
}
}
Menu