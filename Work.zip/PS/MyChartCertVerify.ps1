function VerifyRemoteCertificate
{
  Param ($Domain)
  $TcpClient = New-Object -TypeName System.Net.Sockets.TcpClient
  try
  {
    $Socket = New-Object Net.Sockets.TcpClient($Domain, 443)
    $Stream = $Socket.GetStream()
    $RemoteCertValidationCallback = {param($Sender, $Certificate, $Chain, $SSLPolicyErrors) return $True }
    $SslStream = New-Object -TypeName System.Net.Security.SslStream -ArgumentList @($Stream, $True, $RemoteCertValidationCallback)
    try 
    {
      $SslStream.AuthenticateAsClient($Domain)
      $RemoteCertificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($SslStream.RemoteCertificate)
    }
    finally
    {
      $SslStream.Dispose()
      $Socket.Dispose()
    }
  }
  finally
  {
    $TcpClient.Dispose()
  }
  Return $RemoteCertificate.Verify()
}

