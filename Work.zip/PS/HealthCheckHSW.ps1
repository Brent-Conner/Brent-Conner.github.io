Function StartJobPRD {
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW11.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW12.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW13.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW14.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW15.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW16.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW17.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW18.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW19.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW20.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW21.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW22.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW23.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW24.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW25.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW26.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW27.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW28.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW29.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW30.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW31.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW32.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW33.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW34.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW35.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW36.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW37.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW38.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW39.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW40.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW41.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW42.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW43.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW44.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW45.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW46.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW47.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW48.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW49.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW50.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW51.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW52.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW53.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW54.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSD01.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSD02.phs.org/Hyperspace_PHS-PRD/health" -skipcertificatecheck -Method Get }
}

Function StartJobBATCH {
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW11.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW12.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW13.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW14.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW15.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW16.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW17.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW18.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW19.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW20.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW21.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW22.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW23.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW24.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW25.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW26.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW27.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW28.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW29.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW30.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW31.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW32.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW33.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW34.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW35.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW36.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW37.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW38.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW39.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW40.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW41.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW42.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW43.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW44.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW45.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW46.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW47.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW48.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW49.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW50.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW51.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW52.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW53.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
Start-Job -scriptblock { Invoke-WebRequest -Uri "https://ZWPDCEPICHSW54.phs.org/Hyperspace_PHS-BATCH/health" -skipcertificatecheck -Method Get }
}

Function GetJob {
$Jobs = Get-Job
$i = 11
foreach($job in $jobs) { Write-Host "HSW$i - "; $job.state; $i++ } }

Function ReceiveJob {
$jobs = Get-Job
$i = 11
foreach($job in $jobs) {
$stat = (Receive-Job -name $job.name).statuscode
Write-Host "Server $i - "
IF ($stat -ne "200") { Write-Host -ForegroundColor Red $stat }
Else { Write-Host -ForegroundColor Green $stat }
$i++ } }

Function RemoveJob {
$jobs = Get-Job
$i = 11
foreach($job in $jobs) { Remove-Job -id $job.id -force } }

# Menu
##################
while(1)
{
$pc = $null
    Write-Host -foreground Cyan "HSW Health Check - Run in Powershell 6"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1. Start local jobs for Prod"
    Write-Host "2. Get jobs status"
    Write-Host "3. Receive job status code - Don't run until 2 returns complete for all servers. 200 = good"
    Write-Host "4. Remove all local jobs (use before retrying 1)"
	Write-host "5. Start local jobs for BATCH"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    $MenuOption = Read-host "Selection"
    
    Switch($MenuOption)
    {
        "1"  {StartJobPRD}
        "2"  {GetJob}
        "3"  {ReceiveJob}
        "4"  {RemoveJob}
		"5"  {StartJobBATCH}
        default {Continue}
    }
}
##################