﻿
# Global Variables
##################
Clear-Host
$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")
$EPSservices = ("Spooler","EpicPrintService83","ftpsvc")
$EPSname = "-EPIC"
$30UPname = "-EPIC30UP"
$binlocation = "D:\Scripts\PrinterBin\"
$IncFailProc = ("D:\Epic\Jobs\Incoming\8.3\Epic Print Service\","D:\Epic\Jobs\Failed\8.3\Epic Print Service\","D:\Epic\Jobs\Processed\8.3\Epic Print Service\")
$RXnameIP = "-TROY"
$RXnameTroy = "-TROY_RX"
$RicohDriver = "PCL6 Driver for Universal Print"
$HPDriver = "HP Universal Printing PCL 6"
$SharpDriver = "SHARP DX-B450P PS"
$RXDriver = "HP Universal Printing PCL 5 (v5.2)"
$ZebraDriver1 = "ZDesigner S4M-203dpi ZPL"
$ZebraDriver2 = "ZDesigner ZT230-200dpi ZPL"
$mrodriver = "HP LaserJet 4"
$BackupBase = "D:\EPSBackups\"
$PathsWithFiles = ("D:\Epic\Bin\8.3\Epic Print Service\","D:\Epic\Bin\8.3\Epic Print Service\plugins\painters\")
$SaveFiles = ("AppConnection.config","eps.env.config","EpicPrintService.config.xml","EventManager.config.xml","SystemPulse.config.xml","Hyland.Types.dll","OnBasePrinterPlugin.config","OnBasePrinterPlugin.dll")
$Date = Get-Date -Format d | % {$_.replace("/","_")}
$BackupTo = $BackupBase + $Date + "\"
$CSV = "D:\Scripts\"
##################

# Menu Functions
##################
function CreatePrinter
{
    $ip = Read-Host "Printer Port"
    $printname = Read-Host "Printer Name (-EPIC is added automagically)"

    Write-Host -Foreground Yellow "Choose Driver"
    $Driver = DriverSelect
    Brakes $ip $printname $Driver

    foreach($server in $EPSservers)
    {
        Write-Host -foreground Green "Creating: $ip >>>> $server"
        Add-PrinterPort -computername $server -name $ip -printerhostaddress $ip -ea silentlycontinue

	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$ip
        $print.Shared=$false
        $print.DeviceID=$printname+$EPSname
        $print.Rawonly=$true
	    $print.EnableBIDI=$false  
	    Write-Host -foreground Green "Creating: $printname$EPSname >> $server >> $driver"
	    $print.Put()|Out-Null
    }
}

function CreatePrinterRX
{
    $ip = Read-Host "Printer Port"
    $printname = Read-Host "Printer Name (-TROY and -TROY_RX is added automagically)"
	$troyport = Read-Host "Troy Port Number"

    Write-Host -Foreground Yellow "Choose Driver"
    $Driver = DriverSelect
    Brakes $ip $printname $troyport $Driver

    foreach($server in $EPSservers)
    {
        Write-Host -foreground Green "Creating: $ip >>>> $server"
        Add-PrinterPort -computername $server -name $ip -printerhostaddress $ip -ea silentlycontinue
		# IP Printer
	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$ip
        $print.Shared=$false
        $print.DeviceID=$printname+$RXnameIP
        $print.Rawonly=$true
	    $print.EnableBIDI=$false  
	    Write-Host -foreground Green "Creating: $printname$RXnameIP >> $server >> $driver"
	    $print.Put()|Out-Null
		
		# Troy Printer
	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$RXdriver
        $print.PortName="TROYPORT"+$troyport+":"
        $print.Shared=$false
        $print.DeviceID=$printname+$RXnameTroy
        $print.Rawonly=$true
	    $print.EnableBIDI=$false  
	    Write-Host -foreground Green "Creating: $printname$RXnameTroy >> $server >> $RXdriver"
	    $print.Put()|Out-Null
    }
}

function CreatePrinterLabel
{
    $ip = Read-Host "Port"
    $printname = Read-Host "Printer Name (-EPIC30UP is added automagically)"
    $traynum = Read-Host "Tray Number"

    Write-Host -Foreground Yellow "Choose Driver"
    $Driver = DriverSelect
    Brakes $ip $printname $Driver

    foreach($server in $EPSservers)
    {
        Write-Host -foreground Green "Creating: $ip >>>> $server"
        Add-PrinterPort -computername $server -name $ip -printerhostaddress $ip -ea silentlycontinue

	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$ip
        $print.Shared=$false
        $print.DeviceID=$printname+$30UPname
        $print.Rawonly=$true
	    $print.EnableBIDI=$false  
	    Write-Host -foreground Green "Creating: $printname$30UPname >> $server"
	    $print.Put()|Out-Null
        $printid = $print.deviceid

        Start-Sleep 2
        $binfile=$binlocation+$driver+'-Tray'+$traynum+'.bin'
        If(Test-Path $binfile)
        {
            $traycommand='rundll32 PrintUI.dll,PrintUIEntry /Sr /n "\\$server\$printid" /a "$binfile" d g u r p'
            Write-Host "Applying $binfile to $printid"
            Invoke-Expression $traycommand
        }
        Else
        {
            printui.exe /n \\$server\$printid /p
            Write-Host -foreground Yellow "Configure tray settings, close printer, then press enter."
            Pause 
            $CreateBin='rundll32 PrintUI.dll,PrintUIEntry /Ss /n \\$server\$printid /a $binfile'
            Write-Host -foreground Green "Creating bin file: $binfile"
            Invoke-Expression $CreateBin
            Start-Sleep -s 5
        }
    }
}

function CreateMROPrinter
{
    $ip = Read-Host "Printer Port"
    $mroport = Read-Host "MRO Port"
    $printname = Read-Host "Printer Name"

    Write-Host -Foreground Yellow "Choose Driver"
    $Driver = DriverSelect
    Brakes $ip $printname $Driver $mroport

    foreach($server in $EPSservers)
    {
        Write-Host -foreground Green "Creating: $ip >>>> $server"
        $mroname = $ip + "_" + $mroport
        Add-PrinterPort -computername $server -name $mroname -printerhostaddress $ip -portnumber $mroport -ea silentlycontinue

	    $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	    $print.drivername=$driver
        $print.PortName=$mroname
        $print.Shared=$false
        $print.DeviceID=$printname+$EPSname
        $print.Rawonly=$true
	    $print.EnableBIDI=$false  
	    Write-Host -foreground Green "Creating: $printname$EPSname >> $server >> $driver"
	    $print.Put()|Out-Null
    }
}

function TroyConfigTransfer
{
    $Num = 1
    foreach($server in $EPSservers) { Write-Host $Num - $server; $Num++ }
    $Choice = Read-Host "Choose source server"
    $SrcServer = $EPSServers[$Choice-1]
    $TroyPort = Read-Host "Troy Port"
    Brakes $TroyPort

    $SrcConfig1 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPantographConfiguration.xml"
    $SrcConfig2 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPortMonitorConfiguration.xml"
    $SrcData1 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile1Page1.pcl"
    $SrcData2 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile1Pages2Plus.pcl"
    $SrcData3 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile2Page1.pcl"
    $SrcData4 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile2Pages2Plus.pcl"
    $SrcData5 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile3Page1.pcl"
    $SrcData6 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile3Pages2Plus.pcl"
    $SrcData7 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile4Page1.pcl"
    $SrcData8 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile4Pages2Plus.pcl"

    foreach($server in $EPSservers)
    {
        $To1 = "\\$server\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\"
        $To2 = "\\$server\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\"
        if($SrcServer -ne $server) 
        { 
        Write-Host "Copying files from $SrcServer to $server"
        Copy-Item -Path $SrcConfig1 -Destination $To1 -Force
        Copy-Item -Path $SrcConfig2 -Destination $To1 -Force
        Copy-Item -Path $SrcData1 -Destination $To2 -Force
        Copy-Item -Path $SrcData2 -Destination $To2 -Force
        Copy-Item -Path $SrcData3 -Destination $To2 -Force
        Copy-Item -Path $SrcData4 -Destination $To2 -Force
        Copy-Item -Path $SrcData5 -Destination $To2 -Force
        Copy-Item -Path $SrcData6 -Destination $To2 -Force
        Copy-Item -Path $SrcData7 -Destination $To2 -Force
        Copy-Item -Path $SrcData8 -Destination $To2 -Force
        #Write-Host "Restarting Troy service on $server"
        #Get-Service -ComputerName $server -Name TroyPortMonitorService.exe | Restart-Service -Force
        #$NowService = Get-Service -ComputerName $server -Name TroyPortMonitorService.exe
        #$Status = $NowService.Status
        #Write-Host $Server --- $Status
        }
    }        
}

function IPsearch
{
    $ip = Read-Host "IP"
    $server = "ZWPDCEPICEPS11"

    Brakes $ip
    $search = Get-Printer -ComputerName $server | Where-Object { $_.portname -match $ip }
    $names = $search.name
    $ports = $search.portname
    If($names -eq $null) { Write-Host -foreground red "NOT FOUND -- $server -- $ip" }
    Else
    {
        If($ports -eq $ip) { Write-Host -foreground Green "EXISTS -- $server -- $ports -- $names" }
        If($ports -is [Array])
        {
            $n = 0
            foreach($port in $ports)
            {
                $name = $names[$n]
                If($port -eq $ip) { Write-Host -foreground Green "EXISTS -- $server -- $port -- $name" }
                $n++
            }
        }
    }
}



function IPchange
{
    $OldIP = Read-Host "OldIP"
    $NewIP = Read-Host "NewIP"
    Brakes $OldIP $NewIP
    foreach ($server in $epsservers)
    {
        $Printer = Get-Printer -ComputerName $server | Where-Object { $_.PortName -eq $oldIP }
        $Name = $Printer.Name
        If($printer -eq $null) { Write-Host -foreground red "$OldIP doesn't exist on $server" }
        Else
        {     
            Write-Host "Creating $NewIP >> $server"
            Add-PrinterPort -computername $server -name $NewIP -printerhostaddress $NewIP -ea silentlycontinue
            Write-Host -foreground Green "Updating: $Name >> $NewIP >> $server"
           <# $port=([WMICLASS]"\\$server\ROOT\cimv2:Win32_TCPIPPrinterPort").createInstance() 
            $port.Name=$NewIP
            $port.SNMPEnabled=$false 
            $port.Protocol=1 
            $port.HostAddress=$NewIP 
            $port.Put() | Out-Null #>
            Set-Printer -Name $Name -ComputerName $server -PortName $NewIP | Out-Null
        }
    }
}

function DriverChangeOne
{
    $Name = Read-Host "Enter printer name"
    Brakes $Name
    Write-Host -Foreground Yellow "Choose New Driver"
    $Driver = DriverSelect
        
    foreach($Server in $EPSservers)
    {
        Write-Host -Foreground Green "Updating: $Name >> $Driver >> $Server"
	    $Change = 'rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\$Server\$Name DriverName $Driver'
	    Invoke-Expression $Change
    }
}

function StatusEPS
{ # Show status of EPS services
    Write-Host -foreground Red "-------------------------------"
    foreach($service in $EPSservices)
    {
        $status = Get-Service -ErrorAction SilentlyContinue -Name $service
        Write-Host $status.status $status.name
        Write-Host -foreground Red "-------------------------------"
    }
    Pause
}

function EnableEPS
{ # Enable EPS services
    foreach($service in $EPSservices)
    {
        Write-Host -foreground green "Setting $service to Automatic"
        Set-Service -ErrorAction SilentlyContinue -Name $service -StartupType Automatic
        Write-Host -foreground green "Starting $service"
        Start-Service -name $service
    }
}

function DisableEPS
{
    Write-Host -foreground Red "This will kill EPS processes and stop services including the Spooler on the Local Server."
    Pause
    $SpoolSVC = Get-WmiObject win32_process | Where {$_.CommandLine -match "Spool"}
    $SpoolName = $SpoolSVC.name
    Write-Host -foreground green "Ending process $SpoolName"
    Stop-Process -id $SpoolSVC.processid -force
    
    $i = 0
    While($i -ne 2)
    {
    $EpicProcesses = Get-WmiObject win32_process | Where {$_.CommandLine -match "Epic"} #| Where {$_.CommandLine -match "Print"}
    $PrintProcesses = Get-WmiObject win32_process | Where {$_.CommandLine -match "slpwow"}

    foreach($process in $EpicProcesses)
    {
        $name = $process.name
        Write-Host -foreground green "Ending process $name"
        Stop-Process -id $process.processid -force
    }
    foreach($process in $PrintProcesses)
    {
        $name = $process.name
        Write-Host -foreground green "Ending process $name"
        Stop-Process -id $process.processid -force
    }

    foreach($service in $EPSservices)
    {
        Write-Host -foreground green "Setting $service to Disabled"
        Set-Service -ErrorAction SilentlyContinue -Name $service -StartupType Disabled
        Write-Host -foreground green "Stopping service $service"
        Get-Service -ErrorAction SilentlyContinue -Name $service | Stop-Service -Force
    }
    
    #Get-ChildItem -path $Incoming -Include *.ertf -recurse | Remove-Item -Force
    #Get-ChildItem -path $Incoming -Include *.rtf -recurse | Remove-Item -Force
    #Get-ChildItem -path $Incoming -Include *.epic -recurse | Remove-Item -Force
    $i++
    Write-Host -foreground Yellow "Pass $i complete."
    }
}

function DriverChangeAll
{
$Printers = Get-Printer | Where { $_.Name -notmatch "Troy_RX" } | Where { $_.Name -notmatch "30UP" }
$Drivers = Get-PrinterDriver
$i = 0
foreach($Driver in $Drivers) {$Driver = $Driver.name;$i++; Write-Host $i "-" $Driver}
$old = Read-host "Choose old driver to replace"
$olddriver = $Drivers[$old-1].name
Write-Host $olddriver
$new = Read-host "Choose new driver"
$newdriver = $Drivers[$new-1].name
Write-Host $newdriver
$sleep = Read-Host "Enter seconds to sleep between each printer"



    foreach($Printer in $Printers)
    {
        $name = $printer.name
        if($printer.drivername -eq $olddriver)
	    {
		    foreach($server in $EPSservers)
            {
            write-host -foreground Green "Changing $server $name to driver $newdriver"
		    #$change = 'rundll32 PrintUI.dll,PrintUIEntry /Xs /n $name DriverName $newdriver'
            $change = 'rundll32 PrintUI.dll,PrintUIEntry /Xs /n \\$Server\$Name DriverName $newdriver'
            Invoke-Expression $change
		    start-sleep -s $sleep
            }
        }
    }
}

function ExportCSV
{
    Write-Host "1. Export 1 server"
    Write-Host "2. Export all EPS servers"
    $selection = Read-Host "Selection"
    switch($selection)
    {
    "1"
      {
      $server = Read-Host "Server"
      $path = $CSV + $server + '.csv'
      $Printers = Get-Printer -computername $server | Select Name,DriverName,Portname | Export-CSV -Path $path
      Write-Host "$path created."
      Invoke-Item $CSV
      }
    "2"
      {
      foreach($server in $epsservers)
        {
        $path = $CSV + $server + '.csv'
        $Printers = Get-Printer -computername $server | Select Name,DriverName,Portname | Export-CSV -Path $path
        Write-Host "$path created."
        }
        Invoke-Item $CSV
      }
    }
}

function DuplexLong
{
$printname = Read-Host "Queue name"
Brakes $printname
    
    foreach($server in $EPSservers)
    {
    Set-PrintConfiguration -ComputerName $server -PrinterName $printname -DuplexingMode TwoSidedLongEdge
    Write-Host "Applying TwoSidedLongEdge to \\$server\$printname"
    Start-Sleep 1
    }
}

function DuplexRemove
{
$printname = Read-Host "Queue name"
Brakes $printname
    
    foreach($server in $EPSservers)
    {
    Set-PrintConfiguration -ComputerName $server -PrinterName $printname -DuplexingMode OneSided
    Write-Host "Applying OneSided to \\$server\$printname"
    Start-Sleep 1
    }
}

##################
# Non-Menu Functions
##################

function DriverList
{
$i = 0
$alldrivers = Get-PrinterDriver -ComputerName $epsservers[0]
    foreach($drivername in $alldrivers)
    {
    Write-Host $i " - " $drivername.name
    $i++
    }
    $drivernum = Read-Host "Selection"
    $driver = $alldrivers[$drivernum].name
    Return $driver
}

function DriverSelect
{
    Write-Host "1. Ricoh ---------- $ricohdriver"
    Write-Host "2. HP    ---------- $hpdriver"
    Write-Host "3. Sharp ---------- $sharpdriver"
    Write-Host "4. Zebra S4M ------ $ZebraDriver1"
    Write-Host "5. Zebra T230 ----- $ZebraDriver2"
    Write-Host "6. HP LaserJet 4 -- $mrodriver"
    Write-Host "7. Other ------- Show Driver List"
    $driveroption = Read-Host "Selection"
    switch($driveroption)
    {
        "1" {$driver = $ricohdriver}
        "2" {$driver = $hpdriver}
        "3" {$driver = $sharpdriver}
        "4" {$driver = $ZebraDriver1}
        "5" {$driver = $ZebraDriver2}
        "6" {$driver = $mrodriver}
        "7" {$driver = DriverList}
        "Default" {Continue}
    }
    Write-Host $Driver
    Return $Driver
}

function Pause
{
    Read-Host 'Press enter to continue...' | Out-Null
}

function Brakes
{
    foreach($var in $args) { If(!$var) { Write-Host -foreground red "A variable was NULL, returning to menu."; Pause; Menu } }
}
##################

# Menu
##################
function Menu
{
while(1)
{
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "Epic Print Server Functions"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  Create -- Epic or Zebra Printer"
	Write-host "2.  Create -- Troy Printer"
	Write-host "3.  Create -- Label Tray Printer"
    Write-Host "4.  Create -- MRO Printer"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "5.  Transfer -- Troy config to other EPS servers"	
    Write-host "6.  IP -- Search"
    Write-host "7.  IP -- Update Printer"
    Write-host "8.  Driver -- Update Printer"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "9.  Duplex - Add long edge"
    Write-host "10. Duplex - Remove duplex"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "11. EPS Services -- Show Status (current server)"
    Write-host "12. EPS Services -- Enable all (current server)"
    Write-host "13. EPS services -- Disable all (current server)"
    Write-host -foreground Red "---------------------------------------------------"
    Write-Host "14. Change all of one print driver to another - excludes Troy_RX and 30UP"
    Write-Host "15. Export Printers to csv"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
	$MenuOption = Read-host "Selection"
	
	Switch($MenuOption)
    {
		"1"  {CreatePrinter}
		"2"  {CreatePrinterRX}
        "3"  {CreatePrinterLabel}
		"4"  {CreateMROPrinter}
        "5"  {TroyConfigTransfer}
        "6"  {IPsearch}
        "7"  {IPchange}
        "8"  {DriverChangeOne}
        "9"  {DuplexLong}
        "10" {DuplexRemove}
        "11" {StatusEPS}
        "12" {EnableEPS}
        "13" {DisableEPS}
        "14" {DriverChangeall}
        "15" {ExportCSV}
        default {Continue}
    }
}
}
Menu
##################