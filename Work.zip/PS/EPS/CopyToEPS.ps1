﻿$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")

$num = 1
while($num -lt 501)
{
$from = "D:\Data\"

    $To = "D:\Program Files\TROY Group\Port Monitor\PrintPort$num\"
    Copy-Item -Path $From -Destination $To -Force -Recurse
    Write-Host $server -- $num
    $num++
}