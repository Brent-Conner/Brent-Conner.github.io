﻿$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")
$recipients = ("5055502936@vtext.com","bconner@phs.org")
$sender = $server + "@phs.org"
$sleep = "30"
While(1)
{
foreach($server in $EPSservers)
{
$date = Get-Date
$stat = Get-Service -Name 'Troy Port Monitor Service' -ComputerName $server
	Write-Host "$date Checking Troy service on $server."
    Write-Host $stat.status
    if ($stat.status -ne "Running")
	{
		$stat | Start-Service
        $stat = Get-Service -Name 'Troy Port Monitor Service' -ComputerName $server
        Write-Host $stat.Status
	}
}
Start-Sleep -s $sleep
}