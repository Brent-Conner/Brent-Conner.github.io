﻿function TroyDelay
{
    $FileReadDelay = "3000"

    $TroyPort = 1
    while($TroyPort -lt 501)
    {

    $Dest = "D:\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPortMonitorConfiguration.xml"
    [xml]$DestDelay = Get-Content -Path $Dest
       
    $DestDelay.TroyPortMonitorConfiguration.FileReadDelay_ms = $FileReadDelay
    $DestDelay.Save("$Dest")
    Write-Host $TroyPort
    $TroyPort++
    }
}

TroyDelay