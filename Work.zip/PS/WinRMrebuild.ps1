﻿# Disable/revoke winrm/remoting
Start-Service winrm
winrm invoke restore winrm/config

Disable-PSRemoting -Force
Disable-WSManCredSSP -Role Client
Disable-WSManCredSSP -Role Server
Stop-Service winrm

# Enable remoting
Enable-PSRemoting -Force
Enable-WSManCredSSP -Role Server -Force
Enable-WSManCredSSP -Role Client -DelegateComputer "*.phs.org" -Force
winrm enumerate winrm/config/listener

Set-Item WSMan:\localhost\Client\TrustedHosts "*.phs.org" -Force