﻿##functions used by my scripts
function ShowPrintServerStatus{
    ShowText "windows printing" $config.Yellow
    Write-Host
    $i=1
    ShowText ((AddTab("server"))+(AddTab ("spooler") 1)+(AddTab ("Queues") 1)+(AddTab ("# Jobs") 1)+(AddTab ("Network Status"))) $config.Blue
	ForEach($server in $EPSServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText (AddTab($i.ToString()+$space+$server)) $config.White 1
        $servicestatus=GetServiceStatus $server "spooler"
        If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $servicestatus 1) $color 1
        $Queues = Get-WMIObject Win32_PerfFormattedData_Spooler_PrintQueue -computername $server -filter "Jobs > 0 AND Name <> '_Total'" | Select Jobs,Name
        If($Queues -eq $Null){ShowText "No Queues with Errors" $config.Red}
        Else{
            Write-Host
            ForEach($queue in $Queues){
                ShowText ((AddTab (""))+(AddTab ("") 1)+(AddTab $queue.Name 1)+(AddTab $queue.Jobs 1)) $config.Red 1
                $status=CheckOnline $queue.Name
                If($status -gt 0){ShowText (AddTab $NetworkStatus[$status] 1) $config.Red} Else{ShowText (AddTab $NetworkStatus[$status] 1) $config.Green}      
	        }
        }
        $i++
	}
}
#####################################################
function ShowPrintQueueStatus{
	$filter="Name='"+$args[0]+"'"
    ShowText ("Print Queue Status - "+$args[0]) $config.Yellow
    Write-Host
    ShowText "Network Status: " $config.Blue 1
    $status=CheckOnline $args[0]
    If($status -gt 0){ShowText $NetworkStatus[$status] $config.Red}Else{ShowText $NetworkStatus[$status] $config.Green}
    Write-Host
    ShowText ((AddTab("server"))+(AddTab ("Queue Status") 1)+(AddTab ("# Jobs") 1)) $config.Blue
	ForEach($server in $EPSServers){
        ShowText (AddTab $server) $config.White 1
        $jobstatus = Get-WMIObject Win32_PerfFormattedData_Spooler_PrintQueue -computername $server -filter $filter | Select Jobs,Name
        If($jobstatus -eq $Null){ShowText "queue doesn't exist" $config.Red}
        Else{
            $queuestatus=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").CreateInstance()
            $queuestatus.DeviceID=$args[0]
            $queuestatus.Get()
            If($PrinterStatus[$queuestatus.PrinterStatus] -eq "Other"){ShowText (AddTab $ExPrinterStatus[$queuestatus.ExtendedPrinterStatus] 1) $config.Red 1}Else{ShowText (AddTab $PrinterStatus[$queuestatus.PrinterStatus] 1) $config.Green 1}
            If([int]$jobstatus.Jobs -gt 0){ShowText $jobstatus.Jobs.ToString() $config.Red}Else{ShowText $jobstatus.Jobs.ToString() $config.Green}
        }
	}
}
#####################################################
function ShowEPSStatus{
    $oldtime=(Get-Date).AddMinutes(-5)
    ShowText "epic print service" $config.Yellow
    ShowText ((AddTab "server")+(AddTab "eps incoming" 1)) $config.Blue 1
    If($config.UseEPSM -eq 1){ShowText (AddTab "EPSM Incoming" 1) $config.Blue 1}
    ShowText ((AddTab "failed" 1)+(AddTab "ftp" 1)+(AddTab "EPS" 1)) $config.Blue 1
    If($config.UseEPSM -eq 1){ShowText ((AddTab "epsm server" 1)+(AddTab "epsm client" 1)) $config.Blue 1}
    ShowText (AddTab "spooler" 1) $config.Blue
    If($config.UseEPSM -eq 1){ShowText (AddTab " *=EPSM Master") $config.Blue 1}Else{ShowText (AddTab "") $config.Blue 1}
    ShowText (AddTab "     old" 1) $config.Blue 1
    If($config.UseEPSM -eq 1){ShowText (AddTab "    old" 1) $config.Blue 1}
    ShowText ((AddTab " total" 1)+(AddTab "service" 1)+(AddTab "service" 1)) $config.Blue 1
    If($config.UseEPSM -eq 1){ShowText ((AddTab "service" 1)+(AddTab "service" 1)) $config.Blue 1}
    ShowText (AddTab "service" 1) $config.Blue 
	$i=1
    ForEach($server in $EPSServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        $Master=Get-WmiObject -class win32_process -ComputerName $server -Filter "Name='EpicPrintServiceMonitorServerHost.exe'" | Select "ProcessID"
        $servername=$server
        If($Master -ne $Null){$servername=$servername+" (*)"}    
        ShowText (AddTab ($i.ToString()+$space+$servername) 0 1) $config.White 1
		$incomingold=CountPath ("\\"+$server+"\"+$config.EpicDrive+"$\Epic\Jobs\Incoming\"+$config.EpicVersion+"\Epic Print Service\") 0 $oldtime
        If($incomingold -gt 0){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $incomingold 1) $color 1
        If($config.UseEPSM -eq 1){
            $epsmincomingold=CountPath("\\"+$server+"\"+$config.EpicDrive+"$\Epic\Print Service Monitor\Jobs\Incoming\"+$config.EpicVersion+"\Epic Print Service\") 0 $oldtime
            If($epsmincomingold -gt 0){$color=$config.Red}Else{$color=$config.Green}
            ShowText (AddTab $epsmincomingold 1) $color 1
        }
        $failedtotal=CountPath ("\\"+$server+"\"+$config.EpicDrive+"$\Epic\Jobs\Failed\"+$config.EpicVersion+"\Epic Print Service\")
        If($failedtotal -gt 0){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $failedtotal 1) $color 1
        $servicestatus=GetServiceStatus $server "ftpsvc"
        If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $servicestatus 1) $color 1
        $servicestatus=GetServiceStatus $server ("EpicPrintService"+$config.EpicVersion.Replace(".",""))
        If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $servicestatus 1) $color 1
        If($config.UseEPSM -eq 1){
            $servicestatus=GetServiceStatus $server "EpicPrintServiceMonitorServer"
            If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
            ShowText (AddTab $servicestatus 1) $color 1
            $servicestatus=GetServiceStatus $server "EpicPrintServiceMonitorClient"
            If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
            ShowText (AddTab $servicestatus 1) $color 1
        }
        $servicestatus=GetServiceStatus $server "Spooler"
        If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $servicestatus 1) $color
    $i++
	}
    ShowText "EPS LB: " $config.Blue 1
    ShowText ($config.EPSLB+"   ") $config.White 1
    ShowText ("FTP Status: ") $config.Blue 1
    If(CheckSite ("ftp://"+$config.EPSLB)){ShowText "up" $config.Green}Else{ShowText "down" $config.Red}
}
#####################################################
function ShowRelayStatus{
    $oldtime=(Get-Date).AddMinutes(-15)
    $i=1
    ShowText "epic relay service" $config.Yellow
    ShowText ((AddTab("server"))+(AddTab("incoming") 1)+(AddTab("ftp") 1)+(AddTab("relay") 1)) $config.Blue
    ShowText ((AddTab(""))+(AddTab("  old") 1)+(AddTab("service") 1)+(AddTab("service") 1)) $config.Blue
    $RelayServers=$config.RelayServers.split(",")
	ForEach($server in $RelayServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText (AddTab ($i.ToString()+$space+$server) 0 1) $config.White 1
		$incomingold=CountPath ("\\"+$server+"\"+$config.EpicDrive+"$\Epic\Jobs\Incoming\"+$config.EpicVersion+"\Epic Relay Service\") 0 $oldtime
        If($incomingold -gt 0){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $incomingold 1) $color 1
        $servicestatus=GetServiceStatus $server "ftpsvc"
        If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $servicestatus 1) $color 1
        $servicestatus=GetServiceStatus $server ("EpicRelayService"+$config.EpicVersion.Replace(".",""))
        If($servicestatus -ne "Running"){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab $servicestatus 1) $color
        $i++
	}
    ShowText "Relay LB: " $config.Blue 1
    ShowText ($config.RelayLB+"   ") $config.White 1
    ShowText ("FTP Status: ") $config.Blue 1
    If(CheckSite ("ftp://"+$config.RelayLB)){ShowText "up" $config.Green}Else{ShowText "down" $config.Red}
    
}
#####################################################	
function ShowBCAStatus{
    ShowText "bca workstations" $config.Yellow
	$i=1
    $relayoldtime=(Get-Date).AddHours(([int]$config.OldRelay)*(-1))
    $bcaoldtime=(Get-Date).AddHours(([int]$config.OldBCA)*(-1))
	ShowText ((AddTab("Workstation"))+(AddTab("RELAY TOTAL") 1)+(AddTab("RELAY OLD") 1)) $config.Blue 1
    If($config.UseBCAWeb -eq 1){ShowText ((AddTab("Web Total") 1)+(AddTab("Web old") 1)) $config.Blue 1}
    ShowText ((AddTab("BCA TOTAL") 1)+(AddTab("BCA OLD") 1)+(AddTab("pullservice") 1)) $config.Blue
	ForEach ($pc in $PCs){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        If($config.UseBCAWeb -eq 1){$WebName=GetWebServerName $pc}Else{$WebName=$pc}
        ShowText((AddTab($i.ToString()+$space.ToString()+$WebName.ToString()) 0 1)) $config.White 1
        $pullsourcecount=CountPath ($config.RelaySource+$pc)
        If($pullsourcecount -eq 0){$color=$config.Green}Else{$color=$config.Red}
        ShowText (AddTab $pullsourcecount 1) $color 1
		$pullsourceold=CountPath ($config.RelaySource+$pc) 0 $relayoldtime
        If($pullsourceold -eq 0){$color=$config.Green}Else{$color=$config.Red}
        ShowText (AddTab $pullsourceold 1) $color 1
        $webcount=CountPath ($config.WebSource+$pc) 
        If(($webccount -eq "NO PATH")){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab($webcount) 1) $color 1
        $weboldcount=CountPath ($config.WebSource+$pc) 0 $bcaoldtime
        If(($weboldcount -eq "NO PATH") -or ($weboldcount -gt 0)){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab($weboldcount) 1) $color 1
        $pccount=CountPath ("\\"+$pc+"\c$\Epic\Jobs\Processed\"+$config.EpicVersion+"\Epic Print Service\")
        If(($pccount -eq "NO PATH") -or ($pccount -eq "OFFLINE") -or ($pccount -eq "NO DNS")){$color=$config.Red}Else{$color=$config.Green}
        ShowText (AddTab($pccount) 1) $color 1
        $pccountold=CountPath ("\\"+$pc+"\c$\Epic\Jobs\Processed\"+$config.EpicVersion+"\Epic Print Service\") 0 $bcaoldtime
        If($pccountold -eq 0){$color=$config.Green}Else{$color=$config.Red}
        ShowText (AddTab $pccountold 1) $color 1
        $servicestatus=GetServiceStatus $pc ("EpicPullService"+$config.EpicVersion.Replace(".",""))
        If($servicestatus -eq "Running"){$color=$config.Green}Else{$color=$config.Red}
        ShowText (AddTab $servicestatus 1) $color
        If(($config.RestartPullService -eq 1) -and ($args[0] -eq 1)){
            If(($pullsourcecount -gt 0) -or ($pccountold -gt 0) -or ($servicestatus -ne "Running") -and (($pccount -ne "NO PATH") -and ($pccount -ne "NO DNS") -and ($pccount -ne "OFFLINE"))){RestartBCAServices $pc}
        }
        $i++
	}
}
#####################################################
function ShowBCAWebStatus{
    $BCAWebServers=$config.BCAWebServers.Split(",")
    $Apps=$config.BCAWebApp
    ShowText "BCA WEB" $config.Yellow
    ShowText (AddTab "server") $config.Blue 1
    ForEach($app in $Apps){ShowText (AddTab $app 1) $config.Blue 1} 
    ShowText "" $config.Blue
    ShowText (AddTab " *=LoadBalancer") $config.Blue 1
    ForEach($app in $Apps){ShowText (AddTab "health check" 1) $config.Blue 1}
    ShowText "" $config.Blue
    $i=1
    ForEach($server in $BCAWebServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText((AddTab($i.ToString()+$space+$server) 0 1)) $config.White 1
        ForEach($app in $Apps){
            If(CheckSite("http://"+$server+"/"+$config.BCAWebApp+"/login.aspx")){ShowText "up" $config.Green}Else{ShowText "down" $config.Red}
        }
        $i++
    }
    If($i -gt 9){$space=". "}Else{$space=".  "}
    ShowText (AddTab ($i.ToString()+$space+$config.BCAWebLB+" (*)") 0 1) $config.White 1
    ForEach($app in $Apps){
        If(CheckSite ("http://"+$server+"/"+$config.BCAWebApp+"/login.aspx")){ShowText "up" $config.Green}Else{ShowText "down" $config.Red}
    }
}
#####################################################
function ShowWebBLOBStatus{
    $BLOBServers=$config.BLOBServers.split(",")
    $Apps="WebBlobService"
    ShowText "web blob service" $config.Yellow
    ShowText (AddTab "server") $config.Blue 1
    ForEach($app in $Apps){ShowText (AddTab $app 1) $config.Blue 1}
    ShowText "" $config.Blue
    ShowText (AddTab " *=LoadBalancer") $config.Blue 1
    ForEach($app in $Apps){ShowText (AddTab "health check" 1) $config.Blue 1}
    ShowText "" $config.Blue
    $i=1
    ForEach($server in $BlobServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText (AddTab ($i.ToString()+$space+$server) 0 1) $config.White  1
        ForEach($app in $Apps){
            If(CheckWebAppStatus ("http://"+$server+"/"+$app+"/Summary.aspx") ("<span class=""okMsg"">No parsing errors encountered.</span>")){ShowText (AddTab "success" 1) $config.Green}Else{ShowText (AddTab "failed" 1) $config.Red}
        }
        $i++
    }
    If($i -gt 9){$space=". "}Else{$space=".  "}
    ShowText (AddTab ($i.ToString()+$space+$config.BlobLB+" (*)") 0 1) $config.White 1
    ForEach($app in $Apps){
        If(CheckWebAppStatus ("http://"+$config.BlobLB+"/"+$app+"/Summary.aspx") ("<span class=""okMsg"">No parsing errors encountered.</span>")){ShowText (AddTab "success" 1) $config.Green}Else{ShowText (AddTab "failed" 1) $config.Red}
    }
}
#####################################################
function ShowHSWStatus{
    ShowText "Hyperspace Web" $yellow
    ShowText (AddTab "   *=LoadBalancer") $yellow
    $HSWServers=$config.HSWServers.Split(",")
    $HSWApps=GetWebApps $HSWServers[0]
    Write-Host
    ShowText (AddTab "apps") $blue 1
    ForEach($server in $HSWServers){ShowText (AddTab $server 2) $blue 1}
    ShowText (AddTab ($config.HSWLB+" (*)")) $blue
    ForEach($app in $HSWApps){
        ShowText (AddTab($app) 0 1) $white 1
        ForEach($server in $HSWServers){If(CheckWebAppStatus ("http://"+$server+"/"+$app+"/Health/") ("<span class=""status"">Success</span>") 11){ShowText (AddTab "up" 2) $green 1}Else{ShowText (AddTab "down" 2) $red 1}}
        If(CheckWebAppStatus ("http://"+$config.HSWLB+"/"+$app+"/Health/") ("<span class=""status"">Success</span>") 11){ShowText (AddTab "up" 2) $green}Else{ShowText (AddTab "down" 2) $red}
    }
}
#####################################################
function ShowInterconnectStatus{
    ShowText "Interconnect" $yellow
    ShowText (AddTab "   *=LoadBalancer") $yellow
    $InterconnectServers=$config.InterconnectServers.Split(",")
    $InterconnectApps=GetWebApps $InterconnectServers[0]
    ShowText (AddTab "apps") $blue 1
    ForEach($server in $InterconnectServers){ShowText (AddTab $server 2) $blue 1}
    ShowText (AddTab ($config.InterconnectLB+" (*)") 2) $blue
    ShowText (AddTab "") $white 1
    ForEach($server in $InterconnectServers){ShowText ((AddTab "Interconnect" 1)+(AddTab "Cache" 1)) $blue 1}
    ShowText ((AddTab "Interconnect" 1)+(AddTab "Cache" 1)) $blue
    ForEach($app in $InterconnectApps){
        ShowText (AddTab($app) 0 1) $white 1
        ForEach($server in $InterconnectServers){
            If(CheckWebAppStatus ("http://"+$server+"/"+$app+"/StatusPage/Main.aspx") ("<span class=""statusTitle"">Running</span>")){ShowText (AddTab "running" 1) $green 1}Else{ShowText (AddTab "down" 1) $red 1}
            If(CheckWebAppStatus ("http://"+$server+"/"+$app+"/StatusPage/Main.aspx") ("<span class=""cacheStatusUp"">UP</span>")){ShowText (AddTab "running" 1) $green 1}Else{ShowText (AddTab "down" 1) $red 1}
	    }
        If(CheckWebAppStatus ("http://"+$config.InterconnectLB+"/"+$app+"/StatusPage/Main.aspx") ("<span class=""statusTitle"">Running</span>")){ShowText (AddTab "running" 1) $green 1}Else{ShowText (AddTab "down" 1) $red 1}
        If(CheckWebAppStatus ("http://"+$config.InterconnectLB+"/"+$app+"/StatusPage/Main.aspx") ("<span class=""cacheStatusUp"">UP</span>")){ShowText (AddTab "running" 1) $green 1}Else{ShowText (AddTab "down" 1) $red 1}
        Write-Host
    }
}
#####################################################
function ShowMyChartStatus{
    $MyChartServers=$config.MyChartServers.Split(",")
    ShowText "Mychart" $config.Yellow
    ShowText (AddTab "server") $config.Blue 1 
    ShowText (AddTab "Health Check") $config.Blue
    ShowText (AddTab " *=LoadBalancer") $config.Blue
    $i=1
    ForEach($server in $MyChartServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText (AddTab($i.ToString()+$space+$server) 0 1) $config.White 1
        If(CheckWebAppStatus ("http://"+$server+"/mychart") ("""Login"">MyChart Username</label>")){ShowText "up" $config.Green}Else{ShowText "up" $config.Red}
        $i++
    }
    If($i -gt 9){$space=". "}Else{$space=".  "}
    ShowText (AddTab ($i.ToString()+$space+$config.MyChartLB+" (*)") 0 1) $config.White 1
    If(CheckSite ("http://"+$server+"/mychart")){ShowText "up" $config.Green}Else{ShowText "up" $config.Red}
}
#####################################################
function ShowECLStatus{
    $ECLServers=$config.ECLServers.Split(",")
    ShowText "epiccare link" $config.Yellow
    ShowText (AddTab "server") $config.Blue 1 
    ShowText (AddTab "Health Check") $config.Blue
    ShowText (AddTab " *=LoadBalancer") $config.Blue
    $i=1
    ForEach($server in $ECLServers){
        If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText (AddTab($i.ToString()+$space+$server) 0 1) $config.White 1
        If(CheckWebAppStatus ("http://"+$server+"/EpicWeb/common/epic_login.asp") ("Unsupported Web Browser")){ShowText "up" $config.Green}Else{ShowText "down" $config.Red}
        $i++
    }
    If($i -gt 9){$space=". "}Else{$space=".  "}
    ShowText (AddTab ($i.ToString()+$space+$config.ECLLB+" (*)") 0 1) $config.White 1
    If(CheckWebAppStatus ("http://"+$server+"/EpicWeb/common/epic_login.asp") ("Unsupported Web Browser")){ShowText "up" $config.Green}Else{ShowText "down" $config.Red}
}
#####################################################
function CheckWebAppStatus{
	$URL=$args[0]
	$str=$args[1]
    $successnum=$args[2]
    If(CheckSite $URL){
        $webClient=new-object System.Net.WebClient
	    $output=""
	    $output=$webClient.DownloadString($URL)
	    $success=([regex]::Matches($output, $str )).count
        If($successnum -eq $Null){$successnum=1}
        If($success -eq $successnum){Return $True}Else{Return $False}
    }
    Else{Return $False}
}
#####################################################
function CheckSite{
	$URL=$args[0]
	If($URL.Substring(0,1) -eq "f"){
		try{
			$ftp=[system.net.ftpwebrequest] [system.net.webrequest]::create($URL)
			$ftp.method=[system.net.WebRequestMethods+ftp]::listdirectorydetails
			$response=$ftp.getresponse()
			$status=[int]$response.StatusCode
			$Response.Close()
			If($status -eq $Null){Return $False}Else{Return $True}
		}
		catch{
			$Response.Close()
			Return $False
		}	
	}
	ElseIf($URL.Substring(0,1) -eq "h"){
		$request = [System.Net.WebRequest]::Create($URL)
		$response = $request.GetResponse()
		$status = [int]$response.StatusCode
		$Response.Close()
		If($status -eq 200){Return $True}Else{Return $False}
	}	
}
#####################################################
function CheckDNS{
    $Ports=$args[0]
    Remove-Item $DNSLogFile
    Add-Content $DNSLogFile "Port,Status"
    $i=1
    ForEach($port in $Ports){
		Clear-Host
		$port=$port.HostAddress.ToUpper()
		ShowText ("Checking Printer " + $i + " of " + $Ports.Count+" - "+$port) $config.Yellow
		$status=CheckOnline $port
		Add-Content $DNSLogFile ($port+","+$NetworkStatus[$status])
		$i++
	}
    Write-Host
	ShowText "DNS Check Complete" $config.Green
	Invoke-Item $dnslogfile
    ShowText ("Results have been saved to: "+ $dnslogfile) $config.Green
	Pause
}
#####################################################
function CheckOnline{
	If((test-connection -computername $args[0] -count 1 -quiet) -eq $False){
		Try{$Records=[Net.DNS]::GetHostEntry($args[0]);If($Records.HostName -ne $Null){Return 1}}
		Catch{Return 2}
	}
	Else{Return 0}
}
#####################################################
function ExportReportList{
    $selection=AskaQuestion "select the workstation to export"
    $pc=$PCs[$selection-1]
    ShowText "compiling list of pullsource reports, stand by..." $config.Green
    $Reports=CountPath ($config.RelaySource+$pc) 1
    $localreportcsvfile=$PSScriptRoot+"\Output\"+$pc+".csv"
    Remove-Item $localreportcsvfile
    Add-Content $localreportcsvfile $Reports
    ShowText "compiling list of local reports, stand by..." $config.Green
    $Reports=CountPath ("\\"+$pc+"\c$\Epic\Jobs\Processed\"+$config.EpicVersion+"\Epic Print Service") 1
	Add-Content $localreportcsvfile $Reports
	Remove-Item $localreportcsvfile
	ShowText ("export complete, results have been saved to: "+$localreportcsvfile)
}
#####################################################
function OpenResubmitERTF{
    $file=AskaQuestion "Enter the filename"
    $goodpath=""
    ForEach($path in $EPSProcessedPaths){If(Test-Path ($path+$file)){$goodpath=$path+$file}}
    ForEach($path in $EPSFailedPaths){If(Test-Path ($path+$file)){$goodpath=$path+$file}}
    ForEach($path in $EPSIncomingPaths){If(Test-Path ($path+$file)){$goodpath=$path+$file}}
    If($config.UseEPSM -eq 1){ForEach($path in $EPSMIncomingPaths){If(Test-Path ($path+$file)){$goodpath=$path+$file}}}
    If($goodpath -ne ""){
        ShowText ("file found at: "+$goodpath) $config.Yellow
        If($args[0] -eq 1){
            ShowText ("file found at: "+$goodpath) $config.Yellow
            OpenPath $goodpath
        }
        If($args[0] -eq 2){
		    $selection=AskaQuestion "Select the server to resubmit to"
            $DestinationPath=$EPSIncomingPaths[$selection-1]
            MoveFiles $goodpath $DestinationPath 2
        }
    }
    Else{ShowText ("can't find file: "+$file) $config.Red;Pause}
}
#####################################################
function FindTextinERTF{
    $Matches=@()
	$text=AskaQuestion("Enter the text to look for")
	ForEach($path in $EPSProcessedPaths){ShowText ("checking "+$path) $config.Yellow;$Matches+=Select-String -Path ($path+"*.*") -pattern $text -List | Select-Object -Unique Path}
    ForEach($path in $EPSFailedPaths){ShowText ("checking "+$path) $config.Yellow;$Matches+=Select-String -Path ($path+"*.*") -pattern $text -List | Select-Object -Unique Path}
    ForEach($path in $EPSIncomingPaths){ShowText ("checking "+$path) $config.Yellow;$Matches+=Select-String -Path ($path+"*.*") -pattern $text -List | Select-Object -Unique Path}
    If($config.UseEPSM -eq 1){ForEach($path in $EPSMIncomingPaths){ShowText ("checking "+$path) $config.Yellow;$Matches+=Select-String -Path ($path+"*.*") -pattern $text -List | Select-Object -Unique Path}}
    Remove-Item $matchcsvfile
	Add-Content $matchcsvfile ("Files with "+$text)
	ForEach($match in $Matches){Add-Content $matchcsvfile $match.Path}
	OpenPath $matchcsvfile
	ShowText ("Search Complete, results have been saved to: "+$matchcsvfile) $config.Yellow
	Pause  
}
#####################################################
function EnableDisableServer{
    $selection=AskaQuestion ("Select a server to "+$args[0])
    $server=$EPSServers[$selection-1]
    $Services=$args[1]
    ForEach($service in $Services){
        If($args[0] -eq "enable"){StartService $server $service}Else{StopService $server $service}
    }
}
#####################################################
function RestartBCAServices{
    $pc=$args[0]
    If($pc -eq ""){
        $selection=AskaQuestion "select the workstation to restart services"
        $pc=$PCs[$selection-1]
    }
	ShowText ("restarting bca services on "+$pc) $config.Yellow
	$status=CheckOnline $pc
	If($status -eq 0){
        StopService $pc ("EpicPullService"+$config.EpicVersion.Replace(".",""))
        StartService $pc ("EpicPullService"+$config.EpicVersion.Replace(".",""))
    }
    Else{ShowText ($pc.ToString()+" - "+$NetworkStatus[$status]) $config.Red}
}
#####################################################
function StopService{
	$status=CheckOnline $args[0]
	If($status -eq 0){
        Stop-Service -InputObject $(Get-Service -Computer $args[0] -Name $args[1])|Out-Null
        Start-Sleep 5
        While((Get-Service -ComputerName $args[0] -Name $args[1] | Select Status).Status -ne "Stopped"){
            ShowText "Waiting for service to stop..." $config.Yellow
            Start-Sleep 10
            Stop-Service -InputObject $(Get-Service -Computer $args[0] -Name $args[1])|Out-Null
        }
    }
    Else{ShowText ($args[0].ToString()+" - "+$NetworkStatus[$status]) $config.Red}
}
#####################################################
function StartService{
	$status=CheckOnline $args[0]
	If($status -eq 0){Start-Service -InputObject $(Get-Service -Computer $args[0] -Name $args[1])}Else{ShowText ($args[0].ToString()+" - "+$NetworkStatus[$status]) $config.Red}
}
#####################################################
function GetServiceStatus{
	$status=CheckOnline $args[0]
    If($status -eq 0){$servicestatus=(Get-Service -ComputerName $args[0] -Name $args[1] | Select Status).Status;Return $servicestatus}Else{Return $NetworkStatus[$status]}
}
#####################################################
function GetWebApps{
    $Apps=Invoke-Command -ComputerName $args[0] {Get-WebApplication | Select path}
    $Apps1=@()
    ForEach($app in $Apps){
        $apptemp=$app.path
        $apptemp=$apptemp.Replace("/","")
        If($apptemp -ne "MSMQ"){$Apps1+=$apptemp}
    }
    Return $Apps1
}
#####################################################
function ImportCSV{
	$csvpath=AskaQuestion "Enter the path to the csv file"
	$csvpath=$csvpath.replace('"','')
	If(Test-Path $csvpath){$Printers=Import-Csv $csvpath}Else{ShowText ("Invalid location: "+$csvpath) $config.Red}
	Return $Printers
}
#####################################################
function OpenPath{
	If(Test-Path $args[0]){
        ShowText ("opening "+$args[0]) $config.Yellow
        Invoke-Item $args[0]
    }
    Else{ShowText "path does not exist" $config.Red}
}
#####################################################
function CountPath{
	If(Test-Path $args[0]){
        $Files=[System.IO.Directory]::GetFiles($args[0],"*.e???")
        If($args[2] -ne $Null){
            $NewFiles=@()
            ForEach($file in $Files){If(([System.IO.FileInfo]$file).LastWriteTime -lt $args[2]){$NewFiles+=$file}}
        }
        Else{$NewFiles=$Files}
        If($args[1] -eq 1){$count=$Files}Else{If($NewFiles.Count -eq $Null){$count=0}Else{$count=$NewFiles.Count}}
    }
    Else{$count="NO PATH"}
    Return $count
}
#####################################################
function OpenBlobFile{
Write-Host
ShowText "Open Blob file" $config.Yellow
Write-Host
$string=AskaQuestion "enter the name of the file"
$result=$string.split(".")
$file=$result[0].ToCharArray()
$length=$file.length
$x=0
$y=1
$path=""
while ($length -gt 2){
    $path=$path+$file[$x]+$file[$y]+"\"
    $x=$x+2
    $y=$y+2
    $length=$length-2
}
$final=$config.BLOBROOT+$path+$string
OpenPath $final
Pause
}
#####################################################
function MovePullSourceFiles{                        
    $selection=AskaQuestion "Select the folder to move from"
    $SourceFolder=$PCs[$selection-1]
    $selection=AskaQuestion "Select the folder to move to"
    $DestinationFolder=$PCs[$selection-1]
    $confirm=AskaQuestion("Are you sure you want to move file from "+$SourceFolder+" to "+$DestinationFolder+"? enter y to continue, anything else to cancel")
    If($confirm -eq "y"){MoveFiles ($config.RelaySource+$SourceFolder) ($config.RelaySource+$DestinationFolder) 1}Else{Continue}
}
#####################################################
function GenerateCompleteFiles{
    $folder=AskaQuestion "Select the folder to check"
    $path=$config.RelaySource+$PCs[$folder-1]
	$Files=CountPath $path 1
	If($Files.Count -eq 0){ShowText "no complete files needed" $config.Green}
	Else{
	    ForEach($file in $Files){
		    $completefile=$file+".complete"
            If((Test-Path $completefile) -eq $False){
                ShowText ("creating complete file: "+$completefile) $config.Yellow
                New-Item $completefile -type file|Out-Null
            }
        }
    }
}
####################################################
function MoveFiles{
	$SourcePath=$args[0]
	$destinationpath=$args[1]
	$mode=$args[2]
	Switch ($mode){
		1{
			$SourceFiles=CountPath $sourcepath 1 ((Get-Date).AddMinutes(-1))
            If($SourceFiles -eq $Null){ShowText ("No files found at "+$SourcePath) $config.Red;Pause;Continue}
            Else{
                ShowText "moving "+$SourceFiles.Count+" file" $config.Yellow
                $SourcePath=$SourcePath+"\*.*"
                Move-Item $SourcePath $DestinationPath
                ShowText "move complete" $config.Yellow
            }
		}
		2{
            ShowText "moving 1 file" $config.Yellow
            Move-Item $SourcePath $DestinationPath
            ShowText "move complete" $config.Yellow
            Pause
        }
	}
	
}
#####################################################
function ManagePrintQueue{
    $queue=AskaQuestion "Enter the queue to manage (x to cancel)"
    while (($action -ne "x") -and ($queue -ne "x")){
        Clear-Host
        ShowPrintQueueStatus $queue
        Write-Host
        $action=GetMenuSelection "Select an Option" ("Pause","Resume","Purge","Delete","Refresh") ("p","s","g","d","r")
        Write-Host
        ForEach($server in $EPSServers){
            $print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").CreateInstance()
	        $print.DeviceID=$queue
	        Switch($action){
		        p{$print.Pause()|Out-Null}
		        s{$print.Resume()|Out-Null}
		        g{$print.CancelAllJobs()|Out-Null}
		        d{$print.CancelAllJobs()|Out-Null;$print.Delete()|Out-Null}
                r{continue}
	        }
        }
    }
}
#####################################################
function CreatePrinters{
	$Printers=$args[0]
	If($Printers -eq $Null){ShowText "no printers to create" $config.Red;Continue}
	$i=1
	ForEach($printer in $Printers){
		Clear-Host
		If($Printers.isHash -eq $true){ShowText ("Creating printer 1 of 1 - "+$printer.PrinterName) $config.Yellow}
		Else{ShowText ("Creating printer "+$i+" of "+$Printers.count+ " - "+$printer.PrinterName) $config.Yellow}
		$printername=$printer.PrinterName.ToUpper()
		$port=$printer.Port.ToUpper()
		If($config.AskforComment -eq 1){$comment=$printers.Comment}Else{$comment=$config.DefaultComment}
		If($config.AskforLocation -eq 1){$location=$printers.Location}Else{$location=$config.DefaultLocation}		
		$Trays=$Printers.Trays.Split(",")
		ForEach($server in $EPSServers){CreatePort $server $port}
		ForEach($tray in $Trays){ForEach($server in $EPSServers){$printernamewithtray=$printername+$tray;CreatePrinter $server $printer.Drivername $printernamewithtray $port $comment $location}}
		ForEach($tray in $Trays){ForEach($server in $EPSServers){$printernamewithtray=$printername+$tray;SetTrayDefault $server $printer.Drivername $printernamewithtray $tray}}
        $i++
    }
	ShowText "printer creation complete" $config.Yellow
	Pause
	$printers=$Null
}
#####################################################
function GetPrinterInfo{
    $printers=@{}
	$printername=AskaQuestion "Enter the name of the printer"
	$Printers.PrinterName=$printername.ToUpper()
	If($config.UseIPAddress -eq 1){$printers.Port=AskaQuestion "Enter the IP Address of the printer"}Else{$Printers.Port=$Printers.PrinterName}
	If((CheckOnline $Printers.Port) -gt 0){
        $continue=AskaQuestion "Printer is offline, type yes to continue creating printer, or anything else to cancel"
        If($continue -ne "yes"){Continue}
    }
    $Printers.DriverName=GetDriverSelection
    If($TrayLabels.Count -eq 1){$Printers.Trays=$TrayNames}Else{$Printers.Trays=GetMultiSelection "select the trays to build" $config.TrayLabels.Split(",") $config.TrayNames.Split(",")}
	If($config.AskForComment -eq 1){$Printers.Comment=AskaQuestion "Enter comment" 1}Else{$Printers.Comment=$config.DefaultComment}
	If($config.AskForLocation -eq 1){$Printers.Location=AskaQuestion "Enter location" 1}Else{$Printers.Location=$config.DefaultLocation}
	$Printers.isHash=$true
	Return $Printers
}
#####################################################	
function SetTrayDefault{
    $server=$args[0]
    $driver=$args[1]
    $printer=$args[2]
    $tray=$args[3]
    $binfile=$binlocation+$driver+$tray+'.bin'
    $binfile=$binfile.replace("/","_")
    If(Test-Path $binfile){Start-Sleep 3;SetBinFile $server $printer $binfile}Else{CreateBinFile $server $printer $binfile}
}
#####################################################
function CreatePrinter{
    $server=$args[0]
	$driver=$args[1]
	$printer=$args[2]
	$port=$args[3]
	$comment=$args[4]
	$location=$args[5]
	$print=([WMICLASS]"\\$server\ROOT\cimv2:Win32_Printer").createInstance()
	$print.drivername=$driver
    $print.PortName=$port
    $print.Shared=$false
	$print.DeviceID=$printer 
    $print.Comment=$comment
	$print.Location=$location
	$print.Rawonly = $true
	$print.EnableBIDI= $false  
	ShowText ("creating print queue: \\"+$server+"\"+$printer) $config.Green 
	$print.Put()|Out-Null
}
#####################################################
function CreatePort{
    $server=$args[0]
	$printer=$args[1]
    $port=([WMICLASS]"\\$server\ROOT\cimv2:Win32_TCPIPPrinterPort").createInstance() 
    $port.Name=$printer
    $port.SNMPEnabled=$false 
    $port.Protocol=1 
    $port.HostAddress=$printer 
    ShowText ("creating printer port: '"+$printer+"' on " +$server) $config.Green
    $port.Put()|Out-Null
}
#####################################################
function CreateBinFile{
    $server=$args[0]
    $printer=$args[1]
    $binfile=$args[2]
    printui.exe /n \\$server\$printer /p
    ShowText "BINARY FILE DOESN'T EXIST`r`nPlease configure defaults for this queue type, save and close the window`r`nPress ENTER when complete.  A file will be created with the setting for future use." $config.Red
	Read-Host 
    $createbincommand='rundll32 PrintUI.dll,PrintUIEntry /Ss /n \\'+ $server+'\'+$printer+' /a "'+$binfile+'"' 
	ShowText ("creating bin file: "+$binfile) $config.Green
    Invoke-Expression $createbincommand
    Start-Sleep -s 5
}
#####################################################
function SetBinFile{
    $server=$args[0]
    $printer=$args[1]
    $binfile=$args[2]
    Start-Sleep 3
    $traycommand='rundll32 PrintUI.dll,PrintUIEntry /Sr /n \\'+ $server+'\'+$printer+' /q /a "'+$binfile+'" r d u g'
    ShowText ("setting printer defaults: \\"+$server+"\"+$printer) $config.Green
    Invoke-Expression $traycommand
}
#####################################################
function GetWebServerName{
    $folderxmlpath=$config.WebSource+$args[0]+"\folder.xml"
    If(Test-Path $folderxmlpath){$folderxml=Get-Content $folderxmlpath}Else{$folderxml="Unknown Location - "+$args[0]}
    $folderxml=[STRING] $folderxml
    $folderxml=$folderxml.Replace('<folderinfo name="',"")
    $folderxml=$folderxml.Replace('" descriptions="" hidden="false" groups=""></folderinfo>',"")
    $folderxml=$folderxml.Replace('" descriptions="" hidden="true" groups=""></folderinfo>',"")
    Return [STRING] $folderxml
}
#####################################################
function GetMultiSelection{
	$DisplayList=$args[1]
    $ReturnList=$args[2]
    $i=1
    ShowText ($args[0]+":") $config.Blue
	ForEach ($item in $DisplayList){
		If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText ($i.ToString()+$space+$item) $config.White
        $i++
	}
    ShowText ("A"+$space+"all of the above") $config.White
    Do{
        $selection=AskAQuestion "Selection" 1
        If($selection -eq "a"){ForEach($item in $ReturnList){$FinalList+=$item+","}}
        If($selection -ne ""){$FinalList+=$ReturnList[$selection-1]+","}
    }While(($selection -ne "") -and ($selection -ne "a"))
    $Return=$FinalList.TrimEnd(",")
    Return $Return
}
#####################################################
function GetMenuSelection{
	$List=$args[1]
    $Selections=$args[2]
    $i=0
    $stoploop=$false
    If($args[3] -ne $Null){
        ShowText $args[3] $config.Yellow
        Write-Host
    }
    ShowText ($args[0]+":") $config.Blue
	ForEach ($item in $List){ShowText ($Selections[$i]+": "+$item) $config.White;$i++}
    ShowText ("x: cancel") $config.White
    Do{
        $selection=AskaQuestion "selection" 1
        If($selection -eq "x"){$stoploop=$true}
        ForEach($item in $Selections){If($item -eq $selection){$stoploop=$true}}
        If($stoploop -eq $false){ShowText "selection not valid" $config.Red}
    }While($stoploop -eq $false)
    return $selection
}
#####################################################
function GetDriverSelection{
	$FullDrivers=Get-WmiObject -Class Win32_PrinterDriver -ComputerName $EPSServers[0]
    $Drivers=@()
    ForEach($item in $FullDrivers){$Drivers+=$item.Name -replace ',3,Windows x64',''}$List=$args[1]
    ShowText "Select the driver from the following list:" $config.Blue
    $i=1
	ForEach ($item in $Drivers){
		If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText ($i.ToString()+$space+$item) $config.White
        $i++
	}
    $selection=AskAQuestion "Selection"
	Return $Drivers[$selection-1]
}
#####################################################
function DeleteHSWApps{
    Clear-Host
    ShowText "Delete hsw apps" $config.Yellow
    $HSWServers=$config.HSWServers.Split(",")
    $Apps=Invoke-Command -ComputerName $HSWServers[0] {Get-WebApplication | Select ApplicationPool,PhysicalPath}
    $i=1
    ShowText "Select the hsw app to delete" $config.Blue
	ForEach ($item in $Apps){
		If($i -gt 9){$space=". "}Else{$space=".  "}
        ShowText ($i.ToString()+$space+$item.ApplicationPool) $config.White
        $i++
	}
    $selection=AskAQuestion "Selection"
    $AppToDelete=$Apps[$Selection-1]
    $confirm=AskaQuestion ("delete "+$AppToDelete.applicationPool+"? type yes to delete, anything else to cancel...")
    If($confirm -eq "yes"){ 
        ForEach($server in $HSWServers){
            Invoke-Command -ComputerName $server {Remove-WebApplication -Site "Default Web Site" -Name $args[0]} -args $AppToDelete.ApplicationPool
            Invoke-Command -ComputerName $server {Remove-WebAppPool -Name $args[0]} -args $AppToDelete.ApplicationPool
            Invoke-Command -ComputerName $server {Remove-Item $args[0] -Recurse} -args $AppToDelete.PhysicalPath
        }
    }
}
#####################################################
function AddTab{
    $beforetab=[string] $args[0]	
    If($args[1] -eq 1){$char=15-$beforetab.length}
    ElseIf($args[1] -eq 2){$char=30-$beforetab.length}
    Else{$char=45-$beforetab.length}
    $aftertab=$beforetab
	For($i=1;$i -le $char;$i++){
        If($args[2] -eq 1){$aftertab=$aftertab+"-"}Else{$aftertab=$aftertab+" "}
    }
	Return $aftertab
}
#####################################################
function AskaQuestion{
	$question=$args[0]+": "
	ShowText $question.ToUpper() $config.Blue 1
	$answer=Read-Host
	While(($answer -eq "")-and ($args[1] -ne 1)){
        ShowText "RESPONSE CANNOT BE BLANK" $config.Red
        ShowText $question.ToUpper() $config.Blue 1
        $answer=Read-Host
    }
	Return $answer
}
####################################################
function ShowText{
    If($args[1] -eq $Null){
        $color=$config.White
        Write-Host $args[0]
    }
    Else{
        $color=$args[1]
        If($args[2] -eq 1){
            Write-Host -foreground $color -NoNewLine $args[0].ToUpper()
        }
        Else{
            Write-Host -foreground $color $args[0].ToUpper()
        }
    } 
}
####################################################
function Pause{
    Read-Host 'Press Enter to continue...' | Out-Null
}
####################################################