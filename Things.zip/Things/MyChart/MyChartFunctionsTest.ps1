﻿$BLD_Instance = "D:\Program Files (x86)\Epic\MyChart\v10.2-Customizations_MYCHARTBLD_InstanceSpecificChanges\*"
$BLD_Working = "D:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTBLD\"
#$BLDSSO_Instance = "D:\Program Files (x86)\Epic\MyChart\v10.2-Customizations_MyChartSSOBLD_InstanceSpecificChanges\*"
#$BLDSSO_Working = "D:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTSSOBLD\"

$TST_Instance = "D:\Program Files (x86)\Epic\MyChart\v10.2-Customizations_MyChartTST_InstanceSpecificChanges\*"
$TST_Working = "D:\Program Files (x86)\Epic\MyChart\v10.2-MyChartTST\"
$TSTSSO_Instance = "D:\Program Files (x86)\Epic\MyChart\v10.2-Customizations_MyChartSSOTST_InstanceSpecificChanges\*"
$TSTSSO_Working = "D:\Program Files (x86)\Epic\MyChart\v10.2-MyChartSSOTST\"

function PostDeployCopy {

Write-Host -foreground yellow "Copying..."
Echo "Source: $($args[0])"
Echo "Target: $($args[1])"
Copy-Item -Path $args[0] -Destination $args[1] -Force -Recurse

}

PostDeployCopy $BLD_Instance $BLD_Working
#PostDeployCopy $BLDSSO_Instance $BLDSSO_Working
PostDeployCopy $TST_Instance $TST_Working
PostDeployCopy $TSTSSO_Instance $TSTSSO_Working

Get-Service -Name w3svc | Restart-Service -Force