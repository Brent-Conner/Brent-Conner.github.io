#Requires -RunAsAdministrator

# Get IPv4 address of local server
$dnsDomain = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "ipenabled = 'true'" | Where-Object -Property DNSDomain | Select-Object -ExpandProperty DNSDomain
$ipaddress = Read-Host "IP address of this server" #Test-Connection -ComputerName "$env:COMPUTERNAME.$dnsDomain" -Count 1 | Select-Object -ExpandProperty IPV4Address | Select-Object -ExpandProperty IPAddressToString

# Read HTTPS bindings from IIS, proceed silently if only port 443 is used or prompt for input if not.
$webBindings = Get-WebBinding | Where-Object -Property protocol -eq https | Select-Object -ExpandProperty bindingInformation 

# Assume port 443 if no other action is taken
$myChartPort = "443"

foreach ($binding in $webBindings)
{
    if($binding -notlike "*:443:*")
    {
        Write-Warning "Non-Standard HTTPS port binding detected - Which port is used for MyChart? (443 is standard)"
        Write-Output $webBindings
        $myChartPort = Read-Host "MyChart Port"
    }
}

Write-Output "IP address: $ipaddress"
Write-Output "Port: $myChartPort"

##############
# Functions #
##############

# Encode port (existing CSTS function - no changes made).
function _portencode {
    Param (
        [Parameter(Mandatory = $true)]
        [int]$port
    )

    ############# Port Encoding - Common to both ######
    # Converts the port number to hexadecimal
    $portpart = '{0:X4}' -f $port

    #Lots of casting for ease of handling.  First, force the hex to string, so we can swap first half and last half
    # Add 0x to the beginning so that Powershell can handle converting the number for us back to an int after swapping
    # hex digit placement
    $portpart = ([int]([string]("0x" + $portpart.Substring(2, 2) + $portpart.Substring(0, 2))))
    return $portpart
}


############# IPv4 Encoding #######################
$IPv4Multi = 256

# We calculate the IP address part by working with integers
# First octet - no adjustment (multiplied by 256^0)
# Second octet - multiplied by 256^1
# Third octet - Multipled by 256^2.  And so on
$ippart = 0

for ($i = 0; $i -le 3; $i++) {
    $ippart += ([int]($ipaddress.split(".")[$i]) * [math]::pow($IPv4Multi, $i))
}

$portpart = _portencode -port $myChartPort

# Format the entire string into a cookie
$cookieValue = "$ippart.$portpart.0000"

Write-Output "Cookie value: $cookieValue"


#####################################
# Set-cookie response header in IIS #
#####################################

# Create new ServerManager object
[System.Reflection.Assembly]::LoadFrom("$env:systemroot\system32\inetsrv\Microsoft.Web.Administration.dll") | Out-Null 
$iis = New-Object -TypeName Microsoft.Web.Administration.ServerManager

# Get custom headers collection from application host configuration file (essentially just web.config, but at the server level)
$config = $iis.GetApplicationHostConfiguration()
$customHeadersCollection = $config.GetSection("system.webServer/httpProtocol").GetCollection("customHeaders")

# Quit if set-cookie header already exists in applicationHost.config. An error will be thrown if it already exists, as duplicate entries of the same name cannot be added.
ForEach ($header in $customHeadersCollection) {
    If ($header.RawAttributes.ContainsValue("Set-Cookie")) {
        Write-Warning "Set-Cookie header already exists in applicationHost.config. No changes were made. If you have not run this script previously, work with your Epic MyChart TS to determine appropriate next steps."
        Write-Warning "Note: If you use Citrix NetScaler as your load balancer, you will need to specify this value ($cookieValue) when adding this server object to the service group binding."
        exit
    }   
}

# Build custom set-cookie response header with MyChart persistence cookie.
$addElement = $customHeadersCollection.CreateElement("add")
$addElement["name"] = "Set-Cookie"
$addElement["value"] = "MyChartPersistence=" + $cookieValue + "; path=/; httponly; secure"

# Set the response header
$customHeadersCollection.Add($addElement) | Out-Null
Write-Output "Header created in applicationHost.config:"
Write-Output ($addElement.Attributes.Value[0] + ": " + $addElement.Attributes.Value[1])
Write-Warning "Note: If you use Citrix NetScaler as your load balancer vendor, you will need to specify this value ($cookieValue) when adding this server object to the service group binding.`n"

# Commit changes
$iis.CommitChanges()
