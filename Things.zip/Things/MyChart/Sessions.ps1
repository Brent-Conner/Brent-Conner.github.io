﻿$server = Read-Host "Server"

Function users {
$connections = ((Get-Counter -Counter 'web service(_total)\Current connections' -Computername localhost).CounterSamples).CookedValue
Echo $connections }
#Write-Host $server "-" $connections }

#Get-Counter -ListSet ASP* | Select -expand counter | ?{$_ -match 'session'}