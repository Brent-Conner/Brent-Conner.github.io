﻿$servers = Get-Content D:\Scripts\_Servers\AzurePOC.txt


foreach($server in $servers) {
Write-Host "***************** $server start ********************"

Invoke-Command -ComputerName $server { New-Item -Path C:\Certs\ -Type Directory -Force }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\Cert\star.pfx" -Destination C:\Certs\ -Force -recurse -ToSession $s

Invoke-Command -cn $server {
    Import-PfxCertificate -FilePath "C:\Certs\star.pfx" -Password (ConvertTo-SecureString -String "password" -AsPlainText -Force) -CertStoreLocation Cert:\LocalMachine\My -Exportable
    New-WebBinding -Name "Default Web Site" -Port 443 -Protocol https;
    $cert = Get-ChildItem -Path Cert:\LocalMachine\My | where-Object {$_.subject -like "*.mountsinai.org*"};
    (Get-WebBinding -Port 443).AddSslCertificate($cert.Thumbprint,"My")
    }
Write-Host "***************** $server end ********************"
Pause
}