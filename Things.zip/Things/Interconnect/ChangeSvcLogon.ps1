﻿$svcs = (Get-Service -name Inter*).name
$apps = (Get-IISAppPool | Where-Object {$_.Name -match 'Interconnect'}).name
$cred = Get-Credential
$user = $cred.username
$pass = $cred.GetNetworkCredential().password

foreach($svc in $svcs) {
Echo $svc
&sc.exe config "$svc" obj= "$user" password= "$pass"
Restart-Service -Name $svc -force
}

foreach($app in $apps) {
Import-Module WebAdministration
Echo $app
Set-ItemProperty IIS:\AppPools\$app -name processModel -value @{userName="$user";password="$pass";identitytype=3}
Restart-WebAppPool -name $app
}