﻿# Delete Temp ASP NET files from previous CP versions
$servers = "Server1","Server2"


Function Remote {
foreach($server in $servers) {
$aspnet = "\\$server\C$\Windows\Microsoft.NET\Framework64\v4.0.30319\Temporary ASP.NET Files\"
$paths = Get-ChildItem $aspnet -Directory
    foreach($path in $paths) {
        if($path -match "interconnect") {
        $path = $aspnet + $path
        Write-Host $path
        Get-ChildItem $path -Directory | Sort-Object CreationTime -Descending | Select-Object -Skip 1 | Remove-Item -Recurse -Force
        } } } }

Function Local {
$aspnet = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Temporary ASP.NET Files\"
$paths = Get-ChildItem $aspnet -Directory
    foreach($path in $paths) {
        if($path -match "interconnect") {
        $path = $aspnet + $path
        Write-Host $path
        Get-ChildItem $path -Directory | Sort-Object CreationTime -Descending | Select-Object -Skip 1 | Remove-Item -Recurse -Force
        } } }