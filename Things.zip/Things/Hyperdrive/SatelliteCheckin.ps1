﻿$cmd = Get-ItemPropertyValue "HKLM:\SOFTWARE\WOW6432Node\Epic Systems Corporation\Satellite" -Name Path
$arg = "/F"
Start-Process -FilePath $cmd -ArgumentList $arg -Verb RunAs -Wait
Start-Process -FilePath $cmd -ArgumentList $arg -Verb RunAs -Wait