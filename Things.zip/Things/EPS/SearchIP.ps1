﻿#$header = "IP^namebyip^namebyportname^comment"
#$header | Out-file -filepath C:\Scripts\ONEEPIC\out.txt -append

#$ips = get-content C:\Scripts\ONEEPIC\IPs.txt

#foreach($ip in $ips) {
Remove-Variable * -ErrorAction SilentlyContinue
$ip = Read-host "IP"

$portnames = Get-PrinterPort -cn sepiepsp018004 | Where-Object { $_.printerhostaddress -match $ip }

if ($portnames) {
    $array = $portnames.name -is [array]
    
    switch ($array) {
        False {
            $printer = Get-Printer -cn sepiepsp018004 | Where-Object { $_.portname -match $portnames.name } 
            Write-Host -foregroundcolor green "<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>"
            Write-Host "Name:"$printer.name
            Write-host "Comment:"$printer.comment
            Write-host "Port Name:"$portnames.name
            Write-Host "Port HostAddress:"$portnames.printerhostaddress
            Write-Host -foregroundcolor green "<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>"
            }
        True {
            $i = 0 
            foreach($portname in $portnames.name) {
            Write-Host -foregroundcolor green "<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>"
            $printer = Get-Printer -cn sepiepsp018004 | Where-Object { $_.portname -match $portname }
            Write-Host "Name:"$printer.name
            Write-host "Comment:"$printer.comment
            Write-host "Port Name:"$portnames[$i].name
            Write-Host "Port HostAddress:"$portnames[$i].printerhostaddress
            $i++
            Write-Host -foregroundcolor green "<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>"
            } } } }

else { Write-Host -foregroundcolor red "$ip not found" }




#header = IP,namebyip,namebyportname,comment
#$out = $ip + "^" + $findprinterbyip.name + "^" + $findprinterbyportname.name + "^" + $findprinterbyip.comment + $findprinterbyportname.comment


#$out | Out-file -filepath C:\Scripts\ONEEPIC\out.txt -append
#}