﻿#$EPSservers = ("ZWTSTEPICEPS11","ZWTSTEPICEPS12","ZWTSTEPICEPS13")
$EPSservers = ("ZWPDCEPICEPS11","ZWPDCEPICEPS12","ZWPDCEPICEPS13","ZWPDCEPICEPS14","ZWPDCEPICEPS15","ZWPDCEPICEPS16","ZWPDCEPICEPS17","ZWPDCEPICEPS18")

function TroyConfigBackup
{
    $Num = 1
    foreach($server in $EPSservers) { Write-Host $Num - $server; $Num++ }
    $Choice = Read-Host "Choose source server"
    $SrcServer = $EPSServers[$Choice-1]
    Write-Host $SrcServer

    Write-Host "Creating backup of all Troy ports on $SrcServer"
    
    $TroyPort = 1
    #while($TroyPort -lt 11)
    while($TroyPort -lt 501)
    {
    $SrcConfig1 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPantographConfiguration.xml"
    $SrcConfig2 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Config\TroyPortMonitorConfiguration.xml"
    $SrcData1 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile1Page1.pcl"
    $SrcData2 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile1Pages2Plus.pcl"
    $SrcData3 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile2Page1.pcl"
    $SrcData4 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile2Pages2Plus.pcl"
    $SrcData5 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile3Page1.pcl"
    $SrcData6 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile3Pages2Plus.pcl"
    $SrcData7 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile4Page1.pcl"
    $SrcData8 = "\\$SrcServer\d$\Program Files\TROY Group\Port Monitor\PrintPort$TroyPort\Data\PantographProfile4Pages2Plus.pcl"

        $To1 = "\\$SrcServer\d$\TroyConfigBackup\PrintPort$TroyPort\Config\"
        $To2 = "\\$SrcServer\d$\TroyConfigBackup\PrintPort$TroyPort\Data\"

        
        if (!(Test-Path -path $To1)) { New-Item $To1 -Type Directory }
        if (!(Test-Path -path $To2)) { New-Item $To2 -Type Directory }

        Copy-Item -Path $SrcConfig1 -Destination $To1 -Force -Recurse
        Copy-Item -Path $SrcConfig2 -Destination $To1 -Force -Recurse
        Copy-Item -Path $SrcData1 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData2 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData3 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData4 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData5 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData6 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData7 -Destination $To2 -Force -Recurse
        Copy-Item -Path $SrcData8 -Destination $To2 -Force -Recurse
        
        $TroyPort++
   }        
}

TroyConfigBackup