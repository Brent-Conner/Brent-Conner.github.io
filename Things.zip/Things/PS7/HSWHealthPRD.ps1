﻿$servers = Get-Content \\epicfileshare\epicfileshare\Brent\_Servers\HSW.txt
Echo "Server HealthCheck MaintenanceStatus"
foreach($server in $servers) {
$stat = "blank"
$health = Invoke-WebRequest https://$server.msnyuhealth.org/Hyperspace_PRD/health/healthHandler.ashx?mode=loadbalancer -skipcertificatecheck | % {$_.Content}
$mode = Invoke-WebRequest https://$server.msnyuhealth.org/maintenance/status.json -skipcertificatecheck | % {$_.Content}
$out = $server + " " + $health + " " + $mode
#$out | out-file C:\Scripts\PRDHSWhealthold.txt -Append
echo $out
}
pause