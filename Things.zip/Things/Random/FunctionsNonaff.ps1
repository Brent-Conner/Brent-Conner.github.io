﻿$pcs = get-content "C:\scripts\brent\nonaff.txt"

function startup {
foreach($pc in $pcs) {
$startup = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\*"
write-host $pc
$s = New-PSSession $pc
New-Item -Path "C:\Scripts\Brent\nonaff\$pc\" -ItemType Directory
Copy-Item -Path $startup -Destination "C:\scripts\Brent\nonaff\$pc\" -Force -recurse -FromSession $s
} }

function execheck {
foreach($pc in $pcs) {
$path = "C:\Program Files (x86)\epic\Workflow Conductor\WorkflowConductor.exe"
$test = Invoke-Command -cn $pc -ScriptBlock { Test-Path $using:path }
if($test) { $pc + ",exists" | Out-File "C:\Scripts\Brent\nonaff\execheck.txt" -append }
else { $pc + ",notfound" | Out-File "C:\Scripts\Brent\nonaff\execheck.txt" -append }
} }

startup
execheck