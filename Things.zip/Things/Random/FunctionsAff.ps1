﻿$pcs = get-content "C:\scripts\brent\affinity.txt"

function startup {
foreach($pc in $pcs) {
$startup = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\*"
write-host $pc
$s = New-PSSession $pc
New-Item -Path "C:\Scripts\Brent\affinity\$pc\" -ItemType Directory
Copy-Item -Path $startup -Destination "C:\scripts\Brent\affinity\$pc\" -Force -recurse -FromSession $s
} }

function execheck {
foreach($pc in $pcs) {
$path = "C:\Program Files (x86)\epic\Workflow Conductor\WorkflowConductor.exe"
$test = Invoke-Command -cn $pc -ScriptBlock { Test-Path $using:path }
if($test) { $pc + ",exists" | Out-File "C:\Scripts\Brent\affinity\execheck.txt" -append }
else { $pc + ",notfound" | Out-File "C:\Scripts\Brent\affinity\execheck.txt" -append }
} }


function install {
$wfcmsi = "C:\scripts\Brent\Epic February 2023 Workflow Conductor-Pack 6.msi"
$wfclnk = "C:\scripts\Brent\Epic Workflow Conductor.lnk"
$pc = "CD386855.affinityhealth.net"

$exist = Invoke-Command -cn $pc -scriptblock { Test-Path "C:\Program Files (x86)\Epic\Workflow Conductor\WorkflowConductor.exe" }
if($exist) {
$s = New-PSSession $pc
Invoke-Command -cn $pc { New-Item -Path "C:\WFCFeb2023\" -ItemType Directory }
#Copy-Item -path $wfcmsi -Destination "C:\WFCFeb2023\" -Force -ToSession $s
Invoke-Command -cn $pc { Remove-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\*workflow*" }
Copy-Item -path $wfclnk -destination "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\" -force -ToSession $s
Invoke-Command -session $s { msiexec /i "C:\WFCFeb2023\Epic February 2023 Workflow Conductor-Pack 6.msi" /norestart /quiet /lv+ "C:\WFCFeb2023\install.log" }
}
Else{ Echo "doh" }
}
function regcheck {
$pc = Read-Host "PC"
Invoke-command -cn $pc { Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Epic Systems Corporation\PoolManager" }