﻿$pcs = get-content -path "c:\scripts\trackboards\affKickstartList.txt"

foreach($pc in $pcs) {


$Warp = "C:\Program Files (x86)\Epic\WarpDrive\WarpDrive.exe"
$Warpt = Invoke-Command -cn $pc -ScriptBlock { Test-Path $using:warp }
$Hyp = "C:\Program Files (x86)\Epic\Hyperdrive\VersionIndependent\Hyperspace.exe"
$Hypt = Invoke-Command -cn $pc -ScriptBlock { Test-Path $using:hyp }


$out = $pc + "," + $warpt + "," + $hypt
$out | out-file -filepath c:\scripts\trackboards\checkaff.txt -append
}