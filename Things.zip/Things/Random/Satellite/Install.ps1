﻿$pcs = Get-content "C:\scripts\Brent\domain\hostnames.txt"
#
function SATmulti {
foreach($pc in $pcs) {
Write-host $pc
$s = New-Pssession $pc
Invoke-Command -cn $pc { New-Item -Path C:\EpicInstall\ -Type Directory -Force }
Copy-Item -Path "C:\scripts\Brent\Satellite\SatellitePrep.bat" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Copy-Item -Path "C:\scripts\Brent\Satellite\SatelliteSetup.exe" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Invoke-Command -ComputerName $pc -ScriptBlock { C:\EpicInstall\SatellitePrep.bat }
} }

function SATone {
$pc = Read-host "PC:"
Write-host $pc
$s = New-Pssession $pc
Invoke-Command -cn $pc { New-Item -Path C:\EpicInstall\ -Type Directory -Force }
Copy-Item -Path "C:\scripts\Brent\Satellite\SatellitePrep.bat" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Copy-Item -Path "C:\scripts\Brent\Satellite\SatelliteSetup.exe" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Invoke-Command -ComputerName $pc -ScriptBlock { C:\EpicInstall\SatellitePrep.bat }
}

