﻿$user = "wheatfranrobot"
$pw = "wF@Sc1$5x4"

Invoke-RestMethod 


Request URL:  https://eeds.epic.com/Token

Request Body:  grant_type=password&username=<robot user name>&password=<robot password>  

Request Body Example:  grant_type=password&username=EpicRobot1&password=ep1cr0b0t