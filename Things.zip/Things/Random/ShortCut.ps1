﻿$pc = read-host "PC"
$startup = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\"
$add = "C:\scripts\Brent\WFC\Epic Workflow Conductor.lnk"
$s = New-PSSession $pc

Function Remove {
Invoke-Command -ComputerName $pc { Remove-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\*workflow*" -Force }
}

Function Add {
Copy-Item -Path $add -Destination $startup -Force -ToSession $s
}


