﻿$src = "c:\users\lgagnow\appdata\local\temp\slingshotlogs\*.log"
$dst = "C:\scripts\Logs\slingshot"

$pc = "cd143350.affinityhealth.net"
$s = New-PSSession $pc

Copy-Item -Path $src -Destination $dst -FromSession $s -Recurse -Force

#Invoke-Command -cn $pc { Get-ItemPropertyValue "HKLM:\SOFTWARE\WOW6432Node\Citrix\ICA Client\Engine\Lockdown Profiles\All Regions" -Name EnableLockdown }