﻿Function NonPrd {
$pc = Read-Host "PC"
$s = New-Pssession $pc
Invoke-Command -cn $pc { New-Item -Path C:\EpicInstall\ -Type Directory -Force }
Copy-Item -Path "C:\scripts\Voicebrook\AscensionWisconsinHyperdriveNonProdCertificate.pfx" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Invoke-Command -cn $pc { Import-PfxCertificate -FilePath "C:\EpicInstall\AscensionWisconsinHyperdriveNonProdCertificate.pfx" -Password (ConvertTo-SecureString -String "4#K172DjBn&D" -AsPlainText -Force) -CertStoreLocation Cert:\LocalMachine\root -Exportable }
}


Function PRD {
$pc = Read-Host "PC"
$s = New-Pssession $pc
Invoke-Command -cn $pc { New-Item -Path C:\EpicInstall\ -Type Directory -Force }
Copy-Item -Path "C:\scripts\Voicebrook\AscensionWisconsinHyperdriveProdCertificate.pfx" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Invoke-Command -cn $pc { Import-PfxCertificate -FilePath "C:\EpicInstall\AscensionWisconsinHyperdriveProdCertificate.pfx" -Password (ConvertTo-SecureString -String "_3q7E1I9}Mcl" -AsPlainText -Force) -CertStoreLocation Cert:\LocalMachine\root -Exportable }
}

Function PRDmulti {
$pcs = Get-Content "C:\scripts\Voicebrook\pcs.txt"
foreach ($pc in $pcs) {
Echo $pc
$s = New-Pssession $pc
Invoke-Command -cn $pc { New-Item -Path C:\EpicInstall\ -Type Directory -Force }
Copy-Item -Path "C:\scripts\Voicebrook\AscensionWisconsinHyperdriveProdCertificate.pfx" -Destination C:\EpicInstall\ -Force -recurse -ToSession $s
Invoke-Command -cn $pc { Import-PfxCertificate -FilePath "C:\EpicInstall\AscensionWisconsinHyperdriveProdCertificate.pfx" -Password (ConvertTo-SecureString -String "_3q7E1I9}Mcl" -AsPlainText -Force) -CertStoreLocation Cert:\LocalMachine\root -Exportable }
} }