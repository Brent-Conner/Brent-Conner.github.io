﻿# Clear-Host
# Global Variables
##################
$WinRM = ("WinRM")
$PullService = ("EpicBCAClient93")
$LocalUser = ("\Presbyterian")
$FDout = "\\pacfile2\groups\epic\Technical Team\BCA\FireDisaster\Fire and Disaster Facility Procedures\"
$HICSout = "\\pacfile2\groups\epic\Technical Team\BCA\FireDisaster\HICS Forms and Job Action Sheets\"
$2019shortcut = '\\netappb\EpicRA\2017\BCAPC\BCA Printing - 2019.lnk'
#$LocalPW
##################

# Menu Functions

function RestartPull
{
$PC = Read-Host "Silver tag"
    if($PC -eq $null) { break }
    if(test-netconnection -computername $PC -InformationLevel Quiet)
    {
        Write-Host -foreground green "Restarting $PullService on $PC"
        Get-Service -ComputerName $PC -Name $PullService | Restart-Service -Force
        $status = Get-Service -ComputerName $PC -Name $PullService
        Write-Host $status.status $status.name
    }
    else { Write-Host -foreground red "$PC is offline" }
}

function RestartPullList
{
$path = Read-Host "Enter path + name to list"
    $pcs = Get-Content $path
    foreach($pc in $PCs) {
    #if($PC -match $null) { break }
    if(test-netconnection -computername $PC -InformationLevel Quiet)
    {
        Write-Host -foreground green "Restarting $PullService on $PC"
        Get-Service -ComputerName $PC -Name $PullService | Restart-Service -Force
        $status = Get-Service -ComputerName $PC -Name $PullService
        Write-Host $status.status $status.name
    }
    else { Write-Host -foreground red "$PC is offline" }
    }
}

function ReportDate
{
$rpt = $null
Write-Host "Most recent report will be displayed"
$PC = Read-Host "Silver Tag"
Invoke-Command -cn $PC { $rpt = Get-ChildItem "C:\Epic\Jobs\Processed\Epic Bca Client\" | Select Name,LastWriteTime ; Write-Host $rpt[-1] }
Pause
}

function Prep
{
$PC = Read-Host "Silver Tag"
If (Test-NetConnection -ComputerName $PC -InformationLevel Quiet)
    {
    Write-Host -foreground green "Starting $WinRM on $PC"
    Get-Service -ComputerName $PC -Name $WinRM | Restart-Service -Force
    Write-Host -foreground green "Setting $WinRM startup type to automatic on $PC"
    Set-Service -ComputerName $PC -Name $WinRM -StartupType Automatic
    $status = Get-Service -ComputerName $PC -Name $WinRM
    Write-Host "Final settings on $PC"
    Write-Host $status.status $status.name $status.StartType
    Write-Host "Adding local user"
    Invoke-Command -ComputerName $pc { net user Presbyterian 'Pre$byterian1' /add; net localgroup administrators Presbyterian /add }
    $s = New-Pssession $pc
    Write-Host "Adding to Epic_BCA_Machines group"
    Add-ADGroupMember -Identity Epic_BCA_Machines -Members $PC$
    Invoke-Command -ComputerName $pc { New-Item -Path C:\BCAPC\ -Type Directory -Force }
    Copy-Item -Path "\\pacfile2\groups\epic\Technical Team\BCA\Satellite\BCAPCPRD.bat" -Destination C:\BCAPC\ -Force -recurse -ToSession $s
    Copy-Item -Path \\netappb\EpicRA\Independent\Kuiper\SatelliteSetup.exe -Destination C:\BCAPC\ -Force -recurse -ToSession $s
    Invoke-Command -ComputerName $pc -ScriptBlock { C:\BCAPC\BCAPCPRD.bat }
    Copy-Item -Path $FDout -Destination 'C:\users\public\desktop' -Force -recurse -ToSession $s
    Copy-Item -Path $HICSout -Destination 'C:\users\public\desktop' -Force -recurse -ToSession $s
    #Copy-Item -Path '\\pacfile2\groups\epic\Technical Team\BCA\Mayshortcut\BCA Printing.lnk' -Destination C:\Users\Public\Desktop -Force -ToSession $s

    }
Else { Write-Host "Failed to Connect to $PC" }
}

function Install2017
{
$PC = Read-Host "Silver Tag"
If (Test-NetConnection -ComputerName $PC -InformationLevel Quiet)
    {
    $s = New-Pssession -ComputerName $PC
    Copy-Item -Path $2017image -Destination C:\BCA2017 -Force -Recurse -ToSession $s
    Invoke-Command -session $s { msiexec /i "C:\BCA2017\Epic 2017 BCA PC.msi" /qb! /lv+ "C:\BCA2017\install.log" }
    Copy-Item -Path $2017shortcut -Destination C:\Users\Public\Desktop -Force -ToSession $s
    }

Else { Write-Host "Failed to Connect to $PC" }
}

# Menu
##################
while(1)
{
$pc = $null
    Write-Host -foreground Cyan "BCA Tools"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  Restart BCA service for a PC"
    #Write-host "2.  Restart BCA service for a list of BCAs"
    Write-Host "2.  Query most recent report date of BCA PC"
    Write-Host "3.  Prep BCA PC: WinRM settings, Local user, Satellite"
    #Write-Host "5.  Install 2017 remotely"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    $MenuOption = Read-host "Selection"
    
    Switch($MenuOption)
    {
        "1"  {RestartPull}
        ""  {RestartPullList}
        "2"  {ReportDate}
        "3"  {Prep}
        ""  {Install2017}
        default {Continue}
    }
}
##################

Function BCAVIP {
$pc = Read-Host "PC"
$s = New-PSSession $pc
$source = '\\pacfile2\groups\epic\Technical Team\BCA\EpicBCAClient.config.xml'
$dest = "C:\Epic\Bin\8.8\Epic Print Service"
$PullService = ("EpicBCAClient88")
Copy-Item -Path $source -Destination $Dest -Force -recurse -ToSession $s

Get-Service -ComputerName $PC -Name $PullService | Restart-Service -Force
}