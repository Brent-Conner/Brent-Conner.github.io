﻿# Global Variables
##################
$PullService = ("EpicBCAClient83")

while(1)
{
$PC = Read-Host "Enter silver tag"
    if(test-connection $PC -count 2 -ea SilentlyContinue)
    {
        Write-Host -foreground green "Restarting $PullService on $PC"
        Get-Service -ComputerName $PC -Name $PullService | Restart-Service -Force
        $status = Get-Service -ComputerName $PC -Name $PullService
        Write-Host $status.status $status.name
    }
    else { Write-Host -foreground red "$PC is offline" }
}