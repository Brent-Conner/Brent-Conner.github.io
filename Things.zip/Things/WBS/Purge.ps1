﻿
#$paths = "\\EPICWBLOBTST\epicwblobtst_archive01\WBSTST\","\\EPICWBLOBTST\epicwblobtst_archive01\WBSBLD\","\\Epicwblobtst\wbs\","\\Epicwblobtst\wbsbld\","\\Epicwblobtst\wbstst\","\\EPICWEBBLOB\EpicWebBlob\BCAWBSPRD\"

#$path = "\\EPICWEBBLOB\wbsarchive1\WBSPRD\"
#$paths = "\\epicwebblob\wbs2021$\WBSPRD\",

$paths = "\\wbsbackup\WBSPRD\","\\EPICWEBBLOB\EpicWebBlob\WBSPRD\","\\EpicWeb\WBS2023$\WBSPRD\"

$start = Get-Date
foreach($path in $paths) {
Send-Mailmessage -to "brent.conner@mountsinai.org" -from "A007@mountsinai.org" -Subject "WBS Script Update" -body "Start: $start
Path: $path" -SmtpServer "smtp.mountsinai.org"

Echo $path
Remove-Item -Path $path* -Recurse

}
$end = Get-Date
Send-Mailmessage -to "brent.conner@mountsinai.org" -from "A007@mountsinai.org" -Subject "WBS Script Update" -body "End: $end
Path: $path" -SmtpServer "smtp.mountsinai.org"