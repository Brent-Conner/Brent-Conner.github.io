﻿#### Paths
#$srcs = "\\EPICWBLOBTST\epicwblobtst_archive01\WBSTST\","\\EPICWBLOBTST\epicwblobtst_archive01\WBSBLD\","\\Epicwblobtst\wbsbld\","\\Epicwblobtst\wbstst\"
#$src = "\\EPICWEBBLOB\EpicWebBlob\BCAWBSPRD\"
#$src = "\\EPICWEBBLOB\wbsarchive1\WBSPRD\"

#$srcs = "\\EPICWEBBLOB\EpicWebBlob\WBSPRD\","\\epicwebblob\wbs2021$\WBSPRD\","\\wbsbackup\WBSPRD\"
$src = "\\EpicWeb\WBS2023$\WBSPRD\"

$dst = "\\epicwbs\wbsprd\"

#### Email
$from = "wbs@mountsinai.org"
$recipients = @("Brent.Conner@mountsinai.org","Daniel.Schwetz@mountsinai.org","Thomas.Grenier@mountsinai.org")
#$recipients = "Brent.Conner@mountsinai.org"
$start = Get-Date

Send-Mailmessage -to $recipients -from $from -Subject "WBS Script Started" -body "Start: $start
Source: $src || Destination: $dst
D:\Scripts\Merge.ps1 running on SEPIINTT01A007 as epicprintservice" -SmtpServer "smtp.mountsinai.org"

#foreach($src in $srcs) {
#### Do Stuff
$log = Get-Date -Format "MM_dd_HHmm" #d | % {$_.replace("/","_")}

### Use when copying from old root into new root path -- scenario lined out in Galaxy
# Epic's Command - robocopy.exe $src $dst /copyall /sec /e /tee /mt /r:3 /w:1 /dcopy:t /xo /log+:C:\logfile.txt
# Use to keep security of the destination
#robocopy.exe $src $dst /copy:DAT /e /tee /mt:32 /r:5 /w:1 /dcopy:t /xo /V /log+:D:\Robocopy\$log.txt


### Use when merging WBS paths from bottom up
robocopy.exe $src $dst /copy:DAT /is /it /im /e /mt:64 /r:5 /w:1 /dcopy:t /v /log+:D:\Robocopy\$log.txt

#}

$end = Get-Date

Send-Mailmessage -to $recipients -from $from -Subject "WBS Script Complete" -body "Start: $start
End: $end

Sources: $src
Destination: $dst

Technical Mortgage Payment Successful" -SmtpServer "smtp.mountsinai.org"