﻿function TXPRD { start powershell -argumentlist "ssh bconn029@txepic.wfsi.priv" }
function TXTST { start powershell -argumentlist "ssh bconn029@txepicnp.epic.ascension.org" }
function TXTST2 { start powershell -argumentlist "ssh bconn029@txepicnp.wfsi.priv" }
function TXDR { start powershell -argumentlist "ssh bconn029@txepicnpdr.epic.ascension.org" }
function TXDR2 { start powershell -argumentlist "ssh bconn029@txepicnpdr.wfsi.priv" }
function WITST { start powershell -argumentlist "ssh bconn030@epicnp.epic.ascension.org" }
function WIREL { start powershell -argumentlist "ssh bconn030@epicnp.wfsi.priv" }
function WIPRD { start powershell -argumentlist "ssh bconn030@epicent.epic.ascension.org" }



function Cache
{
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-Host -foreground Cyan "Cache Servers"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host "1.  TXPRD - txepic.wfsi.priv"
	Write-host "2.  TXNTST TXACE1 TXACE2 txmst TXPOC TXSTG - txepicnp.epic.ascension.org"
	Write-host "3.  TXEXAM TXOTST TXPJX1 TXPJX2 TXPLY TXPREP TXREF TXSUP - txepicnp.wfsi.priv"
    Write-Host "4.  DR TXACE2 txmst TXNTST txpoc - txepicnpdr.epic.ascension.org"
    Write-host "5.  DR TXACE1 TXEXAM txotst TXPLY TXPREP txref TXSUP - txepicnpdr.wfsi.priv"	
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "6.  WITST - epicnp.epic.ascension.org"
    Write-host "7.  REL, RELBLD - epicnp.wfsi.priv"
    Write-host "8.  WIPRD - epicent.epic.ascension.org"
    Write-host -foreground Red "---------------------------------------------------"
    Write-host "9.  Azure CLOUD TRAIN - zeusnldbtrn001"
    Write-host "10. Azure CLOUD TEST - zeusnldbtst001"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Yellow "<><><><><><><><><><><><><><>"
    Write-host -foreground Cyan "/epic/bin/epicmenu"
	$MenuOption = Read-host "Selection"
	
	Switch($MenuOption)
    {
		"1"  {TXPRD}
		"2"  {TXTST}
        "3"  {TXTST2}
		"4"  {TXDR}
        "5"  {TXDR2}
        "6"  {WITST}
        "7"  {WIREL}
        "8"  {WIPRD}
        "9"  {CLOUDTRAIN}
        "10" {CLOUDTEST}
        default {Continue}
    }
}
Cache