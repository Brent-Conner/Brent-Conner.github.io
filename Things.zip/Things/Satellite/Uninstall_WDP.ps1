﻿$servers = Get-Content D:\Scripts\_Servers\wdp.txt
foreach ($server in $servers) {
Invoke-Command -cn $server -ScriptBlock {
    (Get-WmiObject Win32_product | Where {$_.name -eq "Epic Windows Data Provider"}).Uninstall()
    }
}