$cmd = Get-ItemPropertyValue "HKLM:\SOFTWARE\WOW6432Node\Epic Systems Corporation\Satellite" -Name Path
$arg = "/F"
Start-Process -FilePath $cmd -ArgumentList $arg -Verb RunAs -Wait
Start-Process -FilePath $cmd -ArgumentList $arg -Verb RunAs -Wait


$pc = read-host "PC"
invoke-command -ComputerName $pc { Start-Process -FilePath "C:\Program Files (x86)\Epic\Satellite\105.0.8.0\Satellite.exe" -ArgumentList "/F" -Verb RunAs -Wait }

cd "C:\Program Files (x86)\Epic\Satellite\105.0.8.0"
.\Satellite /F
cd "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"



$pc = Read-host "PC"
#Invoke-Command -cn $pc { query user; Get-LocalUser }

#(get-itemproperty "HKCU:\Control Panel\Desktop\").FontSmoothing

Invoke-Command -cn $pc {
    New-PSDrive -PSProvider Registry -Name HKU -Root HKEY_USERS;
    $profiles = get-CHILditem "HKU:";
    foreach($profile in $profiles) { 
        $name = "HKU:\" + $profile; Echo $name;
        (Get-ItemProperty "$name\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders\").DESKTOP;
        (Get-ItemProperty "$name\Control Panel\Desktop\").FontSmoothing;
        };
    }