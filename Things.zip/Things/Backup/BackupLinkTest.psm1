﻿# Global Variables
##################
$BackupBase = "D:\Backup\"
$SaveFolder = "D:\Program Files (x86)\Epic\v8.3\TST"
$Date = Get-Date -Format d | % {$_.replace("/","_")}
$BackupTo = $BackupBase + $Date + "\"
##################

function BackupLink
{
    New-Item $BackupTo -Type Directory -Force | Out-Null
    $From = $SaveFolder
    Copy-Item $From -Destination $BackupTo -Force -Recurse -ErrorAction SilentlyContinue
}