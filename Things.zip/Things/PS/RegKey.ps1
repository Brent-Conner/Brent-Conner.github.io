﻿$path = "HKLM:\SYSTEM\CurrentControlSet\Services\HTTP\Parameters"
$name = "EnableErrorLogging"
$type = "DWORD"
$value = "0"

#If(!(Test-Path $path)) {

    New-Item -Path $path -Force | Out-Null
    New-ItemProperty -Path $path -Name $name -Value $value -PropertyType $type -Force | Out-Null
 #   }

#Else { New-ItemProperty -Path $registryPath -Name $name -Value $value -PropertyType $type -Force | Out-Null }