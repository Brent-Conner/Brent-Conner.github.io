﻿$EpicProcesses = Get-WmiObject win32_process | Where {$_.CommandLine -match "Epic"}

    foreach($process in $EpicProcesses)
    {
        $name = $process.name
        Write-Host -foreground green "Ending process $name"
        Stop-Process -id $process.processid -force
    }