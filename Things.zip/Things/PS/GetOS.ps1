﻿$a = Read-Host "PC or Server"
Invoke-Command -ComputerName $a { (Get-WMIObject win32_operatingsystem).name }
Invoke-Command -ComputerName $a { $env:COMPUTERNAME }