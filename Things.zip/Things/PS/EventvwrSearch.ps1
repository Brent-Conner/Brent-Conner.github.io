﻿Function EventSearch {
$logs = ("Application","Security","Setup","System","Forwarded Events")
Write-Host "Choose log"
Write-Host "1. Application"
Write-Host "2. Security"
Write-Host "3. Setup"
Write-Host "4. System"
Write-Host "5. Forwarded Events"
$num = Read-Host "Number"
$text = Read-Host "Text to search for"
$server = Read-Host "Server"
switch($num)
    {
        "1" {$log = $logs[0]}
        "2" {$log = $logs[1]}
        "3" {$log = $logs[2]}
        "4" {$log = $logs[3]}
        "5" {$log = $logs[4]}
    }


Get-WinEvent -ComputerName $server -FilterHashtable @{logname=$log} | where-object { $_.Message -like "*$text*" } | Select TimeCreated,Message,TaskCategory # | Out-File C:\output\events.csv
}
EventSearch