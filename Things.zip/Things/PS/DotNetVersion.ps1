﻿ $pc = Read-Host "pc"
 #Invoke-Command -computername $pc { (Get-ItemProperty "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").version }
 Invoke-Command -computername $pc { Get-ItemProperty "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" }