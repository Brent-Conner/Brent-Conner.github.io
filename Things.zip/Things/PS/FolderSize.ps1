﻿$BasePath = "\\blobcifs\epicblob$\BCA\Outgoing\PROD\IC\-P\HS\-P\"
# $Path = Read-Host "Path"
$Folders = Get-ChildItem $BasePath -Directory

Foreach ($Folder in $Folders)
{
$Path = $BasePath + $Folder
Write-Host $Path
$MB = "{0:N2} MB" -f ((Get-ChildItem $Path -Recurse | Measure-Object -Property Length -Sum -ErrorAction Stop).Sum / 1MB)
$Out = $Path + "^" + $MB
$Out | Out-File C:\Output\BCASize.csv -Append
}