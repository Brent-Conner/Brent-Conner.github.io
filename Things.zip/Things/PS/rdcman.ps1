﻿$servers = Get-Content C:\Scripts\servers.txt
$groups = Get-Content C:\Scripts\groups.txt
$file = "C:\Scripts\rdcmanIL.txt"
        
foreach($server in $servers) {        
        
"        <server>" | Out-File $file -append
"          <properties>" | Out-File $file -append
"            <name>$server</name>" | Out-File $file -append
"          </properties>" | Out-File $file -append
"        </server>" | Out-File $file -append
}

foreach($group in $groups) {
"     <group>" | Out-File $file -append
"       <properties>" | Out-File $file -append
"         <name>$group</name>" | Out-File $file -append
"       </properties>" | Out-File $file -append
"       <group>" | Out-File $file -append
"         <properties>" | Out-File $file -append
"           <name>PRD</name>" | Out-File $file -append
"         </properties>" | Out-File $file -append
"       </group>" | Out-File $file -append
"       <group>" | Out-File $file -append
"         <properties>" | Out-File $file -append
"           <name>TEST</name>" | Out-File $file -append
"         </properties>" | Out-File $file -append
"       </group>" | Out-File $file -append
"     </group>" | Out-File $file -append
}
