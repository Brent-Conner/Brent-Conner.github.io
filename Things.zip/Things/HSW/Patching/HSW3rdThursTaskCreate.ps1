﻿$servers = Get-Content D:\Scripts\_Servers\HSW3rdThurs.txt
foreach($server in $servers) {
Invoke-Command -ComputerName $server { New-Item -Path D:\Scripts\Patching\ -Type Directory -Force;  }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\Patching" -Destination D:\Scripts\ -Force -recurse -ToSession $s

Invoke-Command -cn $server { Register-ScheduledTask -TaskName "Drain 3rd Thurs" -Xml (Get-Content "D:\Scripts\Patching\Drain3rdThurs4pm.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
Invoke-Command -cn $server { Register-ScheduledTask -TaskName "InService 3rd Fri" -Xml (Get-Content "D:\Scripts\Patching\InService3rdFri3am.xml" | out-string) -User msnyuhealth\epicprintservice -Password Ep1c77468$ -Force }
}