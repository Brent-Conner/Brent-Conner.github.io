﻿$dest = "C:\ProgramData\Epic\ECSMTools\Maintenance\"
$drain = "D:\Scripts\Patching\Drain\status.json"

Copy-Item -Path $drain -Destination $dest -Force