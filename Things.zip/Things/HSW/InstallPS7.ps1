﻿#$health = Invoke-WebRequest https://localhost/Hyperspace_PRD/health/healthHandler.ashx?mode=loadbalancer -skipcertificatecheck | % {$_.StatusCode}

$servers = Get-Content -path D:\Scripts\_Servers\HSW.txt

foreach($server in $servers) {
$src = "\\epicfileshare\epicfileshare\Brent\Apps\PowerShell-7.3.0-win-x64.msi"
$s = New-PSSession $server
Invoke-Command -cn $server { New-Item -Path "D:\Scripts\Installs\" -type directory -Force }
Copy-Item -Path $src -Destination "D:\Scripts\Installs\" -ToSession $s -Recurse -Force

#Invoke-Command -cn $server { msiexec.exe /i "D:\Scripts\Installs\PowerShell-7.3.0-win-x64.msi" /qb! /lv+ "D:\Scripts\PS7.log" }

}