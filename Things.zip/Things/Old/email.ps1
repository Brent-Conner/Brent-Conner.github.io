$to = ("bconner@phs.org")
$from = ("CA Service Desk donotreply@phs.org")
$bcc = ("bconner@phs.org")

Send-Mailmessage -to $to -bcc $bcc -from $from -Subject "Cat facts - Transfer to You" -body "Thank you for joining Cat Facts!

Cats make about 100 different sounds. Dogs make only about 10.


If you would like to unsubscribe please use the following link:
http://replygif.net/i/130.gif" -SmtpServer "imr2.phs.org"
