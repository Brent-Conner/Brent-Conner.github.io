$names = Get-ChildItem -Force \\epic2010hwebm\bca\outgoing
$all = $names | Select Name
$singles = $all | Select-String Name
$output = $singles -replace ".*=" -replace "}.*"
foreach ($one in $output)
{
Restart-Computer -Computername $one
}