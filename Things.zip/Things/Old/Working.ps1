﻿$Images = Get-Content C:\Input\Images.txt
foreach($image in $images)
    {
    $path = '\\blobcifs\epicblob$\PRD\WBS_Stor\PHSLOGO\MedIllustrations\' + $image
    $fileexist = test-path -path $path
    if($fileexist -eq $true) { $image | out-file C:\output\exists.csv -append }
    if($fileexist -eq $false) { $image | out-file C:\output\noexist.csv -append }
    }