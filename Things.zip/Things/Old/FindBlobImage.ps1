
while(1)
{
#$path = "\\blobcifs\epicblob$\PRD\WBS_Stor\Epic\Images"
$path = "\\blobcifs\epicblob$\PRD\WBS_Stor\PHSLOGO"

$x = 0
$y = 1

$file = read-host "Enter name of the blob image"
$file = $file -replace " ", ""
$array = $file.tochararray()
while(1)
{
$path = $path + $array[$x] + $array[$y] + "\"
$result = Test-Path $path

	If($result -eq $true)
	{
	$lpath = $path
	$x++; $y++
    	$x++; $y++
	if($array[$x] -eq $null){write-host "File may exist at" $path; explorer $path; break}
	$fpath = $path + $file
	$fresult = Test-Path $fpath
		if($fresult -eq $true){write-host "Location:" $fpath; invoke-item $fpath; explorer "$path"; break}
	}
	Else{Write-host $file "not found";write-host "File may exist at" $lpath; explorer $lpath; break}
}
}

