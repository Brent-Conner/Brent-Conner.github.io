$pcs = Get-Content "C:/epic/welcome.txt"
foreach($pc in $pcs) { Write-Host $pc; Restart-Computer -ComputerName $pc -Force }