##Get-WMIObject -class Win32_Printer -computer epictroy64  | Select Name,DriverName,PortName,PrinterStatus ## | Export-CSV -path c:\scripts\troy.csv

Get-PrinterDriver -ComputerName EpicTroy64 | Select-Object Name,@{ n="DriverVersion";e={
$ver = $_.DriverVersion
$rev = $ver -band 0xffff
$build = ($ver -shr 16) -band 0xffff
$minor = ($ver -shr 32) -band 0xffff
$major = ($ver -shr 48) -band 0xffff
"$major.$minor.$build.$rev"} } | Export-CSV -path c:\scripts\driver2.csv
##$PrintDriver = Get-PrinterDriver * -ComputerName epictroy64