﻿# Delete all files older than 7 days
$servers = ("zwpdcepicifc11","zwpdcepicifc12","zwpdcepicifc13","zwpdcepicifc14","zwtstepicifc11","zwtstepicifc12")
$Paths = ("\C$\inetpub\logs\LogFiles\W3SVC1\","\C$\ProgramData\Epic\Interconnect\TraceFiles\")
$Days = "-7"
$CurrentDate = Get-Date
$DatetoDelete = $CurrentDate.AddDays($Days)
foreach($server in $servers) {
foreach($path in $Paths) {
$path = "\\" + $server + $path
Get-ChildItem $Path -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse
}
}