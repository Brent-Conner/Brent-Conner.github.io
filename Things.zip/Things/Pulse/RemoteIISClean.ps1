﻿# Delete all files older than 30 days

$Path = "C:\inetpub\logs\LogFiles\W3SVC1\"
$Days = "-30"
$CurrentDate = Get-Date
$DatetoDelete = $CurrentDate.AddDays($Days)
Write-Host "Deleting files in $Path"
Get-ChildItem $Path -Recurse | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse
