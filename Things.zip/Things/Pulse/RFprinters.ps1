$RFservers = ("ZWPDCEPICFAX11","ZWPDCEPICFAX12")
$name = "EPSFAX"

foreach($server in $RFservers) {
$stat = (Get-Printer -cn $server -Name $name).PrinterStatus
if($stat -ne "Normal") {

Send-Mailmessage -to ECSM@PHS.ORG -from PulseScript@phs.org -subject "$server - Check EPSFAX queue" -body "Current status of EPSFAX
$server $stat" -SmtpServer "imr2.phs.org"
} }