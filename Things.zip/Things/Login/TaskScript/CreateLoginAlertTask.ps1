﻿$servers = Get-Content D:\Scripts\_Servers\InternalOnPrem.txt
#foreach($server in $servers) {
$server = "SEPIKPRP01A001"
Invoke-Command -ComputerName $server { New-Item -Path D:\Scripts\ -Type Directory -Force;  }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\TaskScript\LoginAlert" -Destination D:\Scripts\ -Force -recurse -ToSession $s

Invoke-Command -cn $server { Register-ScheduledTask -TaskName "LoginAlert" -Xml (Get-Content "D:\Scripts\LoginAlert\LoginAlert.xml" | out-string) -Force }
#}