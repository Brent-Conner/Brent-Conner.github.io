﻿#### Get user and server
#$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$server = Hostname
$user = query user /server:$server
$title = $user[0]
$name1 = $user[1]
$name2 = $user[2]
#$name = ($user[1].substring(0,15)).Trim()


#### Email
$from = "Why@mountsinai.org"
#$recipients = @("Brent.Conner@mountsinai.org","Daniel.Schwetz@mountsinai.org","Thomas.Grenier@mountsinai.org")
$recipients = "Brent.Conner@mountsinai.org"
$Date = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::Now,"US Eastern Standard Time")

Send-Mailmessage -to $recipients -from $from -Subject "Someone logged in" -body "Session(s)
$title[0]
$name1[1]
$name2[2]
$server
Time of server query $date" -SmtpServer "smtp.mountsinai.org"