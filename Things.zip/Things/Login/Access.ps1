﻿$servers = Get-Content D:\Scripts\_Servers\InternalOnPrem.txt


foreach($server in $servers) {
Write-Host $server
#Invoke-Command -ComputerName $server { net localgroup Administrators "msnyuhealth\MSH-Azure Epic Servers Local Administrators-MSH" /add }
Invoke-Command -ComputerName $server { net localgroup Administrators "msnyuhealth\epictechadmins" /delete }
}

net localgroup Administrators "msnyuhealth\epictechadmins" /add