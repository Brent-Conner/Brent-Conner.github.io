﻿{
$server = Read-Host "Server"
Invoke-Command -ComputerName $server { New-Item -Path C:\Copy\ -Type Directory -Force }
$s = New-PSSession $server
Copy-Item -Path "\\epicfileshare\epicfileshare\Brent\Copy\*.*" -Destination C:\Copy\ -Force -recurse -ToSession $s
}

{
$src = "\\Epicwblobtst\wbsbld\*"
$dest = "\\epicwbs\WBSPRD\MRG\"
Copy-Item -Path $src -Destination $dest -Force -recurse
}