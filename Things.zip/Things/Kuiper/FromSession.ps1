﻿#$servers = Get-Content "D:\Scripts\_Servers\MychartTST.txt"
$server = "SEPIMYCP01A003"
$src = "C:\Program Files (x86)\Epic\MyChart\v10.2-MYCHARTSSO\web\mychart.ini"


#foreach($server in $servers) {
#New-Item -path "D:\MyChart\$server" -type directory -force
$dst = "D:\MyChart\SEPIMYCP01A003\SSO\"

$s = New-PSSession $server -Credential $server\conneb02-pa 

Copy-Item -Path $src -Destination $dst -FromSession $s -Recurse -Force

#}

