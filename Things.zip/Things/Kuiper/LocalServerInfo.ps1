﻿$server = Read-Host "Server"
$outfile = "D:\Scripts\otherinfo.txt"
#"Server^vCPU^RAM (GB)^Processor" | 
out-file $outfile -Force

Write-Host $server
$ram = (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property capacity -Sum).sum / 1gb
$vcpu = (Get-WmiObject Win32_ComputerSystem).NumberOfLogicalProcessors
$cpu = (Get-WmiObject Win32_Processor).Name[0]
$disks = get-wmiobject win32_logicaldisk | Select DeviceID,FreeSpace,Size
$diskv = $null
foreach($disk in $disks) { $diskv = $diskv + $disk.DeviceID + "^" + ($disk.FreeSpace)/1024/1024/1024 + "^" + ($disk.Size)/1024/1024/1024 + "^"}

$out = $server + "^" + $vcpu + "^" + $ram + "^" + $cpu + "^" + $diskv
$out | out-file $outfile -append
